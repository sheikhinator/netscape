# Netscape

An offline, fully encrypted video and photo vault for Android, with a cinematic browse experience —
hero billboard, content rails, resume-where-you-left-off, artwork you control.

Your photos and videos stay on the device. The optional on-device AI feature uses
Android AICore and may download Google's Gemini Nano model once, after you confirm.
That download is the model only; Netscape does not upload your media to a cloud AI
service. Imports still work when the model is unavailable.

## Security model

| Layer | What happens |
|---|---|
| Passphrase | PBKDF2-HMAC-SHA256, 150,000 iterations, 16-byte random salt → 256-bit master key. Never stored. |
| Per-item key | Every video and photo gets its own random 256-bit key, wrapped with the master key using AES-GCM. |
| Media payload | AES-256-CTR, random 16-byte IV per file. CTR is used so the player can seek instantly without decrypting the whole file. |
| Thumbnails & index | AES-256-GCM (authenticated). The library index itself is encrypted, so filenames and titles are unreadable at rest. |
| On screen | `FLAG_SECURE` — no screenshots, blank in the recent-apps switcher. |
| Playback | A custom ExoPlayer `DataSource` decrypts in memory as it streams. No temp file is ever written in the clear. |
| Auto-lock | The vault locks itself the moment the app goes to the background. |

Files live in the app's private storage (`/data/data/com.netscape.vault/files/vault`) — invisible to the
gallery, to other apps, and to anyone with the phone but not the passphrase.

**There is no recovery.** Lose the passphrase, lose the vault. That is the point.

## Features

- Bottom navigation: **Home · Videos · Photos · Folders · Search**
- Folders: tiles with cover art and counts, rename or remove a folder (removing never deletes media — items fall back to My Library)
- Tags: add tags to any item, browse them as chips on the Folders tab, search by tag
- On-device AI can generate titles, descriptions, and searchable tags after import; regenerate them from an item's details
- Multi-select: long-press any tile in Videos/Photos/Search/a folder, then bulk move to a folder, bulk tag, or bulk delete
- Netflix-style home: hero billboard, horizontal rails, progress bars on partially watched videos
- **No repeated tiles** — each title appears in exactly one rail; the hero is excluded from the rails below it
- **No duplicate imports** — every file is SHA-256 hashed as it is encrypted; identical bytes are rejected
- Continue Watching with per-item resume position
- Rename, move to a folder (folders become their own rails on Home), My List favourites
- Change artwork: scrub any frame out of the *encrypted* video, or pick any image from the device
- Search and filter (videos / photos / My List / in progress)
- Pinch-zoom photo viewer

## Build the APK on GitHub (phone only, zip stays zipped)

You upload two things and never unzip anything yourself.

1. Create a new GitHub repo (private is fine).
2. **Add file -> Upload files** -> drop `Netscape-source.zip` in as-is. Commit.
3. **Add file -> Create new file** -> type the filename exactly:
   `.github/workflows/build.yml`
   (typing the slashes creates the folders). Paste in the contents of the `build.yml`
   that came with this project. Commit.

That second commit starts the build immediately. The workflow finds the zip in the repo
root, unpacks it, locates the Gradle project inside, and builds it.

When it finishes (~4-6 min), go to **Releases** on the repo — the APK is attached there as a
plain `Netscape.apk` you can tap and install straight from your phone browser. (It is also
under Actions -> the run -> Artifacts, if you prefer.)

To update later: replace the zip with a new one and commit. Nothing else changes.

## Notes

- Minimum Android 8.0 (API 26).
- The first launch asks you to create a passphrase. Type it carefully; there is no reset.
- Importing uses the system file picker, so the app requests **zero runtime permissions**.
- Originals are left where they are — delete them from your gallery yourself once you have verified the import.
