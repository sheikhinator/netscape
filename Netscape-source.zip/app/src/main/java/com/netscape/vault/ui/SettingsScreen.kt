package com.netscape.vault.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings as AndroidSettings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.ai.ModelAvailability
import com.netscape.vault.ai.ModelReadiness
import com.netscape.vault.data.Vault
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onLock: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var availability by remember { mutableStateOf<ModelAvailability?>(null) }
    var checking by remember { mutableStateOf(false) }
    var downloading by remember { mutableStateOf(false) }
    var statusError by remember { mutableStateOf<String?>(null) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    suspend fun refreshStatus() {
        checking = true
        statusError = null
        try {
            availability = Vault.aiModelAvailability()
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            statusError = error.localizedMessage
                ?: "Could not check Android's on-device AI service."
        } finally {
            checking = false
        }
    }

    LaunchedEffect(Unit) {
        refreshStatus()
    }

    val statusTitle = when {
        checking && availability == null -> "Checking device support"
        availability == null -> "Status not checked"
        availability?.readiness == ModelReadiness.AVAILABLE -> "Ready"
        availability?.readiness == ModelReadiness.DOWNLOADABLE -> "Download required"
        availability?.readiness == ModelReadiness.DOWNLOADING -> "Downloading"
        else -> "Unavailable on this device"
    }
    val statusColor = when (availability?.readiness) {
        ModelReadiness.AVAILABLE -> Color(0xFF8BC98B)
        ModelReadiness.DOWNLOADABLE, ModelReadiness.DOWNLOADING -> Color(0xFFFFD166)
        ModelReadiness.UNAVAILABLE -> Color(0xFFFF8A80)
        null -> Brand.Muted
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, end = 20.dp, top = 12.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(
                text = "Settings",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Device status and privacy controls",
                color = Brand.Muted,
                fontSize = 14.sp
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Brand.SurfaceHigh)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "On-device AI",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = statusTitle,
                        color = statusColor,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = availability?.explanation
                            ?: if (checking) "Checking Android AICore…" else "Check the device to see whether the model is supported.",
                        color = Color.White,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )

                    if (availability?.readiness == ModelReadiness.UNAVAILABLE) {
                        Text(
                            text = "Netscape cannot switch this capability on for an unsupported phone. If your phone should support it, check for Android and AICore updates, then check again.",
                            color = Brand.Muted,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }

                    statusError?.let {
                        Text(
                            text = it,
                            color = Color(0xFFFF8A80),
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                    actionMessage?.let {
                        Text(
                            text = it,
                            color = Brand.Muted,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }

                    if (availability?.readiness == ModelReadiness.DOWNLOADABLE) {
                        Button(
                            onClick = {
                                scope.launch {
                                    downloading = true
                                    actionMessage = null
                                    try {
                                        Vault.downloadAiModel()
                                        actionMessage = "The on-device model is ready."
                                    } catch (cancelled: CancellationException) {
                                        throw cancelled
                                    } catch (error: Exception) {
                                        actionMessage = error.localizedMessage
                                            ?: "The on-device model could not be downloaded."
                                    } finally {
                                        downloading = false
                                    }
                                    refreshStatus()
                                }
                            },
                            enabled = !downloading && !checking,
                            colors = ButtonDefaults.buttonColors(containerColor = Brand.Red)
                        ) {
                            if (downloading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                                Text("Downloading…", modifier = Modifier.padding(start = 8.dp))
                            } else {
                                Text("Download model")
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            scope.launch {
                                actionMessage = null
                                refreshStatus()
                            }
                        },
                        enabled = !checking && !downloading
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null)
                        Text("Check again", modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Brand.SurfaceHigh)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Privacy and storage",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "When available, AI analysis uses Gemini Nano through Android AICore on this phone. Netscape does not send your photos or videos to a cloud AI service.",
                        color = Color.White,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )
                    Text(
                        text = "Vault media is encrypted and kept in this app's private storage.",
                        color = Brand.Muted,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }

            OutlinedButton(
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    context.startActivity(
                        Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                            data = Uri.fromParts("package", context.packageName, null)
                        }
                    )
                }
            ) {
                Icon(Icons.Filled.Settings, contentDescription = null)
                Text("Open Android app settings", modifier = Modifier.padding(start = 8.dp))
            }

            TextButton(
                onClick = onLock,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.Lock, contentDescription = null)
                Text("Lock vault now", modifier = Modifier.padding(start = 8.dp))
            }

            Spacer(Modifier.height(20.dp))
        }
    }
}