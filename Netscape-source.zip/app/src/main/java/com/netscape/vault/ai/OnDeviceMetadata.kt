package com.netscape.vault.ai

import android.graphics.Bitmap
import com.google.mlkit.genai.common.DownloadStatus
import com.google.mlkit.genai.common.FeatureStatus
import com.google.mlkit.genai.prompt.GenerateContentRequest
import com.google.mlkit.genai.prompt.Generation
import com.google.mlkit.genai.prompt.ImagePart
import com.google.mlkit.genai.prompt.TextPart
import kotlinx.coroutines.flow.collect
import org.json.JSONObject
import java.util.Locale

enum class ModelReadiness {
    AVAILABLE,
    DOWNLOADABLE,
    DOWNLOADING,
    UNAVAILABLE
}

data class AiMetadata(
    val title: String,
    val description: String,
    val tags: List<String>
)

/**
 * Gemini Nano is accessed through Android AICore. Only in-memory bitmaps and
 * prompts are passed to the model; Netscape never sends media to a cloud API.
 */
object OnDeviceMetadata {
    private val model by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        Generation.getClient()
    }

    suspend fun readiness(): ModelReadiness =
        try {
            when (model.checkStatus()) {
                FeatureStatus.AVAILABLE -> ModelReadiness.AVAILABLE
                FeatureStatus.DOWNLOADABLE -> ModelReadiness.DOWNLOADABLE
                FeatureStatus.DOWNLOADING -> ModelReadiness.DOWNLOADING
                else -> ModelReadiness.UNAVAILABLE
            }
        } catch (_: Exception) {
            ModelReadiness.UNAVAILABLE
        }

    suspend fun download(onProgress: (String) -> Unit = {}) {
        when (readiness()) {
            ModelReadiness.AVAILABLE -> return
            ModelReadiness.DOWNLOADABLE -> Unit
            ModelReadiness.DOWNLOADING ->
                throw IllegalStateException("The on-device AI model is already downloading.")
            ModelReadiness.UNAVAILABLE ->
                throw IllegalStateException("On-device AI is not available on this device.")
        }

        var downloadError: String? = null
        model.download().collect { status ->
            when (status) {
                is DownloadStatus.DownloadStarted ->
                    onProgress("Starting on-device AI model download")
                is DownloadStatus.DownloadProgress ->
                    onProgress("Downloading on-device AI model (${status.totalBytesDownloaded} bytes)")
                DownloadStatus.DownloadCompleted ->
                    onProgress("On-device AI model ready")
                is DownloadStatus.DownloadFailed ->
                    downloadError = status.e.message ?: "Model download failed."
            }
        }

        downloadError?.let { throw IllegalStateException(it) }
        if (readiness() != ModelReadiness.AVAILABLE) {
            throw IllegalStateException("The on-device AI model did not become available.")
        }
    }

    suspend fun describePhoto(bitmap: Bitmap): AiMetadata {
        val prompt = """
            Create private photo-library metadata for this image.
            Describe only visible content. Do not identify people or infer identity, age,
            relationships, health, or other private traits. Keep the description neutral
            and non-graphic. Return only one valid JSON object with:
            "title" (a short, useful title), "description" (one concise factual sentence),
            and "tags" (3 to 8 short, searchable labels).
            Example shape: {"title":"...","description":"...","tags":["..."]}
        """.trimIndent()
        val request = GenerateContentRequest.Builder(
            ImagePart(bitmap),
            TextPart(prompt)
        ).build()
        return parse(responseText(model.generateContent(request)))
    }

    suspend fun describeVideo(frames: List<Bitmap>): AiMetadata {
        require(frames.isNotEmpty()) { "No video frames could be read." }

        val observations = frames.mapIndexedNotNull { index, frame ->
            val prompt = """
                Describe only the visible content of this sampled video frame in one
                concise, factual sentence. Do not identify people or infer identity,
                age, relationships, health, or other private traits. Frame ${index + 1}.
            """.trimIndent()
            val request = GenerateContentRequest.Builder(
                ImagePart(frame),
                TextPart(prompt)
            ).build()
            responseText(model.generateContent(request)).takeIf { it.isNotBlank() }
        }
        if (observations.isEmpty()) {
            throw IllegalStateException("The model could not describe the video frames.")
        }

        val prompt = """
            Create private video-library metadata from these ordered observations of
            sampled frames from one video:
            ${observations.mapIndexed { index, text -> "${index + 1}. $text" }.joinToString("\n")}

            Describe only visible content. Do not identify people or infer identity, age,
            relationships, health, or other private traits. Keep the description neutral
            and non-graphic. Return only one valid JSON object with:
            "title" (a short, useful title), "description" (one concise factual sentence),
            and "tags" (3 to 8 short, searchable labels).
            Example shape: {"title":"...","description":"...","tags":["..."]}
        """.trimIndent()
        return parse(responseText(model.generateContent(prompt)))
    }

    private fun responseText(response: com.google.mlkit.genai.prompt.GenerateContentResponse): String =
        response.candidates.firstOrNull()?.text?.trim().orEmpty()

    private fun parse(raw: String): AiMetadata {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) {
            throw IllegalStateException("The model did not return metadata in the expected format.")
        }

        val json = JSONObject(raw.substring(start, end + 1))
        val title = json.optString("title").trim().take(80)
        val description = json.optString("description").trim().take(400)
        val tagsArray = json.optJSONArray("tags")
        val tags = buildList<String> {
            if (tagsArray != null) {
                for (index in 0 until tagsArray.length()) {
                    val tag = tagsArray.optString(index)
                        .trim()
                        .removePrefix("#")
                        .trim()
                        .lowercase(Locale.ROOT)
                        .take(32)
                    if (tag.isNotBlank() && none { it.equals(tag, ignoreCase = true) }) {
                        add(tag)
                    }
                    if (size == 10) break
                }
            }
        }
        if (title.isBlank() || description.isBlank()) {
            throw IllegalStateException("The model returned incomplete metadata.")
        }
        return AiMetadata(title, description, tags)
    }
}