package com.netscape.vault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Sell
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch

/**
 * Shared grid used by Videos / Photos / Search / a folder / a tag.
 * Long-press any tile to start multi-select, then move to a folder, tag or delete in bulk.
 */
@Composable
fun MediaLibrary(
    entries: List<VaultItem>,
    emptyText: String,
    modifier: Modifier = Modifier,
    header: @Composable (() -> Unit)? = null,
    onOpen: (VaultItem) -> Unit
) {
    val scope = rememberCoroutineScope()
    var selected by remember { mutableStateOf(setOf<String>()) }
    var moveDialog by remember { mutableStateOf(false) }
    var tagDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }

    val selectionMode = selected.isNotEmpty()

    Column(modifier = modifier.fillMaxSize().background(Brand.Ink)) {
        if (selectionMode) {
            SelectionBar(
                count = selected.size,
                onClear = { selected = emptySet() },
                onMove = { moveDialog = true },
                onTag = { tagDialog = true },
                onDelete = { deleteDialog = true }
            )
        }
        header?.invoke()

        if (entries.isEmpty()) {
            Text(text = emptyText, color = Brand.Muted, modifier = Modifier.padding(24.dp))
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 110.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(entries, key = { it.id }) { item ->
                    MediaCard(
                        item = item,
                        modifier = Modifier.fillMaxWidth(),
                        selected = selected.contains(item.id),
                        selectionMode = selectionMode,
                        onLongClick = { selected = selected + item.id },
                        onClick = {
                            if (selectionMode) {
                                selected = if (selected.contains(item.id)) {
                                    selected - item.id
                                } else {
                                    selected + item.id
                                }
                            } else {
                                onOpen(item)
                            }
                        }
                    )
                }
            }
        }
    }

    if (moveDialog) {
        FolderPickerDialog(
            onDismiss = { moveDialog = false },
            onPick = { name ->
                val ids = selected
                moveDialog = false
                selected = emptySet()
                scope.launch { Vault.moveToCollection(ids, name) }
            }
        )
    }

    if (tagDialog) {
        var draft by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { tagDialog = false },
            containerColor = Brand.Surface,
            title = { Text("Add a tag", color = Color.White) },
            text = {
                Column {
                    OutlinedTextField(
                        value = draft,
                        onValueChange = { draft = it },
                        singleLine = true,
                        placeholder = { Text("e.g. travel", color = Brand.Muted) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    val existing = Vault.tags()
                    if (existing.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .horizontalScroll(rememberScrollState())
                                .padding(top = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            existing.take(12).forEach { tag ->
                                AssistChip(
                                    onClick = { draft = tag },
                                    label = { Text(tag, fontSize = 12.sp) },
                                    colors = AssistChipDefaults.assistChipColors(
                                        containerColor = Brand.SurfaceHigh,
                                        labelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val ids = selected
                    val value = draft
                    tagDialog = false
                    selected = emptySet()
                    scope.launch { Vault.addTagTo(ids, value) }
                }) { Text("Add", color = Brand.Red) }
            },
            dismissButton = {
                TextButton(onClick = { tagDialog = false }) { Text("Cancel", color = Color.White) }
            }
        )
    }

    if (deleteDialog) {
        AlertDialog(
            onDismissRequest = { deleteDialog = false },
            containerColor = Brand.Surface,
            title = { Text("Delete ${selected.size} item(s)?", color = Color.White) },
            text = { Text("The encrypted files are erased from this device.", color = Brand.Muted) },
            confirmButton = {
                TextButton(onClick = {
                    val ids = selected
                    deleteDialog = false
                    selected = emptySet()
                    scope.launch { Vault.deleteMany(ids) }
                }) { Text("Delete", color = Brand.Red) }
            },
            dismissButton = {
                TextButton(onClick = { deleteDialog = false }) { Text("Cancel", color = Color.White) }
            }
        )
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    onClear: () -> Unit,
    onMove: () -> Unit,
    onTag: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brand.SurfaceHigh)
            .padding(horizontal = 6.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClear) {
            Icon(Icons.Filled.Close, contentDescription = "Clear", tint = Color.White)
        }
        Text("$count selected", color = Color.White, fontSize = 14.sp)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = onMove) {
            Icon(Icons.Filled.DriveFileMove, contentDescription = "Move to folder", tint = Color.White)
        }
        IconButton(onClick = onTag) {
            Icon(Icons.Filled.Sell, contentDescription = "Tag", tint = Color.White)
        }
        IconButton(onClick = onDelete) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = Brand.Red)
        }
    }
}

@Composable
fun FolderPickerDialog(
    onDismiss: () -> Unit,
    onPick: (String) -> Unit
) {
    var newName by remember { mutableStateOf("") }
    val folders = Vault.collections()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Surface,
        title = { Text("Move to folder", color = Color.White) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                folders.forEach { name ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(name) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Folder, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                        Text("  $name", color = Color.White, fontSize = 15.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${Vault.countIn(name)}", color = Brand.Muted, fontSize = 12.sp)
                    }
                }
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    placeholder = { Text("New folder name", color = Brand.Muted) },
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Brand.SurfaceHigh,
                        unfocusedContainerColor = Brand.SurfaceHigh,
                        focusedIndicatorColor = Brand.Red,
                        unfocusedIndicatorColor = Brand.Line,
                        cursorColor = Brand.Red
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (newName.isNotBlank()) onPick(newName) },
                enabled = newName.isNotBlank()
            ) {
                Icon(Icons.Filled.CreateNewFolder, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                Text("  Create", color = Brand.Red)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) }
        }
    )
}

@Composable
fun VideosScreen(onOpen: (VaultItem) -> Unit) {
    var sortRecent by remember { mutableStateOf(true) }
    val videos = Vault.items
        .filter { it.kind == MediaKind.VIDEO }
        .let { list -> if (sortRecent) list.sortedByDescending { it.addedAt } else list.sortedBy { it.title.lowercase() } }

    MediaLibrary(
        entries = videos,
        emptyText = "No videos yet. Add some from the home screen.",
        header = {
            SectionHeader(
                title = "Videos",
                subtitle = "${videos.size} title(s)",
                action = if (sortRecent) "Newest" else "A–Z",
                onAction = { sortRecent = !sortRecent }
            )
        },
        onOpen = onOpen
    )
}

@Composable
fun PhotosScreen(onOpen: (VaultItem) -> Unit) {
    var sortRecent by remember { mutableStateOf(true) }
    val photos = Vault.items
        .filter { it.kind == MediaKind.PHOTO }
        .let { list -> if (sortRecent) list.sortedByDescending { it.addedAt } else list.sortedBy { it.title.lowercase() } }

    MediaLibrary(
        entries = photos,
        emptyText = "No photos yet.",
        header = {
            SectionHeader(
                title = "Photos",
                subtitle = "${photos.size} image(s)",
                action = if (sortRecent) "Newest" else "A–Z",
                onAction = { sortRecent = !sortRecent }
            )
        },
        onOpen = onOpen
    )
}

@Composable
fun SearchScreen(onOpen: (VaultItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Videos", "Photos", "My List", "In progress")

    val results = Vault.items
        .filter { item ->
            when (filter) {
                "Videos" -> item.kind == MediaKind.VIDEO
                "Photos" -> item.kind == MediaKind.PHOTO
                "My List" -> item.favorite
                "In progress" -> item.inProgress
                else -> true
            }
        }
        .filter { item ->
            query.isBlank() ||
                item.title.contains(query, ignoreCase = true) ||
                item.collection.contains(query, ignoreCase = true) ||
                item.allTags.any { it.contains(query, ignoreCase = true) }
        }
        .sortedByDescending { it.addedAt }

    MediaLibrary(
        entries = results,
        emptyText = "Nothing matches that.",
        header = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search titles, folders, tags", color = Brand.Muted) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Brand.Surface,
                        unfocusedContainerColor = Brand.Surface,
                        focusedIndicatorColor = Brand.Red,
                        unfocusedIndicatorColor = Color.Transparent,
                        cursorColor = Brand.Red
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                )
                Row(
                    modifier = Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    filters.forEach { name ->
                        FilterChip(
                            selected = filter == name,
                            onClick = { filter = name },
                            label = { Text(name, fontSize = 13.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                containerColor = Brand.Surface,
                                labelColor = Brand.Muted,
                                selectedContainerColor = Brand.Red,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        },
        onOpen = onOpen
    )
}

@Composable
fun FoldersScreen(
    onOpenFolder: (String) -> Unit,
    onOpenTag: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val folders = Vault.collections()
    val tags = Vault.tags()
    var manage by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var renameDraft by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .verticalScroll(rememberScrollState())
            .padding(bottom = 110.dp)
    ) {
        SectionHeader(title = "Folders", subtitle = "${folders.size} folder(s)")

        Text(
            text = "Long-press items in Videos or Photos to move them into a new folder. Long-press a folder here to rename or remove it.",
            color = Brand.Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )

        folders.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pair.forEach { name ->
                    FolderTile(
                        name = name,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenFolder(name) },
                        onLongClick = { manage = name }
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        if (tags.isNotEmpty()) {
            SectionHeader(title = "Tags", subtitle = "${tags.size} tag(s)")
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tags.forEach { tag ->
                    AssistChip(
                        onClick = { onOpenTag(tag) },
                        label = { Text(tag, fontSize = 13.sp) },
                        leadingIcon = {
                            Icon(Icons.Filled.Sell, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(14.dp))
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = Brand.Surface,
                            labelColor = Color.White
                        )
                    )
                }
            }
        }
    }

    val managing = manage
    if (managing != null) {
        AlertDialog(
            onDismissRequest = { manage = null },
            containerColor = Brand.Surface,
            title = { Text(managing, color = Color.White) },
            text = {
                Text(
                    "${Vault.countIn(managing)} item(s). Removing a folder keeps the media — items move back to ${Vault.DEFAULT_COLLECTION}.",
                    color = Brand.Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    renameDraft = managing
                    renaming = managing
                    manage = null
                }) {
                    Icon(Icons.Filled.Edit, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                    Text("  Rename", color = Brand.Red)
                }
            },
            dismissButton = {
                if (managing != Vault.DEFAULT_COLLECTION) {
                    TextButton(onClick = {
                        manage = null
                        scope.launch { Vault.deleteCollection(managing) }
                    }) { Text("Remove folder", color = Color.White) }
                }
            }
        )
    }

    val renamingName = renaming
    if (renamingName != null) {
        AlertDialog(
            onDismissRequest = { renaming = null },
            containerColor = Brand.Surface,
            title = { Text("Rename folder", color = Color.White) },
            text = {
                OutlinedTextField(
                    value = renameDraft,
                    onValueChange = { renameDraft = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    val target = renameDraft
                    renaming = null
                    scope.launch { Vault.renameCollection(renamingName, target) }
                }) { Text("Save", color = Brand.Red) }
            },
            dismissButton = {
                TextButton(onClick = { renaming = null }) { Text("Cancel", color = Color.White) }
            }
        )
    }
}

@Composable
private fun FolderTile(
    name: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cover = Vault.coverOf(name)
    Column(
        modifier = modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .clip(RoundedCornerShape(8.dp))
                .background(Brand.SurfaceHigh)
        ) {
            if (cover != null) ThumbImage(cover, Modifier.fillMaxSize())
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0.3f to Color.Transparent,
                            1f to Color.Black.copy(alpha = 0.8f)
                        )
                    )
            )
            Icon(
                Icons.Filled.Folder,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.9f),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(8.dp)
                    .size(18.dp)
            )
            Text(
                text = "${Vault.countIn(name)}",
                color = Color.White,
                fontSize = 11.sp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(8.dp)
            )
        }
        Text(
            text = name,
            color = Color.White,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
fun CollectionScreen(
    title: String,
    entries: List<VaultItem>,
    onBack: () -> Unit,
    onOpen: (VaultItem) -> Unit
) {
    MediaLibrary(
        entries = entries,
        emptyText = "This folder is empty.",
        header = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Column {
                    Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${entries.size} item(s)", color = Brand.Muted, fontSize = 12.sp)
                }
            }
        },
        onOpen = onOpen
    )
}

@Composable
private fun SectionHeader(
    title: String,
    subtitle: String,
    action: String? = null,
    onAction: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 12.dp, top = 18.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = Brand.Muted, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        if (action != null && onAction != null) {
            TextButton(onClick = onAction) { Text(action, color = Brand.Red, fontSize = 13.sp) }
        }
    }
}

@Composable
fun SpacerHeight(value: Int) {
    Box(modifier = Modifier.height(value.dp))
}
