package com.netscape.vault.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import com.netscape.vault.ai.AiMetadata
import com.netscape.vault.ai.ModelReadiness
import com.netscape.vault.ai.OnDeviceMetadata
import com.netscape.vault.crypto.Crypto
import com.netscape.vault.crypto.EncryptedMediaDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import javax.crypto.SecretKey

enum class MediaKind { VIDEO, PHOTO }

data class VaultItem(
    val id: String,
    val title: String,
    val kind: MediaKind,
    val hash: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val addedAt: Long,
    val keyWrap: String,
    val collection: String,
    val favorite: Boolean,
    val progressMs: Long,
    val lastOpened: Long,
    val hasThumb: Boolean,
    val tags: List<String> = emptyList(),
    val description: String = "",
    val aiTags: List<String> = emptyList(),
    val titleManuallyEdited: Boolean = false
) {
    val allTags: List<String>
        get() = (tags + aiTags).distinctBy { it.lowercase() }

    val progressFraction: Float
        get() = if (durationMs > 0) (progressMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    val inProgress: Boolean
        get() = kind == MediaKind.VIDEO && progressMs > 5_000 && progressFraction < 0.95f
}

object Vault {

    const val DEFAULT_COLLECTION = "My Library"

    lateinit var appContext: Context
        private set

    private var master: SecretKey? = null
    private val thumbCache = object : android.util.LruCache<String, Bitmap>(48) {}

    val items: SnapshotStateList<VaultItem> = mutableStateListOf()
    val unlocked = mutableStateOf(false)
    val busyMessage = mutableStateOf<String?>(null)

    /** Set while a system picker is on screen so auto-lock does not fire. */
    var suppressAutoLock = false

    private val root: File get() = File(appContext.filesDir, "vault").apply { mkdirs() }
    private val mediaDir: File get() = File(root, "media").apply { mkdirs() }
    private val thumbDir: File get() = File(root, "thumbs").apply { mkdirs() }
    private val headerFile: File get() = File(root, "header.json")
    private val libraryFile: File get() = File(root, "library.enc")

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun hasVault(): Boolean = headerFile.exists()

    fun lock() {
        master = null
        items.clear()
        thumbCache.evictAll()
        unlocked.value = false
    }

    // ---------- unlock / create ----------

    suspend fun createVault(password: String): Boolean = withContext(Dispatchers.IO) {
        val salt = Crypto.randomBytes(16)
        val key = Crypto.deriveMasterKey(password.toCharArray(), salt)
        val verifier = Crypto.gcmEncrypt(key, "NETSCAPE-V1".toByteArray())
        val header = JSONObject()
            .put("v", 1)
            .put("salt", Crypto.b64(salt))
            .put("iterations", Crypto.ITERATIONS)
            .put("verifier", Crypto.b64(verifier))
        headerFile.writeText(header.toString())
        master = key
        items.clear()
        saveLibrary()
        unlocked.value = true
        true
    }

    suspend fun unlock(password: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val header = JSONObject(headerFile.readText())
            val salt = Crypto.unb64(header.getString("salt"))
            val iterations = header.optInt("iterations", Crypto.ITERATIONS)
            val key = Crypto.deriveMasterKey(password.toCharArray(), salt, iterations)
            val plain = Crypto.gcmDecrypt(key, Crypto.unb64(header.getString("verifier")))
            if (String(plain) != "NETSCAPE-V1") return@withContext false
            master = key
            loadLibrary()
            unlocked.value = true
            true
        } catch (e: Exception) {
            master = null
            false
        }
    }

    suspend fun changePassword(current: String, next: String): Boolean = withContext(Dispatchers.IO) {
        val header = JSONObject(headerFile.readText())
        val salt = Crypto.unb64(header.getString("salt"))
        val iterations = header.optInt("iterations", Crypto.ITERATIONS)
        val oldKey = try {
            val k = Crypto.deriveMasterKey(current.toCharArray(), salt, iterations)
            Crypto.gcmDecrypt(k, Crypto.unb64(header.getString("verifier")))
            k
        } catch (e: Exception) {
            return@withContext false
        }
        val newSalt = Crypto.randomBytes(16)
        val newKey = Crypto.deriveMasterKey(next.toCharArray(), newSalt)
        // Re-wrap every per-item key under the new master key.
        val rewrapped = items.map { item ->
            val fileKey = Crypto.unwrapKey(oldKey, item.keyWrap)
            item.copy(keyWrap = Crypto.wrapKey(newKey, fileKey))
        }
        master = newKey
        withContext(Dispatchers.Main) {
            items.clear()
            items.addAll(rewrapped)
        }
        headerFile.writeText(
            JSONObject()
                .put("v", 1)
                .put("salt", Crypto.b64(newSalt))
                .put("iterations", Crypto.ITERATIONS)
                .put("verifier", Crypto.b64(Crypto.gcmEncrypt(newKey, "NETSCAPE-V1".toByteArray())))
                .toString()
        )
        saveLibrary()
        true
    }

    // ---------- persistence ----------

    private fun loadLibrary() {
        val key = master ?: return
        val list = mutableListOf<VaultItem>()
        if (libraryFile.exists()) {
            try {
                val json = String(Crypto.gcmDecrypt(key, libraryFile.readBytes()))
                val arr = JSONArray(json)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list += VaultItem(
                        id = o.getString("id"),
                        title = o.getString("title"),
                        kind = if (o.getString("kind") == "PHOTO") MediaKind.PHOTO else MediaKind.VIDEO,
                        hash = o.optString("hash", ""),
                        sizeBytes = o.optLong("size", 0L),
                        durationMs = o.optLong("duration", 0L),
                        addedAt = o.optLong("added", 0L),
                        keyWrap = o.getString("keyWrap"),
                        collection = o.optString("collection", DEFAULT_COLLECTION),
                        favorite = o.optBoolean("favorite", false),
                        progressMs = o.optLong("progress", 0L),
                        lastOpened = o.optLong("lastOpened", 0L),
                        hasThumb = o.optBoolean("thumb", false),
                        tags = run {
                            val arrTags = o.optJSONArray("tags")
                            val out = mutableListOf<String>()
                            if (arrTags != null) {
                                for (t in 0 until arrTags.length()) out.add(arrTags.getString(t))
                            }
                            out
                        },
                        description = o.optString("description", ""),
                        aiTags = run {
                            val arrTags = o.optJSONArray("aiTags")
                            val out = mutableListOf<String>()
                            if (arrTags != null) {
                                for (t in 0 until arrTags.length()) out.add(arrTags.getString(t))
                            }
                            out
                        },
                        titleManuallyEdited = o.optBoolean("titleManuallyEdited", false)
                    )
                }
            } catch (_: Exception) {
            }
        }
        items.clear()
        items.addAll(list.sortedByDescending { it.addedAt })
    }

    private fun saveLibrary() {
        val key = master ?: return
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(
                JSONObject()
                    .put("id", item.id)
                    .put("title", item.title)
                    .put("kind", item.kind.name)
                    .put("hash", item.hash)
                    .put("size", item.sizeBytes)
                    .put("duration", item.durationMs)
                    .put("added", item.addedAt)
                    .put("keyWrap", item.keyWrap)
                    .put("collection", item.collection)
                    .put("favorite", item.favorite)
                    .put("progress", item.progressMs)
                    .put("lastOpened", item.lastOpened)
                    .put("thumb", item.hasThumb)
                    .put("tags", JSONArray(item.tags))
                    .put("description", item.description)
                    .put("aiTags", JSONArray(item.aiTags))
                    .put("titleManuallyEdited", item.titleManuallyEdited)
            )
        }
        libraryFile.writeBytes(Crypto.gcmEncrypt(key, arr.toString().toByteArray()))
    }

    private suspend fun persist() = withContext(Dispatchers.IO) { saveLibrary() }

    // ---------- files ----------

    fun mediaFile(item: VaultItem): File = File(mediaDir, item.id + ".bin")
    private fun thumbFile(id: String): File = File(thumbDir, "$id.bin")

    fun keyFor(item: VaultItem): SecretKey =
        Crypto.unwrapKey(master ?: error("locked"), item.keyWrap)

    // ---------- import ----------

    data class ImportResult(
        val added: Int,
        val duplicates: Int,
        val failed: Int,
        val addedIds: List<String> = emptyList()
    )

    data class AiAnalysisResult(
        val generated: Int,
        val failed: Int,
        val firstError: String? = null
    )

    suspend fun importMedia(uris: List<Uri>): ImportResult = withContext(Dispatchers.IO) {
        val key = master ?: return@withContext ImportResult(0, 0, uris.size)
        val resolver = appContext.contentResolver
        var added = 0
        var dupes = 0
        var failed = 0
        val addedIds = mutableListOf<String>()
        val known = items.map { it.hash }.toMutableSet()

        uris.forEachIndexed { index, uri ->
            withContext(Dispatchers.Main) {
                busyMessage.value = "Encrypting ${index + 1} of ${uris.size}"
            }
            try {
                val mime = resolver.getType(uri) ?: ""
                val kind = if (mime.startsWith("image")) MediaKind.PHOTO else MediaKind.VIDEO
                val name = displayName(uri) ?: "Untitled"
                val id = UUID.randomUUID().toString()
                val fileKey = Crypto.newKey()
                val dest = File(mediaDir, "$id.bin")

                val stream = resolver.openInputStream(uri)
                    ?: throw IllegalStateException("cannot read source")
                val (hash, size) = stream.use { input ->
                    Crypto.encryptToFile(input, dest, fileKey)
                }

                if (hash in known) {
                    // Same bytes already in the vault — never store or list it twice.
                    dest.delete()
                    dupes++
                    return@forEachIndexed
                }
                known += hash

                var duration = 0L
                var poster: Bitmap? = null
                if (kind == MediaKind.VIDEO) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(appContext, uri)
                        duration = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_DURATION
                        )?.toLongOrNull() ?: 0L
                        poster = retriever.getFrameAtTime(
                            (duration * 1000L) / 4,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                        )
                    } catch (_: Exception) {
                    } finally {
                        try { retriever.release() } catch (_: Exception) {}
                    }
                } else {
                    poster = decodeSampled(uri)
                }

                val hasThumb = poster != null
                if (poster != null) writeThumb(id, fileKey, poster)

                val item = VaultItem(
                    id = id,
                    title = name.substringBeforeLast('.').ifBlank { "Untitled" },
                    kind = kind,
                    hash = hash,
                    sizeBytes = size,
                    durationMs = duration,
                    addedAt = System.currentTimeMillis(),
                    keyWrap = Crypto.wrapKey(key, fileKey),
                    collection = DEFAULT_COLLECTION,
                    favorite = false,
                    progressMs = 0L,
                    lastOpened = 0L,
                    hasThumb = hasThumb
                )
                withContext(Dispatchers.Main) { items.add(0, item) }
                addedIds.add(id)
                added++
            } catch (e: Exception) {
                failed++
            }
        }
        saveLibrary()
        withContext(Dispatchers.Main) { busyMessage.value = null }
        ImportResult(added, dupes, failed, addedIds)
    }

    suspend fun aiModelReadiness(): ModelReadiness =
        withContext(Dispatchers.IO) { OnDeviceMetadata.readiness() }

    suspend fun downloadAiModel() = withContext(Dispatchers.IO) {
        try {
            OnDeviceMetadata.download { message ->
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    busyMessage.value = message
                }
            }
        } finally {
            withContext(NonCancellable + Dispatchers.Main) {
                busyMessage.value = null
            }
        }
    }

    suspend fun analyzeItems(ids: List<String>): AiAnalysisResult =
        withContext(Dispatchers.IO) {
            var generated = 0
            var failed = 0
            var firstError: String? = null
            val distinctIds = ids.distinct()

            try {
                distinctIds.forEachIndexed { index, id ->
                    withContext(Dispatchers.Main) {
                        busyMessage.value = "Generating on-device details ${index + 1} of ${distinctIds.size}"
                    }
                    try {
                        if (generateItemMetadata(id)) generated++ else failed++
                    } catch (e: Exception) {
                        failed++
                        if (firstError == null) firstError = e.message
                    }
                }
            } finally {
                withContext(NonCancellable + Dispatchers.Main) {
                    busyMessage.value = null
                }
            }
            AiAnalysisResult(generated, failed, firstError)
        }

    private suspend fun generateItemMetadata(id: String): Boolean {
        val item = items.firstOrNull { it.id == id } ?: return false
        val frames = mutableListOf<Bitmap>()
        try {
            when (item.kind) {
                MediaKind.PHOTO -> photo(item)?.let { frames += prepareAiBitmap(it) }
                MediaKind.VIDEO -> {
                    val positions = if (item.durationMs > 0L) {
                        listOf(15L, 50L, 85L).map { item.durationMs * it / 100L }.distinct()
                    } else {
                        listOf(0L)
                    }
                    positions.forEach { position ->
                        frameAt(item, position)?.let { frames += prepareAiBitmap(it) }
                    }
                }
            }
            if (frames.isEmpty()) throw IllegalStateException("Could not read media for on-device AI.")

            val metadata: AiMetadata = when (item.kind) {
                MediaKind.PHOTO -> OnDeviceMetadata.describePhoto(frames.first())
                MediaKind.VIDEO -> OnDeviceMetadata.describeVideo(frames)
            }
            val latest = items.firstOrNull { it.id == id } ?: return false
            withContext(Dispatchers.Main) {
                replace(
                    latest,
                    latest.copy(
                        title = if (latest.titleManuallyEdited) latest.title else metadata.title,
                        description = metadata.description,
                        aiTags = metadata.tags
                    )
                )
            }
            return true
        } finally {
            frames.forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    private fun prepareAiBitmap(bitmap: Bitmap): Bitmap {
        val largestSide = maxOf(bitmap.width, bitmap.height)
        if (largestSide <= 1024) return bitmap
        val scale = 1024f / largestSide
        val resized = Bitmap.createScaledBitmap(
            bitmap,
            (bitmap.width * scale).toInt().coerceAtLeast(1),
            (bitmap.height * scale).toInt().coerceAtLeast(1),
            true
        )
        if (resized !== bitmap && !bitmap.isRecycled) bitmap.recycle()
        return resized
    }

    private fun displayName(uri: Uri): String? {
        return try {
            appContext.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun decodeSampled(uri: Uri, max: Int = 1280): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            var sample = 1
            var w = bounds.outWidth
            var h = bounds.outHeight
            while (w / sample > max || h / sample > max) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun writeThumb(id: String, fileKey: SecretKey, bitmap: Bitmap) {
        val scaled = scaleTo(bitmap, 960)
        val bos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 88, bos)
        val bytes = bos.toByteArray()
        Crypto.encryptToFile(bytes.inputStream(), thumbFile(id), fileKey)
        thumbCache.remove(id)
    }

    private fun scaleTo(src: Bitmap, maxDim: Int): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= maxDim && h <= maxDim) return src
        val ratio = minOf(maxDim.toFloat() / w, maxDim.toFloat() / h)
        return Bitmap.createScaledBitmap(src, (w * ratio).toInt(), (h * ratio).toInt(), true)
    }

    // ---------- reading ----------

    suspend fun thumbnail(item: VaultItem): Bitmap? = withContext(Dispatchers.IO) {
        thumbCache.get(item.id)?.let { return@withContext it }
        if (!item.hasThumb || master == null) return@withContext null
        try {
            val bytes = Crypto.decryptFile(thumbFile(item.id), keyFor(item))
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bmp != null) thumbCache.put(item.id, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    suspend fun photo(item: VaultItem): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val bytes = Crypto.decryptFile(mediaFile(item), keyFor(item))
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            null
        }
    }

    /** Pulls a frame out of the still-encrypted video, for the thumbnail picker. */
    suspend fun frameAt(item: VaultItem, positionMs: Long): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        var source: EncryptedMediaDataSource? = null
        try {
            source = EncryptedMediaDataSource(mediaFile(item), keyFor(item))
            retriever.setDataSource(source)
            retriever.getFrameAtTime(positionMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
            try { source?.close() } catch (_: Exception) {}
        }
    }

    // ---------- edits ----------

    private suspend fun replace(item: VaultItem, updated: VaultItem) {
        val index = items.indexOfFirst { it.id == item.id }
        if (index >= 0) items[index] = updated
        persist()
    }

    suspend fun rename(item: VaultItem, title: String) =
        replace(
            item,
            item.copy(
                title = title.trim().ifBlank { item.title },
                titleManuallyEdited = true
            )
        )

    suspend fun setCollection(item: VaultItem, collection: String) =
        replace(item, item.copy(collection = collection.trim().ifBlank { DEFAULT_COLLECTION }))

    suspend fun toggleFavorite(item: VaultItem) =
        replace(item, item.copy(favorite = !item.favorite))

    suspend fun setProgress(item: VaultItem, positionMs: Long, durationMs: Long) {
        val fresh = items.firstOrNull { it.id == item.id } ?: return
        replace(
            fresh,
            fresh.copy(
                progressMs = positionMs,
                durationMs = if (durationMs > 0) durationMs else fresh.durationMs,
                lastOpened = System.currentTimeMillis()
            )
        )
    }

    suspend fun clearProgress(item: VaultItem) = replace(item, item.copy(progressMs = 0L))

    suspend fun setThumbnail(item: VaultItem, bitmap: Bitmap) {
        withContext(Dispatchers.IO) { writeThumb(item.id, keyFor(item), bitmap) }
        replace(item, item.copy(hasThumb = true))
    }

    suspend fun setThumbnailFromUri(item: VaultItem, uri: Uri) {
        val bmp = withContext(Dispatchers.IO) { decodeSampled(uri) } ?: return
        setThumbnail(item, bmp)
    }

    suspend fun delete(item: VaultItem) = withContext(Dispatchers.IO) {
        mediaFile(item).delete()
        thumbFile(item.id).delete()
        thumbCache.remove(item.id)
        withContext(Dispatchers.Main) { items.removeAll { it.id == item.id } }
        saveLibrary()
    }

    fun collections(): List<String> =
        items.map { it.collection }.distinct().sortedBy { it.lowercase() }

    fun countIn(collection: String): Int = items.count { it.collection == collection }

    fun tags(): List<String> =
        items.flatMap { it.allTags }.distinct().sortedBy { it.lowercase() }

    fun itemsIn(collection: String): List<VaultItem> =
        items.filter { it.collection == collection }.sortedByDescending { it.addedAt }

    fun itemsTagged(tag: String): List<VaultItem> =
        items.filter { item -> item.allTags.any { it.equals(tag, ignoreCase = true) } }
            .sortedByDescending { it.addedAt }

    /** Cover art for a folder tile — first item in it that actually has artwork. */
    fun coverOf(collection: String): VaultItem? =
        items.firstOrNull { it.collection == collection && it.hasThumb }
            ?: items.firstOrNull { it.collection == collection }

    suspend fun setTags(item: VaultItem, tags: List<String>) {
        val cleaned = tags.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        replace(item, item.copy(tags = cleaned))
    }

    suspend fun removeTag(item: VaultItem, tag: String) {
        val fresh = items.firstOrNull { it.id == item.id } ?: return
        replace(
            fresh,
            fresh.copy(
                tags = fresh.tags.filterNot { it.equals(tag, ignoreCase = true) },
                aiTags = fresh.aiTags.filterNot { it.equals(tag, ignoreCase = true) }
            )
        )
    }

    suspend fun addTagTo(ids: Set<String>, tag: String) {
        val clean = tag.trim()
        if (clean.isBlank()) return
        ids.forEach { id ->
            val index = items.indexOfFirst { it.id == id }
            if (index >= 0) {
                val current = items[index]
                if (current.allTags.none { it.equals(clean, ignoreCase = true) }) {
                    items[index] = current.copy(tags = current.tags + clean)
                }
            }
        }
        persist()
    }

    suspend fun moveToCollection(ids: Set<String>, collection: String) {
        val name = collection.trim().ifBlank { DEFAULT_COLLECTION }
        ids.forEach { id ->
            val index = items.indexOfFirst { it.id == id }
            if (index >= 0) items[index] = items[index].copy(collection = name)
        }
        persist()
    }

    suspend fun deleteMany(ids: Set<String>) {
        ids.mapNotNull { id -> items.firstOrNull { it.id == id } }.forEach { delete(it) }
    }

    /** Renaming a folder just re-labels its items — nothing is re-encrypted. */
    suspend fun renameCollection(from: String, to: String) {
        val name = to.trim().ifBlank { return }
        items.indices.forEach { index ->
            if (items[index].collection == from) items[index] = items[index].copy(collection = name)
        }
        persist()
    }

    /** Removing a folder never removes media — the items fall back to the default folder. */
    suspend fun deleteCollection(name: String) {
        if (name == DEFAULT_COLLECTION) return
        items.indices.forEach { index ->
            if (items[index].collection == name) {
                items[index] = items[index].copy(collection = DEFAULT_COLLECTION)
            }
        }
        persist()
    }
}
