# Netscape

An offline, fully encrypted video and photo vault for Android, with a cinematic browse experience —
hero billboard, content rails, resume-where-you-left-off, artwork you control.

Nothing leaves the device. There is no network permission in the manifest at all.

## Security model

| Layer | What happens |
|---|---|
| Passphrase | PBKDF2-HMAC-SHA256, 150,000 iterations, 16-byte random salt → 256-bit master key. Never stored. |
| Per-item key | Every video and photo gets its own random 256-bit key, wrapped with the master key using AES-GCM. |
| Media payload | AES-256-CTR, random 16-byte IV per file. CTR is used so the player can seek instantly without decrypting the whole file. |
| Thumbnails & index | AES-256-GCM (authenticated). The library index itself is encrypted, so filenames and titles are unreadable at rest. |
| On screen | `FLAG_SECURE` — no screenshots, blank in the recent-apps switcher. |
| Playback | A custom ExoPlayer `DataSource` decrypts in memory as it streams. No temp file is ever written in the clear. |
| Auto-lock | The vault locks itself the moment the app goes to the background. |

Files live in the app's private storage (`/data/data/com.netscape.vault/files/vault`) — invisible to the
gallery, to other apps, and to anyone with the phone but not the passphrase.

**There is no recovery.** Lose the passphrase, lose the vault. That is the point.

## Features

### Look & feel
- iOS-inspired dark UI with a Netflix browse experience: big billboard, genre line, rails, spring press animations, frosted tab bar
- Tabs: **Home · Library · Explore · Search · Settings**
- Seven accent colours, 1–4 column grids, default sort, billboard on/off

### Tags (15 groups, ~450 presets)
- Spicy Categories, Who's In It, Type & Format, Positions, Acts, Body Focus, Look & Body Type,
  Outfit & Lingerie, Kink & Fetish, Toys & Props, Setting & Place, Mood & Vibe, Camera & Style,
  Time & Occasion, People — every tag has its own emoji
- Add your own tags to any group; hide groups you never use
- 🎂 **Age** group: Young Adult · Adult · Mature
- Auto-detected tags: length, 4K / Full HD / HD, portrait / landscape, unwatched
- Bulk tagging, rating, moving and deleting from any grid (long-press to select)

### Automatic titles & descriptions
- Written on import and rewritten when tags change (titles you type yourself are never touched)
- Styles: Spicy 🌶️, Flirty 😘, Classy 🥂, Playful 😜, Minimal, or your own template with
  `{emoji} {adj} {position} {setting} {person} {age} {n} …` tokens
- Emoji amount: none / some / lots; ✨ regenerate any title or description with one tap

### Browse & find
- Home rails: Continue Watching, Top Rated, Recently Added, My List, one per category, Most Watched,
  your folders, Not Watched Yet, Photos — each title appears once
- 🎲 Surprise me, category picker, star ratings, view counts
- Search titles, descriptions, tags and moments; filter sheet with include / exclude tags and
  minimum rating; eight sort orders including shuffle
- Explore: category tiles, folders and every tag in use

### Player & viewer
- Save **moments** while watching (e.g. 2:14 → Cowgirl) — shown on the seek bar, tap to jump
- ±10 s skip, playback speed, mute toggle, resume where you left off
- Photo viewer: swipe between photos, pinch or double-tap zoom, slideshow

### Offline AI tagging (optional AI pack)
- **NSFW classifier** (ViT) → 🌡️ Heat Level: Mild / Sexy / Explicit
- **NudeNet** body-part detector → Body Focus, Topless / Naked, face visible, who's in it
- **CLIP** zero-shot → setting, positions, acts, outfit, look, mood, camera, toys — works with your own custom tags too
- ✨ Suggest tags on any item (with confidence %), bulk AI-tag a selection, or auto-tag new imports
- **SmolVLM2-500M Q8_0** → optional scene-specific title, allow-listed catalog tags, and non-graphic description proposals from up to three frames
- Scene drafts are editable and require an explicit save/add action; free-form sexual narration and auto-apply are not used
- Strict / Balanced / Loose sensitivity; nothing is uploaded — frames are decrypted in memory only
- Install: download `Netscape-AI-Pack.zip` from the repo's Releases ("Netscape AI pack"), then
  Settings → AI models → Install AI pack. The pack is built by `.github/workflows/ai-pack.yml`
  from pinned model sources and verified before publishing. SmolVLM2 runs through the experimental
  llama.cpp multimodal API on CPU; memory use, speed, heat, and suggestion quality still need
  real-device testing on the Infinix GT 50 Pro.

### Privacy
- Blur thumbnails, discreet mode (neutral titles, no tags or emojis), start videos muted
- Change passphrase from Settings
- Crash-safe saving: the library is written atomically with a backup copy, and a damaged index is
  never overwritten

## Build the APK on GitHub (phone only, zip stays zipped)

You upload two things and never unzip anything yourself.

1. Create a new GitHub repo (private is fine).
2. **Add file -> Upload files** -> drop `Netscape-source.zip` in as-is. Commit.
3. **Add file -> Create new file** -> type the filename exactly:
   `.github/workflows/build.yml`
   (typing the slashes creates the folders). Paste in the contents of the `build.yml`
   that came with this project. Commit.

That second commit starts the build immediately. The workflow finds the zip in the repo
root, unpacks it, locates the Gradle project inside, and builds it.

When it finishes (~4-6 min), go to **Releases** on the repo — the APK is attached there as a
plain `Netscape.apk` you can tap and install straight from your phone browser. (It is also
under Actions -> the run -> Artifacts, if you prefer.)

To update later: replace the zip with a new one and commit. Nothing else changes.

## Notes

- Minimum Android 8.0 (API 26).
- The first launch asks you to create a passphrase. Type it carefully; there is no reset.
- Importing uses the system file picker, so the app requests **zero runtime permissions**.
- Originals are left where they are — delete them from your gallery yourself once you have verified the import.
