#include <jni.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdint>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <vector>

#include "llama.h"
#include "mtmd.h"
#include "mtmd-helper.h"

namespace {
constexpr int32_t kContext = 2048;
constexpr int32_t kMaxFrames = 3;
constexpr int32_t kMaxOutput = 96;
constexpr auto kGenerationDeadline = std::chrono::seconds(60);

struct GenerationDeadline {
    const std::chrono::steady_clock::time_point expires_at =
        std::chrono::steady_clock::now() + kGenerationDeadline;
    std::atomic<bool> expired{false};

    bool has_expired() {
        if (expired.load(std::memory_order_relaxed)) return true;
        if (std::chrono::steady_clock::now() < expires_at) return false;
        expired.store(true, std::memory_order_relaxed);
        return true;
    }

    void check() {
        if (has_expired()) {
            throw std::runtime_error("SmolVLM generation exceeded the 60-second deadline");
        }
    }
};

bool abort_generation(void * data) {
    return static_cast<GenerationDeadline *>(data)->has_expired();
}

struct Session {
    llama_model * model = nullptr;
    llama_context * context = nullptr;
    mtmd_context * vision = nullptr;
    llama_sampler * sampler = nullptr;
    std::mutex mutex;

    ~Session() {
        if (sampler) llama_sampler_free(sampler);
        if (vision) mtmd_free(vision);
        if (context) llama_free(context);
        if (model) llama_model_free(model);
    }
};

void fail(JNIEnv * env, const char * message) {
    jclass cls = env->FindClass("java/lang/IllegalStateException");
    env->ThrowNew(cls, message);
}

void fail(JNIEnv * env, const std::string & message) { fail(env, message.c_str()); }

Session * get(JNIEnv * env, jlong handle) {
    if (handle == 0) {
        fail(env, "SmolVLM handle is closed");
        return nullptr;
    }
    return reinterpret_cast<Session *>(handle);
}

std::string piece(llama_context * ctx, llama_token token) {
    std::string out;
    char buf[256];
    const llama_vocab * vocab = llama_model_get_vocab(llama_get_model(ctx));
    const int n = llama_token_to_piece(vocab, token, buf, sizeof(buf), 0, true);
    if (n > 0) out.assign(buf, n);
    return out;
}
} // namespace

extern "C" JNIEXPORT jlong JNICALL
Java_com_netscape_vault_ai_NativeSmolVlm_nativeOpen(
        JNIEnv * env, jobject, jstring model_path, jstring mmproj_path, jint threads) {
    if (!model_path || !mmproj_path) {
        fail(env, "modelPath and mmprojPath are required");
        return 0;
    }
    const char * model = env->GetStringUTFChars(model_path, nullptr);
    const char * mmproj = env->GetStringUTFChars(mmproj_path, nullptr);
    if (!model || !mmproj) {
        if (model) env->ReleaseStringUTFChars(model_path, model);
        if (mmproj) env->ReleaseStringUTFChars(mmproj_path, mmproj);
        fail(env, "Could not read model paths");
        return 0;
    }
    std::unique_ptr<Session> s(new Session());
    const int n_threads = std::max(1, static_cast<int>(threads));
    llama_backend_init();
    llama_model_params mp = llama_model_default_params();
    mp.n_gpu_layers = 0; // CPU-only prototype.
    s->model = llama_model_load_from_file(model, mp);
    if (!s->model) {
        env->ReleaseStringUTFChars(model_path, model);
        env->ReleaseStringUTFChars(mmproj_path, mmproj);
        fail(env, "Unable to load GGUF model");
        return 0;
    }
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = kContext;
    cp.n_batch = kContext;
    cp.n_threads = n_threads;
    cp.n_threads_batch = n_threads;
    s->context = llama_init_from_model(s->model, cp);
    if (!s->context) {
        env->ReleaseStringUTFChars(model_path, model);
        env->ReleaseStringUTFChars(mmproj_path, mmproj);
        fail(env, "Unable to create llama context");
        return 0;
    }
    // llama.cpp mtmd is experimental; keep this bridge isolated and opt-in.
    mtmd_context_params vp = mtmd_context_params_default();
    vp.use_gpu = false;
    vp.n_threads = n_threads;
    s->vision = mtmd_init_from_file(mmproj, s->model, vp);
    env->ReleaseStringUTFChars(model_path, model);
    env->ReleaseStringUTFChars(mmproj_path, mmproj);
    if (!s->vision) {
        fail(env, "Unable to load mmproj file");
        return 0;
    }
    return reinterpret_cast<jlong>(s.release());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_netscape_vault_ai_NativeSmolVlm_nativeGenerate(
        JNIEnv * env, jobject, jlong handle, jstring prompt, jintArray widths,
        jintArray heights, jobjectArray frame_arrays, jint max_tokens) {
    Session * s = get(env, handle);
    if (!s || !prompt || !widths || !heights || !frame_arrays) return nullptr;
    std::lock_guard<std::mutex> lock(s->mutex);
    const char * p = env->GetStringUTFChars(prompt, nullptr);
    if (!p) { fail(env, "Could not read prompt"); return nullptr; }
    const jsize count = env->GetArrayLength(frame_arrays);
    if (count < 1 || count > kMaxFrames ||
        env->GetArrayLength(widths) != count || env->GetArrayLength(heights) != count) {
        env->ReleaseStringUTFChars(prompt, p);
        fail(env, "Expected one to three frames and matching dimensions");
        return nullptr;
    }
    std::vector<jint> ws(count), hs(count);
    env->GetIntArrayRegion(widths, 0, count, ws.data());
    env->GetIntArrayRegion(heights, 0, count, hs.data());
    std::vector<mtmd_bitmap *> bitmaps;
    mtmd_input_chunks * chunks = nullptr;
    std::string result;
    GenerationDeadline deadline;
    // The callback can interrupt CPU llama_decode(), including decodes inside
    // mtmd_helper_eval_chunks. mtmd tokenization/vision encoding may only be
    // checked when those calls return; model loading is outside this deadline.
    llama_set_abort_callback(s->context, abort_generation, &deadline);
    try {
        std::vector<const mtmd_bitmap *> bitmap_ptrs;
        bitmap_ptrs.reserve(count);
        for (jsize i = 0; i < count; ++i) {
            deadline.check();
            if (ws[i] <= 0 || hs[i] <= 0 ||
                static_cast<int64_t>(ws[i]) * hs[i] > 16 * 1024 * 1024) {
                throw std::runtime_error("Invalid frame dimensions");
            }
            auto pixels = static_cast<jintArray>(env->GetObjectArrayElement(frame_arrays, i));
            if (!pixels || env->GetArrayLength(pixels) != ws[i] * hs[i])
                throw std::runtime_error("ARGB frame length does not match dimensions");
            std::vector<jint> argb(static_cast<size_t>(ws[i]) * hs[i]);
            env->GetIntArrayRegion(pixels, 0, argb.size(), argb.data());
            env->DeleteLocalRef(pixels);
            std::vector<uint8_t> rgba(argb.size() * 3);
            for (size_t j = 0; j < argb.size(); ++j) {
                rgba[j * 3] = (argb[j] >> 16) & 255;
                rgba[j * 3 + 1] = (argb[j] >> 8) & 255;
                rgba[j * 3 + 2] = argb[j] & 255;
            }
            mtmd_bitmap * bitmap = mtmd_bitmap_init(ws[i], hs[i], rgba.data());
            if (!bitmap) throw std::runtime_error("Could not create image input");
            bitmaps.push_back(bitmap);
            bitmap_ptrs.push_back(bitmap);
        }
        // The verified Hugging Face template for
        // HuggingFaceTB/SmolVLM2-500M-Video-Instruct is:
        // <|im_start|>User:{content}<end_of_utterance>\nAssistant:
        // Use mtmd's marker here; mtmd replaces it with the model's image
        // chunk while parse_special handles the ChatML control tokens.
        std::string formatted = "<|im_start|>User:";
        for (jsize i = 0; i < count; ++i) {
            formatted += mtmd_default_marker();
        }
        formatted += p;
        formatted += "<end_of_utterance>\nAssistant:";
        mtmd_input_text text{
            formatted.c_str(), formatted.size(), true, true
        };
        deadline.check();
        chunks = mtmd_input_chunks_init();
        if (!chunks) throw std::runtime_error("Could not create multimodal input chunks");
        const int tokenize_status =
            mtmd_tokenize(s->vision, chunks, &text, bitmap_ptrs.data(), bitmap_ptrs.size());
        deadline.check();
        if (tokenize_status != 0)
            throw std::runtime_error("Multimodal tokenization failed");
        llama_memory_clear(llama_get_memory(s->context), true);
        llama_pos n_past = 0;
        deadline.check();
        const int eval_status = mtmd_helper_eval_chunks(s->vision, s->context, chunks, n_past, 0,
                                                         kContext, true, &n_past);
        deadline.check();
        if (eval_status != 0)
            throw std::runtime_error("Multimodal image/text evaluation failed");
        const int limit = std::clamp(static_cast<int>(max_tokens), 1, kMaxOutput);
        s->sampler = llama_sampler_init_greedy();
        if (!s->sampler) throw std::runtime_error("Could not create sampler");
        for (int i = 0; i < limit; ++i) {
            deadline.check();
            const llama_token token = llama_sampler_sample(s->sampler, s->context, -1);
            deadline.check();
            if (llama_vocab_is_eog(llama_model_get_vocab(s->model), token)) break;
            result += piece(s->context, token);
            deadline.check();
            llama_sampler_accept(s->sampler, token);
            llama_token next_token = token;
            llama_batch next = llama_batch_get_one(&next_token, 1);
            const int decode_status = llama_decode(s->context, next);
            deadline.check();
            if (decode_status != 0) throw std::runtime_error("Token inference failed");
        }
        deadline.check();
    } catch (const std::exception & e) {
        result.clear();
        fail(env, e.what());
    }
    // Ensure no compute thread can still use stack-owned callback data.
    llama_synchronize(s->context);
    llama_set_abort_callback(s->context, nullptr, nullptr);
    // Reuse model weights, not the previous item's image/text context.
    llama_memory_clear(llama_get_memory(s->context), true);
    if (chunks) mtmd_input_chunks_free(chunks);
    for (auto * bitmap : bitmaps) mtmd_bitmap_free(bitmap);
    if (s->sampler) { llama_sampler_free(s->sampler); s->sampler = nullptr; }
    env->ReleaseStringUTFChars(prompt, p);
    return env->ExceptionCheck() ? nullptr : env->NewStringUTF(result.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_netscape_vault_ai_NativeSmolVlm_nativeClose(JNIEnv *, jobject, jlong handle) {
    delete reinterpret_cast<Session *>(handle);
}