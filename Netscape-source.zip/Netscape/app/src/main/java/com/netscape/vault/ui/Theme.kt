package com.netscape.vault.ui

import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.Vault

data class Accent(val name: String, val color: Color, val deep: Color)

/**
 * iOS dark palette (true-black background, grouped grey surfaces, hairline separators)
 * with a Netflix-style accent the user can change in Settings.
 */
object Brand {
    val accents = listOf(
        Accent("Netscape Red", Color(0xFFE50914), Color(0xFF8E0C1B)),
        Accent("Hot Pink", Color(0xFFFF2D78), Color(0xFF8A1240)),
        Accent("Velvet Purple", Color(0xFFBF5AF2), Color(0xFF5E2A7A)),
        Accent("Sunset Orange", Color(0xFFFF7A1A), Color(0xFF8A3A06)),
        Accent("Gold", Color(0xFFF5B942), Color(0xFF7A5510)),
        Accent("Ocean", Color(0xFF0A84FF), Color(0xFF06427F)),
        Accent("Emerald", Color(0xFF30D158), Color(0xFF14602A))
    )

    private val accent: Accent
        get() = accents[Vault.settings.value.accent.coerceIn(0, accents.lastIndex)]

    /** Accent colour — named Red for history; follows the user's choice. */
    val Red: Color get() = accent.color
    val RedDeep: Color get() = accent.deep

    val Ink = Color(0xFF000000)
    val Surface = Color(0xFF1C1C1E)
    val SurfaceHigh = Color(0xFF2C2C2E)
    val SurfaceHigher = Color(0xFF3A3A3C)
    val Muted = Color(0xFF8E8E93)
    val Line = Color(0xFF38383A)
    val Label = Color(0xFFF2F2F7)
    val Star = Color(0xFFFFCC00)
}

private val typography = Typography(
    displaySmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 34.sp, letterSpacing = 0.2.sp),
    headlineSmall = TextStyle(fontWeight = FontWeight.Bold, fontSize = 28.sp),
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = 0.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp),
    bodyLarge = TextStyle(fontSize = 17.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
)

@Composable
fun NetscapeTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Brand.Red,
        onPrimary = Color.White,
        secondary = Brand.Red,
        background = Brand.Ink,
        onBackground = Color.White,
        surface = Brand.Surface,
        onSurface = Color.White,
        surfaceVariant = Brand.SurfaceHigh,
        onSurfaceVariant = Brand.Muted,
        outline = Brand.Line,
        error = Color(0xFFFF453A)
    )
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}

/**
 * Original Netscape wordmark: heavy condensed caps, accent colour, long shadow.
 * Drawn in code so there is no bitmap asset to leak the app's contents.
 */
@Composable
fun NetscapeWordmark(
    modifier: Modifier = Modifier,
    fontSize: TextUnit = 26.sp,
    compact: Boolean = false
) {
    Row(modifier = modifier) {
        Text(
            text = if (compact) "N" else "NETSCAPE",
            color = Brand.Red,
            textAlign = TextAlign.Start,
            style = TextStyle(
                fontSize = fontSize,
                fontWeight = FontWeight.Black,
                letterSpacing = (-0.5).sp,
                shadow = Shadow(
                    color = Brand.RedDeep,
                    offset = Offset(2f, 3f),
                    blurRadius = 6f
                )
            )
        )
    }
}
