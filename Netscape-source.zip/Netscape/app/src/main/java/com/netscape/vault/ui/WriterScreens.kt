package com.netscape.vault.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.ai.AiService
import com.netscape.vault.ai.WriterPrompt
import com.netscape.vault.ai.WriterService
import com.netscape.vault.data.TitleGenerator
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch
import java.util.Locale

/** Settings → "AI writer" section: install the Writer pack and choose background writing. */
@Composable
fun WriterSettingsSection() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val st = WriterService.status.value
    val s = Vault.settings.value
    var installing by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var confirmRemove by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        Vault.suppressAutoLock = false
        if (uri != null) {
            installing = true
            AiService.appScope.launch {
                val e = WriterService.install(uri)
                installing = false
                if (e == null) Toast.makeText(context, "✍️ AI writer installed", Toast.LENGTH_LONG).show() else error = e
            }
        }
    }

    GroupedSection(
        header = "AI writer (offline)",
        footer = if (st.installed)
            "Writes titles and descriptions from each item's tags in your title style (Settings → Style). Runs on this phone; nothing is uploaded."
        else
            "Download Netscape-Writer-Pack.zip from Releases → \"Netscape Writer pack\", then tap Install. Without it, the built-in template writer is used."
    ) {
        GroupedRow(
            "Qwen2.5 1.5B writer", icon = Icons.Rounded.Edit, iconTint = Color(0xFFFF2D78),
            value = if (st.installed) "✅ Installed" else "Not installed"
        )
        GroupedRow(
            title = if (installing) {
                WriterService.installProgress.value?.let { "Installing… ${(it * 100).toInt()}%" } ?: "Installing…"
            } else if (st.installed) "Reinstall / update writer" else "Install Writer pack (.zip)",
            icon = Icons.Rounded.Download,
            iconTint = Color(0xFF0A84FF),
            value = if (st.installed) String.format(Locale.US, "%.0f MB", st.bytes / 1e6) else null,
            showDivider = st.installed,
            onClick = {
                if (!installing) {
                    Vault.suppressAutoLock = true
                    picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                }
            },
            trailing = {
                if (installing) CircularProgressIndicator(color = Brand.Red, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                else Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Brand.Muted, modifier = Modifier.size(20.dp))
            }
        )
        if (st.installed) {
            ToggleRow("Write new imports in the background", s.aiAutoWrite, icon = Icons.Rounded.AutoAwesome, iconTint = Color(0xFF30D158)) { v ->
                scope.launch { Vault.updateSettings { it.copy(aiAutoWrite = v) } }
            }
            GroupedRow("Remove AI writer", icon = Icons.Rounded.Delete, iconTint = Color(0xFF8E8E93), titleColor = Color(0xFFFF453A), showDivider = false, onClick = { confirmRemove = true })
        }
    }

    error?.let { msg ->
        AlertDialog(
            onDismissRequest = { error = null },
            containerColor = Brand.Surface,
            title = { Text("Couldn't install the writer", color = Color.White) },
            text = { Text(msg, color = Brand.Muted) },
            confirmButton = { TextButton(onClick = { error = null }) { Text("OK", color = Brand.Red, fontWeight = FontWeight.Bold) } }
        )
    }
    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            containerColor = Brand.Surface,
            title = { Text("Remove the AI writer?", color = Color.White) },
            text = { Text("Frees ${String.format(Locale.US, "%.0f MB", st.bytes / 1e6)}. Titles already written stay.", color = Brand.Muted) },
            confirmButton = {
                TextButton(onClick = { confirmRemove = false; scope.launch { WriterService.remove() } }) {
                    Text("Remove", color = Color(0xFFFF453A), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel", color = Color.White) } }
        )
    }
}

/**
 * Streams a fresh title + description from the AI writer. The text appears as it is written;
 * "Use this" saves it, "Again" writes another take.
 */
@Composable
fun WriterSheet(item: VaultItem, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    var raw by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<WriterPrompt.Result?>(null) }
    var running by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf<String?>(null) }
    var take by remember { mutableStateOf(0) }

    LaunchedEffect(take) {
        running = true
        failed = null
        result = null
        raw = ""
        try {
            result = WriterService.write(item) { raw = it }
        } catch (e: Throwable) {
            if (e !is kotlinx.coroutines.CancellationException) failed = e.message ?: e.javaClass.simpleName
        } finally {
            running = false
        }
    }
    // Closing the sheet stops the model straight away.
    DisposableEffect(Unit) { onDispose { WriterService.cancel() } }

    val live = remember(raw) { WriterPrompt.parse(raw.removePrefix("TITLE:")) }
    val shown = result ?: live
    fun clean(t: String) = if (s.emojiLevel == 0) TitleGenerator.stripEmoji(t) else t

    Sheet(onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 36.dp)
        ) {
            Row {
                Text("✍️ AI writer", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (running) CircularProgressIndicator(color = Brand.Red, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
            }
            Text(
                "Voice: ${s.titleStyle.label} · change it in Settings → Style",
                color = Brand.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 14.dp)
            )
            Text(
                clean(shown.title).ifBlank { if (running) "Writing…" else "" },
                color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold
            )
            Text(
                clean(shown.description),
                color = Brand.Label, fontSize = 15.sp, lineHeight = 21.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
            failed?.let { Text("Couldn't write: $it", color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SecondaryButton(if (running) "Stop" else "Again", modifier = Modifier.weight(1f)) {
                    if (running) WriterService.cancel() else take++
                }
                PrimaryButton(
                    "Use this",
                    enabled = !running && shown.title.isNotBlank() && shown.description.isNotBlank(),
                    modifier = Modifier.weight(2f)
                ) {
                    val r = shown
                    scope.launch {
                        Vault.saveDetails(item.id, r.title, r.description, item.rating, titleIsAuto = true)
                        onDismiss()
                    }
                }
            }
        }
    }
}
