package com.netscape.vault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem

@Composable
fun HomeScreen(
    onOpen: (VaultItem) -> Unit,
    onDetails: (VaultItem) -> Unit,
    onAdd: () -> Unit,
    onSearch: () -> Unit,
    onLock: () -> Unit
) {
    val all = Vault.items.toList()
    val used = HashSet<String>()

    val hero = all.firstOrNull { it.kind == MediaKind.VIDEO && it.hasThumb }
        ?: all.firstOrNull { it.hasThumb }
        ?: all.firstOrNull()
    hero?.let { used.add(it.id) }

    fun fresh(source: List<VaultItem>): List<VaultItem> =
        source.filter { used.add(it.id) }

    // Each title appears in exactly one rail — no repeated rows of the same video.
    val continueWatching = fresh(all.filter { it.inProgress }.sortedByDescending { it.lastOpened }.take(20))
    val recentlyAdded = fresh(all.sortedByDescending { it.addedAt }.take(20))
    val favorites = fresh(all.filter { it.favorite })
    val collectionRails = Vault.collections()
        .filter { it != Vault.DEFAULT_COLLECTION }
        .map { name -> name to fresh(all.filter { it.collection == name }) }
        .filter { it.second.isNotEmpty() }
    val photos = fresh(all.filter { it.kind == MediaKind.PHOTO })
    val rest = fresh(all)

    Box(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        LazyColumn(contentPadding = PaddingValues(bottom = 110.dp)) {
            item {
                if (hero != null) {
                    Billboard(hero, onPlay = { onOpen(hero) }, onInfo = { onDetails(hero) })
                } else {
                    EmptyVault(onAdd)
                }
            }
            item { Rail("Continue Watching", continueWatching, onDetails) }
            item { Rail("Recently Added", recentlyAdded, onDetails) }
            item { Rail("My List", favorites, onDetails) }
            for (pair in collectionRails) {
                item { Rail(pair.first, pair.second, onDetails) }
            }
            item { Rail("Photos", photos, onDetails) }
            item { Rail("Everything Else", rest, onDetails) }
        }

        // Floating top bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Black.copy(alpha = 0.85f), Color.Transparent)
                    )
                )
                .padding(start = 16.dp, end = 6.dp, top = 14.dp, bottom = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NetscapeWordmark(fontSize = 22.sp)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onSearch) {
                Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White)
            }
            IconButton(onClick = onAdd) {
                Icon(Icons.Filled.Add, contentDescription = "Add media", tint = Color.White)
            }
            IconButton(onClick = onLock) {
                Icon(Icons.Filled.Lock, contentDescription = "Lock", tint = Color.White)
            }
        }
    }
}

@Composable
private fun Billboard(item: VaultItem, onPlay: () -> Unit, onInfo: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.82f)
    ) {
        ThumbImage(item, Modifier.fillMaxSize())
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.55f),
                        0.45f to Color.Transparent,
                        0.82f to Brand.Ink.copy(alpha = 0.85f),
                        1f to Brand.Ink
                    )
                )
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = item.title,
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = buildString {
                    append(if (item.kind == MediaKind.PHOTO) "Photo" else "Video")
                    if (item.durationMs > 0) append("  •  ${formatDuration(item.durationMs)}")
                    append("  •  ${item.collection}")
                },
                color = Brand.Muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = onPlay,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.Black)
                    Text(
                        text = if (item.kind == MediaKind.PHOTO) "View" else "Play",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(start = 6.dp)
                    )
                }
                OutlinedButton(
                    onClick = onInfo,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Filled.Info, contentDescription = null, tint = Color.White)
                    Text("Info", color = Color.White, modifier = Modifier.padding(start = 6.dp))
                }
            }
        }
    }
}

@Composable
private fun EmptyVault(onAdd: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(520.dp)
            .padding(horizontal = 28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Brand.Surface)
                .clickable(onClick = onAdd),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(38.dp))
        }
        Text(
            text = "Your vault is empty",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 20.dp)
        )
        Text(
            text = "Add videos and photos — they are encrypted the moment they land here.",
            color = Brand.Muted,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp)
        )
        Button(
            onClick = onAdd,
            colors = ButtonDefaults.buttonColors(containerColor = Brand.Red),
            modifier = Modifier.padding(top = 20.dp)
        ) { Text("Add media") }
    }
}
