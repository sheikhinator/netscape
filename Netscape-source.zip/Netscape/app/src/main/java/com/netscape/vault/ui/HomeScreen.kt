package com.netscape.vault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Casino
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.AutoTags
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.TagCatalog
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onOpen: (VaultItem) -> Unit,
    onDetails: (VaultItem) -> Unit,
    onAdd: () -> Unit,
    onOpenTag: (String) -> Unit,
    onSurprise: () -> Unit,
    onLock: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    var filter by rememberSaveable { mutableStateOf(0) } // 0 all, 1 videos, 2 photos
    var categoriesOpen by remember { mutableStateOf(false) }

    val all = Vault.items.toList().filter {
        when (filter) {
            1 -> it.kind == MediaKind.VIDEO
            2 -> it.kind == MediaKind.PHOTO
            else -> true
        }
    }
    val used = HashSet<String>()

    val hero = if (!s.showBillboard) null else
        (all.filter { it.hasThumb && it.favorite }.maxByOrNull { it.rating }
            ?: all.filter { it.hasThumb }.maxByOrNull { it.rating * 10 + if (it.kind == MediaKind.VIDEO) 1 else 0 }
            ?: all.firstOrNull())
    hero?.let { used.add(it.id) }

    fun fresh(source: List<VaultItem>): List<VaultItem> = source.filter { used.add(it.id) }

    // Each title appears in exactly one rail — no repeated rows of the same video.
    val continueWatching = fresh(all.filter { it.inProgress }.sortedByDescending { it.lastOpened }.take(20))
    val topRated = fresh(all.filter { it.rating >= 4 }.sortedByDescending { it.rating }.take(20))
    val recentlyAdded = fresh(all.sortedByDescending { it.addedAt }.take(15))
    val favorites = fresh(all.filter { it.favorite })
    val categoryRails = TagCatalog.tagsIn("category", s).map { it.name }
        .map { cat -> cat to fresh(all.filter { item -> item.tags.any { it.equals(cat, ignoreCase = true) } }) }
        .filter { it.second.isNotEmpty() }
    val mostWatched = fresh(all.filter { it.views >= 2 }.sortedByDescending { it.views }.take(20))
    val collectionRails = Vault.collections()
        .filter { it != Vault.DEFAULT_COLLECTION }
        .map { name -> name to fresh(all.filter { it.collection == name }) }
        .filter { it.second.isNotEmpty() }
    val unwatched = fresh(all.filter { it.kind == MediaKind.VIDEO && it.views == 0 })
    val photos = fresh(all.filter { it.kind == MediaKind.PHOTO })
    val rest = fresh(all)

    val listState = rememberLazyListState()
    val scrolled by remember { derivedStateOf { listState.firstVisibleItemIndex > 0 || listState.firstVisibleItemScrollOffset > 120 } }

    Box(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        LazyColumn(state = listState, contentPadding = PaddingValues(bottom = 120.dp)) {
            item {
                when {
                    Vault.items.isEmpty() -> EmptyVault(onAdd)
                    hero != null -> Billboard(
                        item = hero,
                        onPlay = { onOpen(hero) },
                        onInfo = { onDetails(hero) },
                        onToggleList = { scope.launch { Vault.toggleFavorite(hero) } },
                        onTag = onOpenTag
                    )
                    else -> Spacer(Modifier.statusBarsPadding().height(120.dp))
                }
            }
            item { Rail("Continue Watching", continueWatching, onClick = onDetails) }
            item { Rail(emo("⭐", "Top Rated"), topRated, onClick = onDetails) }
            item { Rail("Recently Added", recentlyAdded, onClick = onDetails) }
            item { Rail(emo("❤️", "My List"), favorites, onClick = onDetails) }
            categoryRails.forEach { (cat, list) ->
                item(key = "cat-$cat") {
                    Rail(tagLabel(cat).takeUnless { s.discreet } ?: "Collection", list, onSeeAll = { onOpenTag(cat) }, onClick = onDetails)
                }
            }
            item { Rail(emo("🔥", "Most Watched"), mostWatched, onClick = onDetails) }
            collectionRails.forEach { (name, list) ->
                item(key = "col-$name") { Rail(name, list, onClick = onDetails) }
            }
            item { Rail(emo("👀", "Not Watched Yet"), unwatched, onClick = onDetails) }
            item { Rail("Photos", photos, onClick = onDetails) }
            item { Rail("Everything Else", rest, onClick = onDetails) }
        }

        // Floating header: turns solid once you scroll, like Netflix.
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (scrolled) Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.96f), Color.Black.copy(alpha = 0.9f)))
                    else Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.75f), Color.Transparent))
                )
                .statusBarsPadding()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 4.dp, top = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NetscapeWordmark(fontSize = 24.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onSurprise, enabled = Vault.items.isNotEmpty()) {
                    Icon(Icons.Rounded.Casino, contentDescription = "Surprise me", tint = Color.White)
                }
                IconButton(onClick = onAdd) {
                    Icon(Icons.Rounded.Add, contentDescription = "Add media", tint = Color.White)
                }
                IconButton(onClick = onLock) {
                    Icon(Icons.Rounded.Lock, contentDescription = "Lock", tint = Color.White)
                }
            }
            Row(
                modifier = Modifier
                    .horizontalScroll(rememberScrollState())
                    .padding(start = 16.dp, end = 16.dp, top = 2.dp, bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Pill("Videos", filter == 1) { filter = if (filter == 1) 0 else 1 }
                Pill("Photos", filter == 2) { filter = if (filter == 2) 0 else 2 }
                Pill(emo("🔥", "Categories") + "  ▾", false) { categoriesOpen = true }
            }
        }
    }

    if (categoriesOpen) {
        Sheet(onDismiss = { categoriesOpen = false }) {
            val counts = Vault.tagCounts()
            Text(
                "Categories",
                color = Color.White,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
            Column(modifier = Modifier.padding(bottom = 30.dp)) {
                TagCatalog.tagsIn("category", s).forEach { def ->
                    val n = counts[def.name] ?: 0
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable(enabled = n > 0) {
                                categoriesOpen = false
                                onOpenTag(def.name)
                            }
                            .padding(horizontal = 20.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(def.emoji, fontSize = 20.sp, modifier = Modifier.width(34.dp))
                        Text(
                            def.name,
                            color = if (n > 0) Color.White else Brand.Muted,
                            fontSize = 17.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Text(if (n > 0) "$n" else "", color = Brand.Muted, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

private fun emo(emoji: String, text: String): String {
    val s = Vault.settings.value
    return if (s.emojiLevel == 0 || s.discreet) text else "$emoji $text"
}

@Composable
private fun Billboard(
    item: VaultItem,
    onPlay: () -> Unit,
    onInfo: () -> Unit,
    onToggleList: () -> Unit,
    onTag: (String) -> Unit
) {
    val s = Vault.settings.value
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .aspectRatio(0.72f)
    ) {
        ThumbImage(item, Modifier.fillMaxSize())
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0f to Color.Black.copy(alpha = 0.5f),
                        0.3f to Color.Transparent,
                        0.72f to Brand.Ink.copy(alpha = 0.75f),
                        1f to Brand.Ink
                    )
                )
        )
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = shownTitle(item),
                color = Color.White,
                fontSize = 30.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                lineHeight = 34.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            // Genre line, Netflix style: Tag • Tag • Tag
            val genres = if (s.discreet) emptyList() else item.tags.take(4)
            val facts = listOfNotNull(
                AutoTags.quality(item),
                formatDuration(item.durationMs).takeIf { it.isNotEmpty() },
                if (item.rating > 0) "★ ${item.rating}" else null
            )
            if (genres.isNotEmpty()) {
                Row(
                    modifier = Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    genres.forEachIndexed { i, tag ->
                        if (i > 0) Text("  •  ", color = Brand.Red, fontSize = 13.sp)
                        Text(tag, color = Color.White, fontSize = 13.sp, modifier = Modifier.clickable { onTag(tag) })
                    }
                }
            }
            if (facts.isNotEmpty()) {
                Text(
                    facts.joinToString("   "),
                    color = Brand.Muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            Row(
                modifier = Modifier.padding(top = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                RoundAction(if (item.favorite) Icons.Rounded.Check else Icons.Rounded.Add, "My List", onToggleList)
                PrimaryButton(
                    text = if (item.kind == MediaKind.PHOTO) "View" else if (item.inProgress) "Resume" else "Play",
                    icon = Icons.Rounded.PlayArrow,
                    light = true,
                    modifier = Modifier.width(140.dp),
                    onClick = onPlay
                )
                RoundAction(Icons.Rounded.Info, "Info", onInfo)
            }
        }
    }
}

@Composable
private fun RoundAction(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier.bounceClick(onClick = onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(26.dp))
        Text(label, color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
    }
}

@Composable
private fun EmptyVault(onAdd: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(620.dp)
            .padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(96.dp)
                .clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Brand.Red, Brand.RedDeep)))
                .bounceClick(onClick = onAdd),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(44.dp))
        }
        Text(
            text = "Your private stash awaits",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 24.dp)
        )
        Text(
            text = "Add videos and photos — they're encrypted the moment they land, then auto-named and ready to tag.",
            color = Brand.Muted,
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 10.dp)
        )
        PrimaryButton("Add media", icon = Icons.Rounded.Add, modifier = Modifier.padding(top = 26.dp), onClick = onAdd)
    }
}
