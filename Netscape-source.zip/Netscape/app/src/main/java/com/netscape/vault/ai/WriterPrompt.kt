package com.netscape.vault.ai

/**
 * Builds the chat prompt for the offline writer (Qwen2.5 ChatML) and parses its answer.
 * Plain Kotlin so it is tested on a desktop JVM together with the native writer.
 *
 * The prompt is split in two:
 *   prefix — system rules + one worked example for the chosen voice. Constant per style, so the
 *            native side evaluates it once and keeps it cached.
 *   suffix — this item's facts and tags; the only part evaluated per item.
 */
object WriterPrompt {

    data class Prompt(val prefix: String, val suffix: String)

    data class Item(
        val isVideo: Boolean,
        val durationMs: Long,
        val quality: String?,
        val rating: Int,
        /** Tag group display name → tags, e.g. "Positions" → [Cowgirl]. */
        val tagsByGroup: Map<String, List<String>>,
        val people: List<String>,
        /** What the scene model saw (setting, outfit, lighting, camera), if it has been run. */
        val scene: String? = null
    )

    /** Voices, matching the app's title styles. */
    enum class Voice { SPICY, FLIRTY, CLASSY, PLAYFUL, FILTHY, MINIMAL }

    private fun voiceRules(v: Voice): String = when (v) {
        Voice.SPICY -> "Voice: steamy, explicit and vivid. Sensual detail, heat, tension and release. Bold but never clinical."
        Voice.FILTHY -> "Voice: raw, dirty and explicit. Unapologetically naughty dirty-talk energy, graphic about what the tags show."
        Voice.FLIRTY -> "Voice: teasing, cheeky and flirtatious. Build anticipation, wink at the reader, keep it hot."
        Voice.CLASSY -> "Voice: elegant, sensual and cinematic, like a luxury erotic film blurb. Suggestive, refined, intense."
        Voice.PLAYFUL -> "Voice: fun, cheeky and funny, full of innuendo, still clearly sexy."
        Voice.MINIMAL -> "Voice: short, plain and factual. No emojis, no hype."
    }

    private fun emojiRule(level: Int, v: Voice): String = when {
        v == Voice.MINIMAL || level <= 0 -> "Use no emojis."
        level == 1 -> "Use one or two emojis in total, only from: 🔥 😈 💦 🍑 💋 🥵 😏"
        else -> "Sprinkle 3 to 5 spicy emojis through the title and description, only from: 🔥 😈 💦 🍑 💋 🥵 🍆 👅 😏 🖤 ❤️‍🔥 🫦"
    }

    private const val RULES = """You write titles and descriptions for a private, offline adult video and photo library owned by an adult.
Everyone shown is a consenting adult (18+). Never mention or suggest minors, school, or family relationships.
Describe only what the tags and facts say; do not invent extra people, names or acts. If you don't know someone's gender, say "they".
Use the exact length, quality and rating given — never invent or change numbers.
If "What the camera sees" is given, build the scene from those real visual details (place, outfit, lighting, camera) and make them vivid; it was written plainly, so turn up the heat in your voice.
Write like a skilled erotic copywriter: specific, sensory, varied, never generic or robotic. Don't list the tags back; weave them into the scene.
Format exactly:
TITLE: <3 to 8 words, catchy>
DESCRIPTION: <2 to 4 sentences, 40 to 90 words>"""

    private val EXAMPLE_USER = """Video, 7 minutes, 4K, rated 5/5.
Category: Late Night, Steamy
Who's In It: Couple, Straight
Positions: Cowgirl, Spooning
Acts: Kissing, Oral
Setting & Place: Bedroom
Outfit & Lingerie: Lingerie
Mood & Vibe: Passionate"""

    private fun exampleAnswer(v: Voice, level: Int): String {
        val e = level > 0 && v != Voice.MINIMAL
        val title = when (v) {
            Voice.MINIMAL -> "Bedroom Couple, Late Night"
            Voice.CLASSY -> "Black Lace After Midnight" + if (e) " 🖤" else ""
            Voice.PLAYFUL -> "Lingerie Rodeo After Dark" + if (e) " 🤠" else ""
            Voice.FLIRTY -> "Keep the Lace On" + if (e) " 😘" else ""
            Voice.FILTHY -> "She Rides Him Raw at Midnight" + if (e) " 😈" else ""
            Voice.SPICY -> "Midnight Ride in Black Lace" + if (e) " 🔥" else ""
        }
        val desc = when (v) {
            Voice.MINIMAL -> "A couple in the bedroom late at night. Kissing and oral, then cowgirl and spooning. She wears lingerie. Seven minutes in 4K."
            Voice.CLASSY -> "Black lace, low light and nowhere to be. Slow kisses become something hungrier as she takes him with her mouth, then rises above him and sets the rhythm. Seven unhurried minutes in 4K that close with the two of them wrapped together, breathless."
            Voice.PLAYFUL -> "She kept the lingerie on, he kept his hands busy, and the bed definitely heard about it" + (if (e) " 🙈" else "") + ". A generous round of oral, a very confident cowgirl ride, then a sweaty spoon to finish. Seven minutes, zero chill."
            Voice.FLIRTY -> "She wants you to watch her keep the lace on" + (if (e) " 💋" else "") + ". Teasing kisses turn into her mouth on him, then she climbs on top and makes him earn every second. It ends spooned together, still catching their breath."
            Voice.FILTHY -> "She's in black lace and she wants it bad" + (if (e) " 💦" else "") + ". Deep, sloppy kisses, then she goes down on him like she's starving before climbing on and riding him hard until he can't keep quiet. They finish spooning, still grinding into each other."
            Voice.SPICY -> "She keeps the black lace on just long enough to make him beg" + (if (e) " 😈" else "") + ". Hungry kisses turn into her mouth on him, then she takes the lead on top, rolling her hips until neither of them can stay quiet. Seven minutes of late-night heat that ends tangled up and spooning" + (if (e) " 💦" else "") + "."
        }
        return "TITLE: $title\nDESCRIPTION: $desc"
    }

    fun build(item: Item, voice: Voice, emojiLevel: Int): Prompt {
        val system = RULES + "\n" + voiceRules(voice) + "\n" + emojiRule(emojiLevel, voice)
        val prefix = buildString {
            append("<|im_start|>system\n").append(system).append("<|im_end|>\n")
            append("<|im_start|>user\n").append(EXAMPLE_USER).append("<|im_end|>\n")
            append("<|im_start|>assistant\n").append(exampleAnswer(voice, emojiLevel)).append("<|im_end|>\n")
        }
        val suffix = buildString {
            append("<|im_start|>user\n").append(describe(item)).append("<|im_end|>\n")
            append("<|im_start|>assistant\nTITLE:")
        }
        return Prompt(prefix, suffix)
    }

    fun describe(item: Item): String = buildString {
        val facts = mutableListOf<String>()
        if (item.isVideo) {
            val min = (item.durationMs / 60_000).toInt()
            facts += if (min >= 1) "Video, $min minute${if (min == 1) "" else "s"}" else "Short video clip"
        } else {
            facts += "Photo"
        }
        item.quality?.let { facts += it }
        if (item.rating > 0) facts += "rated ${item.rating}/5"
        append(facts.joinToString(", ")).append(".")
        item.tagsByGroup.filterValues { it.isNotEmpty() }.forEach { (group, tags) ->
            append("\n").append(group).append(": ").append(tags.joinToString(", "))
        }
        if (item.people.isNotEmpty()) append("\nStarring: ").append(item.people.joinToString(", "))
        item.scene?.takeIf { it.isNotBlank() }?.let { append("\nWhat the camera sees: ").append(it.take(400)) }
        if (item.tagsByGroup.values.all { it.isEmpty() } && item.scene.isNullOrBlank()) append("\n(No tags yet — keep it sensual and suggestive.)")
    }

    data class Result(val title: String, val description: String)

    // ---------------------------------------------------------------- enforcement
    // A 1.5B model doesn't follow every instruction, so the rules that matter are applied in code.

    val ALLOWED_EMOJI = listOf("🔥", "😈", "💦", "🍑", "💋", "🥵", "🍆", "👅", "😏", "🖤", "❤️‍🔥", "🫦")

    /** Youth-coded or underage wording. Output containing any of it is rejected and rewritten. */
    private val BANNED = Regex(
        "(?i)\\b(teen\\w*|underage\\w*|minor|minors|child\\w*|kid|kids|schoolgirl\\w*|schoolboy\\w*|school|" +
            "student\\w*|highschool|high school|barely legal|loli\\w*|young girl|young boy|little girl|little boy|" +
            "daughter|son|stepdaughter|stepsister|stepbrother|sister|brother|virgin)\\b"
    )

    fun isAcceptable(r: Result): Boolean = !BANNED.containsMatchIn(r.title) && !BANNED.containsMatchIn(r.description)

    private val EMOJI_RUN = Regex("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{2B00}-\\x{2BFF}\\x{2300}-\\x{23FF}][\\x{FE0F}\\x{200D}\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}]*")

    private val NUMBER_WORDS = "one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|" +
        "sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|a few|several"
    /** "9 minutes", "9-minute", "four solid hours", "for ten minutes" — any length the model wrote. */
    private val DURATION = Regex(
        "(?i)\\b((?:for|in|over|after|about|nearly|almost|just|of)\\s+)?" +
            "(\\d+(?:[.:]\\d+)?|$NUMBER_WORDS)(?:[- ](?:\\d+|$NUMBER_WORDS))?" +
            "(\\s+[a-z]+)?([- ])(minutes?|mins?|hours?|hrs?|seconds?|secs?)\\b"
    )

    /** Fix what the model got wrong: stray emojis, invented lengths, extra whitespace. */
    fun enforce(r: Result, item: Item, emojiLevel: Int): Result {
        fun fix(text: String): String {
            var t = EMOJI_RUN.replace(text) { m ->
                if (emojiLevel > 0 && m.value in ALLOWED_EMOJI) m.value else ""
            }
            t = DURATION.replace(t) { m ->
                if (!item.isVideo) return@replace "" // a photo has no length: drop the whole phrase
                val prep = m.groupValues[1]
                val hyphen = m.groupValues[4] == "-"
                val min = (item.durationMs / 60_000).toInt()
                val (n, unit) = if (min >= 1) min to "minute" else (item.durationMs / 1000).coerceAtLeast(1).toInt() to "second"
                val length = if (hyphen) "$n-$unit" else "$n $unit${if (n == 1) "" else "s"}"
                prep + length // "four solid hours" → "22 minutes": the filler word goes with the wrong number
            }
            return t.replace(Regex("[ \\t]{2,}"), " ").replace(Regex(" ([.,!?])"), "$1").trim()
        }
        return Result(fix(r.title), fix(r.description))
    }

    /** [raw] is what the model generated after the "TITLE:" primer. */
    fun parse(raw: String): Result {
        val text = "TITLE:$raw".replace("\r", "")
        val title = Regex("TITLE:\\s*(.+)").find(text)?.groupValues?.get(1)?.trim()
            ?.trim('"', '*', ' ')?.take(90).orEmpty()
        val desc = Regex("DESCRIPTION:\\s*([\\s\\S]+)").find(text)?.groupValues?.get(1)
            ?.substringBefore("<|im_end|>")?.substringBefore("\nTITLE:")?.trim()?.trim('"').orEmpty()
        return Result(title, desc)
    }
}
