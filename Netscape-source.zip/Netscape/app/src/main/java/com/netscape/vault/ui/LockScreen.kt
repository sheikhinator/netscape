package com.netscape.vault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.Vault
import kotlinx.coroutines.launch

@Composable
fun LockScreen(onUnlocked: () -> Unit) {
    val scope = rememberCoroutineScope()
    val isNew = remember { !Vault.hasVault() }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF160305), Brand.Ink, Brand.Ink)
                )
            )
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            NetscapeWordmark(fontSize = 40.sp)
            Text(
                text = if (isNew) "Create your vault passphrase" else "Enter your passphrase",
                color = Brand.Muted,
                fontSize = 14.sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 26.dp)
            )

            OutlinedTextField(
                value = password,
                onValueChange = { password = it; error = null },
                label = { Text("Passphrase") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = ImeAction.Done
                ),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Brand.Surface,
                    unfocusedContainerColor = Brand.Surface,
                    focusedIndicatorColor = Brand.Red,
                    unfocusedIndicatorColor = Brand.Line,
                    focusedLabelColor = Brand.Red,
                    unfocusedLabelColor = Brand.Muted,
                    cursorColor = Brand.Red
                ),
                modifier = Modifier.fillMaxWidth()
            )

            if (isNew) {
                OutlinedTextField(
                    value = confirm,
                    onValueChange = { confirm = it; error = null },
                    label = { Text("Confirm passphrase") },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Brand.Surface,
                        unfocusedContainerColor = Brand.Surface,
                        focusedIndicatorColor = Brand.Red,
                        unfocusedIndicatorColor = Brand.Line,
                        focusedLabelColor = Brand.Red,
                        unfocusedLabelColor = Brand.Muted,
                        cursorColor = Brand.Red
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                )
            }

            error?.let {
                Text(
                    text = it,
                    color = Brand.Red,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            Button(
                onClick = {
                    if (working) return@Button
                    if (password.length < 6) {
                        error = "Use at least 6 characters"
                        return@Button
                    }
                    if (isNew && password != confirm) {
                        error = "Passphrases do not match"
                        return@Button
                    }
                    working = true
                    scope.launch {
                        val ok = if (isNew) Vault.createVault(password) else Vault.unlock(password)
                        working = false
                        if (ok) {
                            password = ""
                            confirm = ""
                            onUnlocked()
                        } else {
                            error = "Wrong passphrase"
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Brand.Red),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 22.dp)
                    .height(50.dp)
            ) {
                if (working) {
                    CircularProgressIndicator(color = Color.White, strokeWidth = 2.dp, modifier = Modifier.height(20.dp))
                } else {
                    Text(if (isNew) "Create vault" else "Unlock", fontSize = 16.sp)
                }
            }

            Text(
                text = if (isNew)
                    "Your passphrase is the only key. It is never stored and cannot be recovered."
                else
                    "Everything stays encrypted on this device.",
                color = Brand.Muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 18.dp)
            )
        }
    }
}
