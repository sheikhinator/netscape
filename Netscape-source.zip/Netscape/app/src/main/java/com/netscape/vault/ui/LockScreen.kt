package com.netscape.vault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.Vault
import kotlinx.coroutines.launch

@Composable
fun LockScreen(onUnlocked: () -> Unit) {
    val scope = rememberCoroutineScope()
    val isNew = remember { !Vault.hasVault() }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var adult by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var working by remember { mutableStateOf(false) }

    fun submit() {
        if (working) return
        if (password.length < 6) {
            error = "Use at least 6 characters"
            return
        }
        if (isNew && password != confirm) {
            error = "Passphrases do not match"
            return
        }
        if (isNew && !adult) {
            error = "Please confirm you are 18 or older"
            return
        }
        working = true
        scope.launch {
            val ok = if (isNew) Vault.createVault(password) else Vault.unlock(password)
            working = false
            if (ok) {
                password = ""
                confirm = ""
                onUnlocked()
            } else {
                error = "Wrong passphrase"
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    0f to Brand.RedDeep.copy(alpha = 0.55f),
                    0.45f to Brand.Ink,
                    1f to Brand.Ink
                )
            )
            .imePadding()
    ) {
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.Lock, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(34.dp))
            }
            NetscapeWordmark(fontSize = 40.sp, modifier = Modifier.padding(top = 18.dp))
            Text(
                text = if (isNew) "Create your vault passphrase" else "Welcome back",
                color = Brand.Muted,
                fontSize = 15.sp,
                modifier = Modifier.padding(top = 6.dp, bottom = 28.dp)
            )

            TextField(
                value = password,
                onValueChange = { password = it; error = null },
                placeholder = { Text("Passphrase", color = Brand.Muted) },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Password,
                    imeAction = if (isNew) ImeAction.Next else ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                shape = RoundedCornerShape(14.dp),
                colors = fieldColors(),
                modifier = Modifier.fillMaxWidth()
            )

            if (isNew) {
                TextField(
                    value = confirm,
                    onValueChange = { confirm = it; error = null },
                    placeholder = { Text("Confirm passphrase", color = Brand.Muted) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { submit() }),
                    shape = RoundedCornerShape(14.dp),
                    colors = fieldColors(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clickable { adult = !adult; error = null },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = adult,
                        onCheckedChange = { adult = it; error = null },
                        colors = CheckboxDefaults.colors(checkedColor = Brand.Red, uncheckedColor = Brand.Muted)
                    )
                    Text("I'm 18 or older, and everything I store here is legal adult content made with consent.", color = Brand.Label, fontSize = 13.sp)
                }
            }

            error?.let {
                Text(
                    text = it,
                    color = Color(0xFFFF6B6B),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            Box(modifier = Modifier.padding(top = 22.dp).fillMaxWidth()) {
                if (working) {
                    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Brand.Red, strokeWidth = 2.5.dp, modifier = Modifier.size(28.dp))
                    }
                } else {
                    PrimaryButton(
                        text = if (isNew) "Create vault" else "Unlock",
                        modifier = Modifier.fillMaxWidth(),
                        onClick = { submit() }
                    )
                }
            }

            Text(
                text = if (isNew)
                    "Your passphrase is the only key. It is never stored and cannot be recovered."
                else
                    "🔒 Everything stays encrypted on this device.",
                color = Brand.Muted,
                fontSize = 12.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 18.dp)
            )
        }
    }
}
