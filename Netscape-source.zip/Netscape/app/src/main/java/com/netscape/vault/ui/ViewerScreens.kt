package com.netscape.vault.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch

@Composable
fun PhotoScreen(item: VaultItem, onBack: () -> Unit) {
    val bitmap by produceState<ImageBitmap?>(initialValue = null, key1 = item.id) {
        value = Vault.photo(item)?.asImageBitmap()
    }
    var scale by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        val bmp = bitmap
        if (bmp == null) {
            CircularProgressIndicator(color = Brand.Red, modifier = Modifier.align(Alignment.Center))
        } else {
            Image(
                bitmap = bmp,
                contentDescription = item.title,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(
                        scaleX = scale,
                        scaleY = scale,
                        translationX = offsetX,
                        translationY = offsetY
                    )
                    .pointerInput(item.id) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 6f)
                            if (scale > 1f) {
                                offsetX += pan.x
                                offsetY += pan.y
                            } else {
                                offsetX = 0f
                                offsetY = 0f
                            }
                        }
                    }
            )
        }
        IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
        ) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
    }
}

/** Scrub through the encrypted video and freeze any frame as the poster art. */
@Composable
fun FramePickerScreen(item: VaultItem, onDone: () -> Unit) {
    val scope = rememberCoroutineScope()
    var position by remember { mutableStateOf(0f) }
    var preview by remember { mutableStateOf<Bitmap?>(null) }
    var loading by remember { mutableStateOf(true) }
    var saving by remember { mutableStateOf(false) }
    val duration = if (item.durationMs > 0) item.durationMs else 1L

    LaunchedEffect(position) {
        loading = true
        preview = Vault.frameAt(item, (position * duration).toLong())
        loading = false
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .padding(16.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onDone) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Text(
                text = "Choose artwork",
                color = Color.White,
                fontSize = 16.sp,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(Brand.SurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            val bmp = preview
            if (bmp != null) {
                Image(
                    bitmap = bmp.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
            if (loading) CircularProgressIndicator(color = Brand.Red)
        }

        Text(
            text = formatDuration((position * duration).toLong()),
            color = Brand.Muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 12.dp)
        )

        Slider(
            value = position,
            onValueChange = { position = it },
            colors = SliderDefaults.colors(
                thumbColor = Brand.Red,
                activeTrackColor = Brand.Red,
                inactiveTrackColor = Brand.Line
            )
        )

        Button(
            onClick = {
                val bmp = preview ?: return@Button
                saving = true
                scope.launch {
                    Vault.setThumbnail(item, bmp)
                    saving = false
                    onDone()
                }
            },
            enabled = preview != null && !saving,
            colors = ButtonDefaults.buttonColors(containerColor = Brand.Red),
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        ) {
            Text(if (saving) "Saving…" else "Use this frame")
        }
    }
}
