package com.netscape.vault.ai

import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.mutableStateOf
import com.netscape.vault.data.AutoTags
import com.netscape.vault.data.TagCatalog
import com.netscape.vault.data.TitleStyle
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * The optional offline writer (Qwen2.5-1.5B, from the Writer pack). Turns an item's tags into a
 * fresh title + description in the user's chosen voice, streaming the text as it is written.
 */
object WriterService {

    data class Status(val installed: Boolean = false, val bytes: Long = 0, val model: String = "")

    val status = mutableStateOf(Status())
    val installProgress = mutableStateOf<Float?>(null)

    /** Ids being written in the background right now (for "writing…" badges). */
    val busyIds = mutableStateOf<Set<String>>(emptySet())

    private const val MODEL_FILE = "writer.gguf"
    private val PACK_FILES = setOf("manifest.json", MODEL_FILE, "LICENSES.txt")

    private val dir: File get() = File(Vault.appContext.filesDir, "writer").apply { mkdirs() }
    private val lock = Mutex()
    private var writer: StoryWriter? = null
    @Volatile private var releasePending = false

    fun refresh() {
        val model = File(dir, MODEL_FILE)
        val name = try {
            JSONObject(File(dir, "manifest.json").readText()).optJSONObject("models")?.optJSONObject("writer")?.optString("source").orEmpty()
        } catch (_: Exception) {
            ""
        }
        status.value = Status(model.isFile, dir.listFiles()?.sumOf { it.length() } ?: 0, name)
    }

    /** Frees the model's memory (vault locked). Deferred if a description is being written. */
    fun release() {
        writer?.cancel()
        if (lock.tryLock()) {
            try { releaseNow() } finally { lock.unlock() }
        } else {
            releasePending = true
        }
    }

    private fun releaseNow() {
        writer?.close()
        writer = null
        releasePending = false
    }

    /** Stop the description currently being written. */
    fun cancel() {
        writer?.cancel()
    }

    // ---------------------------------------------------------------- install

    suspend fun install(uri: Uri): String? = withContext(Dispatchers.IO) {
        lock.withLock {
            releaseNow()
            val staging = File(Vault.appContext.filesDir, "writer.staging").apply { deleteRecursively(); mkdirs() }
            try {
                val resolver = Vault.appContext.contentResolver
                val packSize = try {
                    resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
                    } ?: -1L
                } catch (_: Exception) {
                    -1L
                }
                val free = Vault.appContext.filesDir.usableSpace + (dir.listFiles()?.sumOf { it.length() } ?: 0L)
                if (packSize > 0 && free < packSize + 64L * 1024 * 1024) {
                    return@withContext String.format(
                        Locale.US, "Not enough free storage: the writer needs about %.0f MB, only %.0f MB is free.",
                        packSize / 1e6, free / 1e6
                    )
                }
                val input = resolver.openInputStream(uri) ?: return@withContext "Couldn't open that file"
                var lastPct = -1
                input.use {
                    PackInstaller.extract(it, staging, PACK_FILES) { written ->
                        if (packSize > 0) {
                            val pct = (written * 100 / packSize).toInt().coerceIn(0, 100)
                            if (pct != lastPct) { lastPct = pct; installProgress.value = pct / 100f }
                        }
                    }
                }
                if (!File(staging, MODEL_FILE).isFile) {
                    return@withContext "That isn't the Netscape Writer pack — pick Netscape-Writer-Pack.zip."
                }
                dir.deleteRecursively()
                if (!staging.renameTo(dir)) {
                    staging.copyRecursively(dir, overwrite = true)
                    staging.deleteRecursively()
                }
                null
            } catch (e: PackInstaller.BadPack) {
                e.message?.replace("Netscape-AI-Pack.zip", "Netscape-Writer-Pack.zip")
                    ?.replace("\"Netscape AI pack\"", "\"Netscape Writer pack\"")
            } catch (e: Exception) {
                "Install failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                installProgress.value = null
                staging.deleteRecursively()
                withContext(Dispatchers.Main) { refresh() }
            }
        }
    }

    suspend fun remove() = withContext(Dispatchers.IO) {
        lock.withLock {
            releaseNow()
            dir.deleteRecursively()
            withContext(Dispatchers.Main) { refresh() }
        }
    }

    // ---------------------------------------------------------------- writing

    private fun voice(): WriterPrompt.Voice = when (Vault.settings.value.titleStyle) {
        TitleStyle.FLIRTY -> WriterPrompt.Voice.FLIRTY
        TitleStyle.CLASSY -> WriterPrompt.Voice.CLASSY
        TitleStyle.PLAYFUL -> WriterPrompt.Voice.PLAYFUL
        TitleStyle.FILTHY -> WriterPrompt.Voice.FILTHY
        TitleStyle.MINIMAL -> WriterPrompt.Voice.MINIMAL
        else -> WriterPrompt.Voice.SPICY
    }

    private fun itemFor(item: VaultItem): WriterPrompt.Item {
        val s = Vault.settings.value
        val byGroup = LinkedHashMap<String, MutableList<String>>()
        val people = mutableListOf<String>()
        TagCatalog.groups.forEach { g -> byGroup[g.name] = mutableListOf() }
        item.tags.forEach { tag ->
            val g = TagCatalog.groupOf(tag, s)
            if (g.id == "people") people += tag else byGroup.getOrPut(g.name) { mutableListOf() } += tag
        }
        return WriterPrompt.Item(
            isVideo = item.kind == com.netscape.vault.data.MediaKind.VIDEO,
            durationMs = item.durationMs,
            quality = AutoTags.quality(item),
            rating = item.rating,
            tagsByGroup = byGroup,
            people = people
        )
    }

    /**
     * Writes a new title + description for [item]. [onText] gets the raw text so far on the main
     * thread as it streams in. Nothing is saved — the caller decides.
     */
    suspend fun write(item: VaultItem, onText: (String) -> Unit = {}): WriterPrompt.Result {
        val prompt = WriterPrompt.build(itemFor(item), voice(), Vault.settings.value.emojiLevel)
        val raw = lock.withLock {
            try {
                withContext(Dispatchers.Default) {
                    val w = writer ?: StoryWriter(File(dir, MODEL_FILE).path).also { writer = it }
                    w.write(prompt) { text -> AiService.appScope.launch { onText("TITLE:$text") } }
                }
            } finally {
                if (releasePending) releaseNow()
            }
        }
        return WriterPrompt.parse(raw)
    }

    /**
     * Writes titles/descriptions for [ids] one after another in the background (after import or
     * AI tagging), so they are usually ready before the user opens the item. Titles the user typed
     * by hand are kept; only auto titles/descriptions are replaced.
     */
    suspend fun prewrite(ids: List<String>) {
        if (!status.value.installed) return
        for (id in ids) {
            val item = Vault.find(id) ?: continue
            if (!item.autoTitle) continue
            busyIds.value = busyIds.value + id
            try {
                val r = write(item)
                val fresh = Vault.find(id) ?: continue
                if (fresh.autoTitle && r.title.isNotBlank() && r.description.isNotBlank()) {
                    Vault.saveDetails(fresh.id, r.title, r.description, fresh.rating, titleIsAuto = true)
                }
            } catch (_: Throwable) {
                // Leave the template text in place; the user can retry from the item.
            } finally {
                busyIds.value = busyIds.value - id
            }
        }
    }
}
