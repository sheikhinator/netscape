package com.netscape.vault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.DriveFileMove
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Sell
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.AutoTags
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.SortOrder
import com.netscape.vault.data.TagCatalog
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch

fun sortItems(list: List<VaultItem>, order: SortOrder): List<VaultItem> = when (order) {
    SortOrder.NEWEST -> list.sortedByDescending { it.addedAt }
    SortOrder.OLDEST -> list.sortedBy { it.addedAt }
    SortOrder.TITLE -> list.sortedBy { Vault.displayTitle(it).lowercase().filter { c -> c.isLetterOrDigit() || c == ' ' }.trim() }
    SortOrder.RATING -> list.sortedWith(compareByDescending<VaultItem> { it.rating }.thenByDescending { it.addedAt })
    SortOrder.VIEWS -> list.sortedWith(compareByDescending<VaultItem> { it.views }.thenByDescending { it.lastOpened })
    SortOrder.LONGEST -> list.sortedByDescending { it.durationMs }
    SortOrder.SHORTEST -> list.sortedBy { if (it.durationMs > 0) it.durationMs else Long.MAX_VALUE }
    SortOrder.RANDOM -> list.shuffled()
}

/**
 * Shared grid used by Library / Search / a folder / a tag.
 * Long-press any tile to start multi-select, then tag, rate, move or delete in bulk.
 */
@Composable
fun MediaLibrary(
    entries: List<VaultItem>,
    emptyText: String,
    onOpen: (VaultItem) -> Unit,
    onEditTags: (Set<String>) -> Unit,
    modifier: Modifier = Modifier,
    header: @Composable (() -> Unit)? = null
) {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    var selected by remember { mutableStateOf(setOf<String>()) }
    var moveDialog by remember { mutableStateOf(false) }
    var rateDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var aiDialog by remember { mutableStateOf<Set<String>?>(null) }
    val selectionMode = selected.isNotEmpty()

    Box(modifier = modifier.fillMaxSize().background(Brand.Ink)) {
        LazyVerticalGrid(
            columns = GridCells.Fixed(s.gridColumns.coerceIn(1, 4)),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, bottom = 130.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (header != null) {
                item(span = { GridItemSpan(maxLineSpan) }) { Column { header() } }
            }
            if (entries.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text(emptyText, color = Brand.Muted, fontSize = 15.sp, modifier = Modifier.padding(vertical = 40.dp, horizontal = 8.dp))
                }
            }
            items(entries, key = { it.id }) { item ->
                MediaCard(
                    item = item,
                    modifier = Modifier.fillMaxWidth(),
                    aspect = if (s.gridColumns >= 3) 3f / 4f else 16f / 10f,
                    showTitle = s.gridColumns < 4,
                    selected = selected.contains(item.id),
                    selectionMode = selectionMode,
                    onLongClick = { selected = selected + item.id },
                    onClick = {
                        if (selectionMode) {
                            selected = if (selected.contains(item.id)) selected - item.id else selected + item.id
                        } else onOpen(item)
                    }
                )
            }
        }

        if (selectionMode) {
            SelectionBar(
                count = selected.size,
                modifier = Modifier.align(Alignment.BottomCenter),
                onClear = { selected = emptySet() },
                onSelectAll = { selected = entries.map { it.id }.toSet() },
                onTag = {
                    val ids = selected
                    selected = emptySet()
                    onEditTags(ids)
                },
                onRate = { rateDialog = true },
                onAi = {
                    aiDialog = selected
                    selected = emptySet()
                },
                onMove = { moveDialog = true },
                onDelete = { deleteDialog = true }
            )
        }
    }

    aiDialog?.let { ids -> AiBulkDialog(ids) { aiDialog = null } }

    if (moveDialog) {
        FolderPickerDialog(
            onDismiss = { moveDialog = false },
            onPick = { name ->
                val ids = selected
                moveDialog = false
                selected = emptySet()
                scope.launch { Vault.moveToCollection(ids, name) }
            }
        )
    }

    if (rateDialog) {
        Sheet(onDismiss = { rateDialog = false }) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(bottom = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Rate ${selected.size} item(s)", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(18.dp))
                StarRating(0, size = 44.dp) { r ->
                    val ids = selected
                    rateDialog = false
                    selected = emptySet()
                    scope.launch { Vault.rateMany(ids, r) }
                }
            }
        }
    }

    if (deleteDialog) {
        AlertDialog(
            onDismissRequest = { deleteDialog = false },
            containerColor = Brand.Surface,
            title = { Text("Delete ${selected.size} item(s)?", color = Color.White) },
            text = { Text("The encrypted files are erased from this device.", color = Brand.Muted) },
            confirmButton = {
                TextButton(onClick = {
                    val ids = selected
                    deleteDialog = false
                    selected = emptySet()
                    scope.launch { Vault.deleteMany(ids) }
                }) { Text("Delete", color = Color(0xFFFF453A), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { deleteDialog = false }) { Text("Cancel", color = Color.White) }
            }
        )
    }
}

@Composable
private fun SelectionBar(
    count: Int,
    modifier: Modifier,
    onClear: () -> Unit,
    onSelectAll: () -> Unit,
    onTag: () -> Unit,
    onRate: () -> Unit,
    onAi: () -> Unit,
    onMove: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = modifier
            .padding(start = 12.dp, end = 12.dp, bottom = 96.dp)
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Brand.SurfaceHigh)
            .padding(horizontal = 4.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onClear) { Icon(Icons.Rounded.Close, contentDescription = "Clear", tint = Color.White) }
        Text("$count", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Row(
            modifier = Modifier
                .weight(1f)
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.End
        ) {
            IconButton(onClick = onSelectAll) { Icon(Icons.Rounded.DoneAll, contentDescription = "Select all", tint = Color.White) }
            IconButton(onClick = onTag) { Icon(Icons.Rounded.Sell, contentDescription = "Tag", tint = Color.White) }
            IconButton(onClick = onAi) { Icon(Icons.Rounded.Memory, contentDescription = "AI tag", tint = Brand.Red) }
            IconButton(onClick = onRate) { Icon(Icons.Rounded.Star, contentDescription = "Rate", tint = Brand.Star) }
            IconButton(onClick = onMove) { Icon(Icons.Rounded.DriveFileMove, contentDescription = "Move", tint = Color.White) }
            IconButton(onClick = onDelete) { Icon(Icons.Rounded.Delete, contentDescription = "Delete", tint = Color(0xFFFF453A)) }
        }
    }
}

@Composable
fun FolderPickerDialog(
    onDismiss: () -> Unit,
    onPick: (String) -> Unit
) {
    var newName by remember { mutableStateOf("") }
    val folders = Vault.collections()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Surface,
        title = { Text("Move to folder", color = Color.White) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                folders.forEach { name ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onPick(name) }
                            .padding(vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.Folder, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(20.dp))
                        Text("  $name", color = Color.White, fontSize = 16.sp)
                        Spacer(Modifier.weight(1f))
                        Text("${Vault.countIn(name)}", color = Brand.Muted, fontSize = 13.sp)
                    }
                }
                FilledField(
                    value = newName,
                    onValueChange = { newName = it },
                    label = "New folder name",
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (newName.isNotBlank()) onPick(newName) },
                enabled = newName.isNotBlank()
            ) {
                Icon(Icons.Rounded.CreateNewFolder, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                Text("  Create", color = Brand.Red)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) }
        }
    )
}

// ---------- Library tab ----------

@Composable
fun LibraryScreen(onOpen: (VaultItem) -> Unit, onEditTags: (Set<String>) -> Unit) {
    val s = Vault.settings.value
    var kind by rememberSaveable { mutableStateOf(0) }
    var sort by rememberSaveable { mutableStateOf(s.defaultSort) }
    var sortOpen by remember { mutableStateOf(false) }

    val base = Vault.items.filter {
        when (kind) {
            1 -> it.kind == MediaKind.VIDEO
            2 -> it.kind == MediaKind.PHOTO
            3 -> it.favorite
            else -> true
        }
    }
    val list = remember(base, sort) { sortItems(base, sort) }

    MediaLibrary(
        entries = list,
        emptyText = "Nothing here yet. Add media from Home.",
        onOpen = onOpen,
        onEditTags = onEditTags,
        header = {
            Column(modifier = Modifier.statusBarsPadding()) {
                LargeTitle("Library", "${list.size} item(s) · ${sort.label}") {
                    IconButton(onClick = { sortOpen = true }) {
                        Icon(Icons.Rounded.Sort, contentDescription = "Sort", tint = Brand.Red)
                    }
                }
                Segmented(
                    options = listOf("All", "Videos", "Photos", "My List"),
                    selected = kind,
                    modifier = Modifier.padding(horizontal = 2.dp, vertical = 8.dp)
                ) { kind = it }
            }
        }
    )

    if (sortOpen) {
        SortSheet(current = sort, onDismiss = { sortOpen = false }) { sort = it; sortOpen = false }
    }
}

@Composable
fun SortSheet(current: SortOrder, onDismiss: () -> Unit, onPick: (SortOrder) -> Unit) {
    Sheet(onDismiss = onDismiss) {
        Text(
            "Sort by",
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        GroupedSection {
            SortOrder.values().forEachIndexed { i, order ->
                GroupedRow(
                    title = order.label,
                    showDivider = i < SortOrder.values().lastIndex,
                    onClick = { onPick(order) },
                    trailing = {
                        if (order == current) Text("✓", color = Brand.Red, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                )
            }
        }
        Spacer(Modifier.height(30.dp))
    }
}

// ---------- Search tab ----------

@Composable
fun SearchScreen(onOpen: (VaultItem) -> Unit, onEditTags: (Set<String>) -> Unit) {
    val s = Vault.settings.value
    var query by rememberSaveable { mutableStateOf("") }
    var kind by rememberSaveable { mutableStateOf(0) }
    var include by remember { mutableStateOf(setOf<String>()) }
    var exclude by remember { mutableStateOf(setOf<String>()) }
    var minRating by remember { mutableStateOf(0) }
    var ageRange by remember { mutableStateOf(Vault.MIN_AGE.toFloat()..Vault.MAX_AGE.toFloat()) }
    var sort by remember { mutableStateOf(s.defaultSort) }
    var filtersOpen by remember { mutableStateOf(false) }
    var sortOpen by remember { mutableStateOf(false) }

    val ageFiltered = ageRange.start > Vault.MIN_AGE || ageRange.endInclusive < Vault.MAX_AGE
    val activeFilters = include.size + exclude.size + (if (minRating > 0) 1 else 0) + (if (ageFiltered) 1 else 0)

    fun has(item: VaultItem, tag: String) =
        item.tags.any { it.equals(tag, ignoreCase = true) } || AutoTags.of(item).any { it.equals(tag, ignoreCase = true) }

    val results = Vault.items
        .asSequence()
        .filter {
            when (kind) {
                1 -> it.kind == MediaKind.VIDEO
                2 -> it.kind == MediaKind.PHOTO
                3 -> it.favorite
                4 -> it.inProgress
                else -> true
            }
        }
        .filter { item -> include.all { has(item, it) } && exclude.none { has(item, it) } }
        .filter { it.rating >= minRating }
        .filter { item ->
            !ageFiltered || item.ages.any { it >= ageRange.start.toInt() && it <= ageRange.endInclusive.toInt() }
        }
        .filter { item ->
            val q = query.trim()
            q.isBlank() ||
                item.title.contains(q, ignoreCase = true) ||
                item.description.contains(q, ignoreCase = true) ||
                item.collection.contains(q, ignoreCase = true) ||
                item.tags.any { it.contains(q, ignoreCase = true) } ||
                item.markers.any { it.label.contains(q, ignoreCase = true) } ||
                item.ages.any { it.toString() == q } ||
                AutoTags.of(item).any { it.contains(q, ignoreCase = true) }
        }
        .toList()
        .let { sortItems(it, sort) }

    MediaLibrary(
        entries = results,
        emptyText = "Nothing matches that.",
        onOpen = onOpen,
        onEditTags = onEditTags,
        header = {
            Column(modifier = Modifier.statusBarsPadding()) {
                LargeTitle("Search", "${results.size} result(s)") {
                    IconButton(onClick = { sortOpen = true }) {
                        Icon(Icons.Rounded.Sort, contentDescription = "Sort", tint = Brand.Red)
                    }
                    Box {
                        IconButton(onClick = { filtersOpen = true }) {
                            Icon(Icons.Rounded.Tune, contentDescription = "Filters", tint = Brand.Red)
                        }
                        if (activeFilters > 0) {
                            Text(
                                "$activeFilters",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .background(Brand.Red, RoundedCornerShape(50))
                                    .padding(horizontal = 5.dp)
                            )
                        }
                    }
                }
                SearchField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = "Titles, tags, positions, people, ages…",
                    modifier = Modifier.padding(horizontal = 2.dp, vertical = 6.dp)
                )
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("All", "Videos", "Photos", "My List", "In progress").forEachIndexed { i, label ->
                        Pill(label, kind == i) { kind = i }
                    }
                }
                if (include.isNotEmpty() || exclude.isNotEmpty()) {
                    FlowRow(
                        modifier = Modifier.padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        include.forEach { t -> TagChip(tagLabel(t), ChipState.ON) { include = include - t } }
                        exclude.forEach { t -> TagChip(tagLabel(t), ChipState.EXCLUDED) { exclude = exclude - t } }
                    }
                }
            }
        }
    )

    if (sortOpen) {
        SortSheet(current = sort, onDismiss = { sortOpen = false }) { sort = it; sortOpen = false }
    }

    if (filtersOpen) {
        Sheet(onDismiss = { filtersOpen = false }) {
            val counts = Vault.tagCounts()
            val autoCounts = Vault.items.flatMap { AutoTags.of(it) }.groupingBy { it }.eachCount()
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(bottom = 40.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Filters", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    TextButton(onClick = {
                        include = emptySet(); exclude = emptySet(); minRating = 0
                        ageRange = Vault.MIN_AGE.toFloat()..Vault.MAX_AGE.toFloat()
                    }) { Text("Reset", color = Brand.Red) }
                }
                Text(
                    "Tap a tag once to require it, twice to exclude it, again to clear.",
                    color = Brand.Muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                SectionLabel("Minimum rating")
                Box(Modifier.padding(horizontal = 16.dp)) { StarRating(minRating, size = 32.dp) { minRating = it } }

                SectionLabel("🎂 Age  ${ageRange.start.toInt()}–${ageRange.endInclusive.toInt()}")
                RangeSlider(
                    value = ageRange,
                    onValueChange = { ageRange = it },
                    valueRange = Vault.MIN_AGE.toFloat()..Vault.MAX_AGE.toFloat(),
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Brand.Red,
                        inactiveTrackColor = Brand.SurfaceHigher
                    ),
                    modifier = Modifier.padding(horizontal = 16.dp)
                )

                fun cycle(tag: String) {
                    when {
                        tag in include -> { include = include - tag; exclude = exclude + tag }
                        tag in exclude -> exclude = exclude - tag
                        else -> include = include + tag
                    }
                }
                fun stateOf(tag: String) = when (tag) {
                    in include -> ChipState.ON
                    in exclude -> ChipState.EXCLUDED
                    else -> ChipState.OFF
                }

                SectionLabel("Auto-detected")
                FlowRow(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    autoCounts.keys.sorted().forEach { tag ->
                        TagChip(tag, stateOf(tag), count = autoCounts[tag]) { cycle(tag) }
                    }
                }

                TagCatalog.groups.forEach { g ->
                    // Only tags that are actually used somewhere — keeps the sheet tidy.
                    val used = TagCatalog.tagsIn(g.id, s).map { it.name }.filter { (counts[it] ?: 0) > 0 } +
                        (if (g.id == TagCatalog.CUSTOM_GROUP) counts.keys.filter { TagCatalog.groupOf(it, s).id == g.id } else emptyList())
                    val tags = used.distinct()
                    if (tags.isNotEmpty()) {
                        SectionLabel("${g.emoji} ${g.name}")
                        FlowRow(
                            modifier = Modifier.padding(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            tags.forEach { tag ->
                                TagChip(tagLabel(tag), stateOf(tag), count = counts[tag]) { cycle(tag) }
                            }
                        }
                    }
                }
                PrimaryButton(
                    "Show ${results.size} result(s)",
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) { filtersOpen = false }
            }
        }
    }
}

// ---------- Explore tab ----------

@Composable
fun ExploreScreen(
    onOpenFolder: (String) -> Unit,
    onOpenTag: (String) -> Unit,
    onOpenAges: (Int, Int) -> Unit
) {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    val folders = Vault.collections()
    val counts = Vault.tagCounts()
    var manage by remember { mutableStateOf<String?>(null) }
    var renaming by remember { mutableStateOf<String?>(null) }
    var renameDraft by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(bottom = 130.dp)
    ) {
        LargeTitle("Explore", "${counts.size} tags in use · ${folders.size} folder(s)")

        // Category tiles
        val categories = TagCatalog.tagsIn("category", s).filter { (counts[it.name] ?: 0) > 0 }
        SectionLabel(if (s.discreet) "Collections" else "🔥 Spicy Categories")
        if (categories.isEmpty()) {
            Text(
                "Tag something with a category (🔥 Hot, 🌙 Late Night, 😈 Naughty…) and it appears here as a tile and a row on Home.",
                color = Brand.Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        } else {
            categories.chunked(2).forEach { pair ->
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 5.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    pair.forEachIndexed { i, def ->
                        CategoryTile(
                            name = if (s.discreet) "Collection ${i + 1}" else def.name,
                            emoji = if (s.discreet) "" else def.emoji,
                            count = counts[def.name] ?: 0,
                            cover = Vault.coverOfTag(def.name),
                            modifier = Modifier.weight(1f)
                        ) { onOpenTag(def.name) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }

        // Folders
        SectionLabel("Folders")
        folders.chunked(2).forEach { pair ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 5.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pair.forEach { name ->
                    FolderTile(
                        name = name,
                        modifier = Modifier.weight(1f),
                        onClick = { onOpenFolder(name) },
                        onLongClick = { manage = name }
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        if (folders.isNotEmpty()) {
            Text(
                "Long-press a folder to rename or remove it.",
                color = Brand.Muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
        }

        // Ages
        val allAges = Vault.items.flatMap { it.ages }
        if (allAges.isNotEmpty() && !s.discreet) {
            SectionLabel("🎂 Ages")
            FlowRow(
                modifier = Modifier.padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf(18 to 21, 22 to 25, 26 to 29, 30 to 34, 35 to 39, 40 to 49, 50 to 99).forEach { (lo, hi) ->
                    val n = Vault.items.count { item -> item.ages.any { it in lo..hi } }
                    if (n > 0) {
                        TagChip(if (hi == 99) "$lo+" else "$lo–$hi", count = n) { onOpenAges(lo, hi) }
                    }
                }
            }
        }

        // Every other group: only tags in use
        if (!s.discreet) {
            TagCatalog.groups.filter { it.id != "category" }.forEach { g ->
                val tags = counts.keys.filter { TagCatalog.groupOf(it, s).id == g.id }
                    .sortedByDescending { counts[it] ?: 0 }
                if (tags.isNotEmpty()) {
                    SectionLabel("${g.emoji} ${g.name}")
                    Row(
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        tags.forEach { tag -> TagChip(tagLabel(tag), count = counts[tag]) { onOpenTag(tag) } }
                    }
                }
            }
        }
    }

    val managing = manage
    if (managing != null) {
        AlertDialog(
            onDismissRequest = { manage = null },
            containerColor = Brand.Surface,
            title = { Text(managing, color = Color.White) },
            text = {
                Text(
                    "${Vault.countIn(managing)} item(s). Removing a folder keeps the media — items move back to ${Vault.DEFAULT_COLLECTION}.",
                    color = Brand.Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    renameDraft = managing
                    renaming = managing
                    manage = null
                }) {
                    Icon(Icons.Rounded.Edit, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                    Text("  Rename", color = Brand.Red)
                }
            },
            dismissButton = {
                if (managing != Vault.DEFAULT_COLLECTION) {
                    TextButton(onClick = {
                        manage = null
                        scope.launch { Vault.deleteCollection(managing) }
                    }) { Text("Remove folder", color = Color.White) }
                }
            }
        )
    }

    val renamingName = renaming
    if (renamingName != null) {
        AlertDialog(
            onDismissRequest = { renaming = null },
            containerColor = Brand.Surface,
            title = { Text("Rename folder", color = Color.White) },
            text = { FilledField(value = renameDraft, onValueChange = { renameDraft = it }, label = "Folder name") },
            confirmButton = {
                TextButton(onClick = {
                    val target = renameDraft
                    renaming = null
                    scope.launch { Vault.renameCollection(renamingName, target) }
                }) { Text("Save", color = Brand.Red) }
            },
            dismissButton = {
                TextButton(onClick = { renaming = null }) { Text("Cancel", color = Color.White) }
            }
        )
    }
}

@Composable
private fun CategoryTile(
    name: String,
    emoji: String,
    count: Int,
    cover: VaultItem?,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .aspectRatio(1.6f)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(listOf(Brand.Red, Brand.RedDeep)))
            .bounceClick(onClick = onClick)
    ) {
        if (cover != null) {
            ThumbImage(cover, Modifier.fillMaxSize())
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.linearGradient(listOf(Brand.Red.copy(alpha = 0.75f), Color.Black.copy(alpha = 0.55f))))
            )
        }
        Column(modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)) {
            if (emoji.isNotEmpty()) Text(emoji, fontSize = 24.sp)
            Text(name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("$count item(s)", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun FolderTile(
    name: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cover = Vault.coverOf(name)
    Column(modifier = modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 10f)
                .clip(RoundedCornerShape(12.dp))
                .background(Brand.SurfaceHigh)
        ) {
            if (cover != null) ThumbImage(cover, Modifier.fillMaxSize())
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(0.3f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.8f)))
            )
            Icon(
                Icons.Rounded.Folder,
                contentDescription = null,
                tint = Color.White.copy(alpha = 0.9f),
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp).size(18.dp)
            )
            Text(
                text = "${Vault.countIn(name)}",
                color = Color.White,
                fontSize = 12.sp,
                modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
            )
        }
        Text(
            text = name,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp, start = 2.dp)
        )
    }
}

// ---------- a folder / a tag / an age range ----------

@Composable
fun CollectionScreen(
    title: String,
    entries: List<VaultItem>,
    onBack: () -> Unit,
    onOpen: (VaultItem) -> Unit,
    onEditTags: (Set<String>) -> Unit
) {
    val s = Vault.settings.value
    var sort by rememberSaveable { mutableStateOf(s.defaultSort) }
    var sortOpen by remember { mutableStateOf(false) }
    val list = remember(entries, sort) { sortItems(entries, sort) }

    MediaLibrary(
        entries = list,
        emptyText = "Nothing here yet.",
        onOpen = onOpen,
        onEditTags = onEditTags,
        header = {
            Column(modifier = Modifier.statusBarsPadding()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.clickable(onClick = onBack).padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Rounded.ArrowBackIosNew, contentDescription = "Back", tint = Brand.Red, modifier = Modifier.size(18.dp))
                        Text(" Back", color = Brand.Red, fontSize = 16.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { sortOpen = true }) {
                        Icon(Icons.Rounded.Sort, contentDescription = "Sort", tint = Brand.Red)
                    }
                }
                Text(
                    title,
                    color = Color.White,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp)
                )
                Text(
                    "${list.size} item(s) · ${sort.label}",
                    color = Brand.Muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(start = 4.dp, bottom = 10.dp)
                )
            }
        }
    )

    if (sortOpen) {
        SortSheet(current = sort, onDismiss = { sortOpen = false }) { sort = it; sortOpen = false }
    }
}
