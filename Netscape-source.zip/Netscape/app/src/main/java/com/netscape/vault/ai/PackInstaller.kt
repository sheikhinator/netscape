package com.netscape.vault.ai

import org.json.JSONObject
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.security.MessageDigest
import java.util.Locale
import java.util.zip.ZipException
import java.util.zip.ZipInputStream

/**
 * Unpacks an AI pack zip into a staging folder and proves every model arrived intact.
 * Plain Kotlin (no Android types) so it is unit-tested on a desktop JVM.
 *
 * Packs built since manifest v3 list each file's size and SHA-256 under "files"; anything that
 * doesn't match — a download cut off half way, a flipped byte — is rejected with a message that
 * says which file is damaged, instead of a raw zlib error.
 */
object PackInstaller {

    /** Shown to the user as-is. */
    class BadPack(message: String) : Exception(message)

    private const val REDOWNLOAD =
        "Delete it, download Netscape-AI-Pack.zip again from the \"Netscape AI pack\" release, " +
            "wait until the download has fully finished, then install it."

    private fun mb(bytes: Long) = String.format(Locale.US, "%.1f MB", bytes / 1e6)

    /**
     * Extracts the files named in [allowed] from [input] into [staging] and verifies them.
     * [onProgress] receives the number of bytes written so far.
     */
    fun extract(
        input: InputStream,
        staging: File,
        allowed: Set<String>,
        onProgress: (Long) -> Unit = {}
    ): Int {
        val got = HashMap<String, Pair<Long, String>>()
        var written = 0L
        try {
            ZipInputStream(input.buffered(1 shl 16)).use { zip ->
                val buf = ByteArray(1 shl 16)
                while (true) {
                    val entry = zip.nextEntry ?: break
                    val name = entry.name.substringAfterLast('/')
                    if (entry.isDirectory || name !in allowed) continue
                    val digest = MessageDigest.getInstance("SHA-256")
                    var size = 0L
                    File(staging, name).outputStream().use { out ->
                        while (true) {
                            val n = zip.read(buf)
                            if (n < 0) break
                            out.write(buf, 0, n)
                            digest.update(buf, 0, n)
                            size += n
                            written += n
                            onProgress(written)
                        }
                    }
                    got[name] = size to digest.digest().joinToString("") { "%02x".format(it) }
                }
            }
        } catch (e: IOException) {
            if (e.message.orEmpty().contains("ENOSPC") || e.message.orEmpty().contains("No space", ignoreCase = true)) {
                throw BadPack("Not enough free storage to install the AI pack. Free up some space and try again.")
            }
            val why = when (e) {
                is EOFException -> "the file ends too early"
                is ZipException -> e.message ?: "it isn't a valid zip"
                else -> e.message ?: e.javaClass.simpleName
            }
            throw BadPack("This AI pack file is damaged or only partly downloaded ($why). $REDOWNLOAD")
        }

        if (got.isEmpty()) {
            throw BadPack("That file isn't a Netscape AI pack — pick Netscape-AI-Pack.zip.")
        }
        val manifestFile = File(staging, "manifest.json")
        val manifest = try {
            JSONObject(manifestFile.readText())
        } catch (_: Exception) {
            throw BadPack("This AI pack is missing its manifest, so it is incomplete. $REDOWNLOAD")
        }

        // Older packs have no checksums — accept them as before.
        val files = manifest.optJSONObject("files") ?: return got.size
        for (name in files.keys()) {
            if (name !in allowed) continue
            val want = files.getJSONObject(name)
            val wantSize = want.getLong("size")
            val wantSha = want.getString("sha256").lowercase(Locale.US)
            val have = got[name]
                ?: throw BadPack("This AI pack is incomplete — $name is missing. $REDOWNLOAD")
            if (have.first != wantSize) {
                throw BadPack(
                    "This AI pack is damaged — $name is ${mb(have.first)} but should be ${mb(wantSize)}. $REDOWNLOAD"
                )
            }
            if (have.second != wantSha) {
                throw BadPack("This AI pack is damaged — $name failed its checksum. $REDOWNLOAD")
            }
        }
        return got.size
    }
}
