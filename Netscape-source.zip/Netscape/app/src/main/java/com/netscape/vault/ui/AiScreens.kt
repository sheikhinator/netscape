package com.netscape.vault.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.ai.AiService
import com.netscape.vault.ai.AiTagger
import com.netscape.vault.ai.Suggestion
import com.netscape.vault.data.TagCatalog
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch
import java.util.Locale

// ---------------------------------------------------------------- Settings section

@Composable
fun AiSettingsSection() {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val st = AiService.status.value
    val s = Vault.settings.value
    var installing by remember { mutableStateOf(false) }
    var confirmRemove by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        Vault.suppressAutoLock = false
        if (uri != null) {
            installing = true
            AiService.appScope.launch {
                val error = AiService.install(uri)
                installing = false
                Toast.makeText(context, error ?: "✨ AI models installed", Toast.LENGTH_LONG).show()
            }
        }
    }

    GroupedSection(
        header = "AI models (offline)",
        footer = if (st.any) "Models run entirely on this phone — nothing is uploaded. Frames are decrypted in memory only."
        else "Download Netscape-AI-Pack.zip from your GitHub repo → Releases → \"Netscape AI pack\", then tap Install and pick the zip. Everything runs offline on this phone."
    ) {
        GroupedRow("NSFW classifier", icon = Icons.Rounded.Memory, iconTint = Color(0xFFFF453A), value = if (st.classifier) "✅ Installed" else "Not installed")
        GroupedRow("NudeNet body detector", icon = Icons.Rounded.Memory, iconTint = Color(0xFFFF9F0A), value = if (st.nudeNet) "✅ Installed" else "Not installed")
        GroupedRow("CLIP scene & position model", icon = Icons.Rounded.Memory, iconTint = Color(0xFFBF5AF2), value = if (st.clip) "✅ Installed" else "Not installed")
        GroupedRow(
            title = if (installing) "Installing…" else if (st.any) "Reinstall / update AI pack" else "Install AI pack (.zip)",
            icon = Icons.Rounded.Download,
            iconTint = Color(0xFF0A84FF),
            value = if (st.any) String.format(Locale.US, "%.0f MB", st.bytes / 1e6) else null,
            showDivider = st.any,
            onClick = {
                if (!installing) {
                    Vault.suppressAutoLock = true
                    picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
                }
            },
            trailing = {
                if (installing) CircularProgressIndicator(color = Brand.Red, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                else Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Brand.Muted, modifier = Modifier.size(20.dp))
            }
        )
        if (st.any) {
            ToggleRow("Auto-tag new imports", s.aiAutoTagImports, icon = Icons.Rounded.AutoAwesome, iconTint = Color(0xFF30D158)) { v ->
                scope.launch { Vault.updateSettings { it.copy(aiAutoTagImports = v) } }
            }
            GroupedRow("Sensitivity", icon = Icons.Rounded.Tune, iconTint = Color(0xFF64D2FF), trailing = {
                Segmented(
                    options = listOf("Strict", "Balanced", "Loose"),
                    selected = s.aiSensitivity,
                    modifier = Modifier.size(width = 220.dp, height = 34.dp)
                ) { i -> scope.launch { Vault.updateSettings { it.copy(aiSensitivity = i) } } }
            })
            GroupedRow("Remove AI models", icon = Icons.Rounded.Delete, iconTint = Color(0xFF8E8E93), titleColor = Color(0xFFFF453A), showDivider = false, onClick = { confirmRemove = true })
        }
    }

    if (confirmRemove) {
        AlertDialog(
            onDismissRequest = { confirmRemove = false },
            containerColor = Brand.Surface,
            title = { Text("Remove AI models?", color = Color.White) },
            text = { Text("Frees ${String.format(Locale.US, "%.0f MB", st.bytes / 1e6)}. Your tags stay.", color = Brand.Muted) },
            confirmButton = {
                TextButton(onClick = {
                    confirmRemove = false
                    scope.launch { AiService.remove() }
                }) { Text("Remove", color = Color(0xFFFF453A), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(onClick = { confirmRemove = false }) { Text("Cancel", color = Color.White) } }
        )
    }
}

// ---------------------------------------------------------------- per-item suggestions

/** "✨ Suggest tags with AI" row for the detail screen, plus its results sheet. */
@Composable
fun AiSuggestRow(item: VaultItem) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val st = AiService.status.value
    var running by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf<List<Suggestion>?>(null) }

    Row(
        modifier = Modifier
            .padding(top = 8.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Brand.Surface)
            .clickable(enabled = !running) {
                if (!st.any) {
                    Toast.makeText(context, "Install the AI pack first: Settings → AI models", Toast.LENGTH_LONG).show()
                    return@clickable
                }
                running = true
                scope.launch {
                    results = try {
                        AiService.suggest(item)
                    } catch (e: Throwable) {
                        Toast.makeText(context, "AI failed: ${e.message ?: e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
                        null
                    }
                    running = false
                }
            }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (running) {
            CircularProgressIndicator(color = Brand.Red, strokeWidth = 2.dp, modifier = Modifier.size(18.dp))
            Text("  Looking at ${if (item.kind == com.netscape.vault.data.MediaKind.VIDEO) "5 frames" else "the photo"}…", color = Color.White, fontSize = 14.sp)
        } else {
            Icon(Icons.Rounded.Memory, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
            Text(
                if (st.any) "  Suggest tags with AI" else "  AI tagging — set up in Settings",
                color = if (st.any) Color.White else Brand.Muted,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }

    val found = results
    if (found != null) {
        AiResultsSheet(item = item, suggestions = found, onDismiss = { results = null })
    }
}

@Composable
private fun AiResultsSheet(item: VaultItem, suggestions: List<Suggestion>, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    val s = Vault.settings.value
    val preselected = remember(suggestions) { AiTagger.confident(suggestions, s.aiSensitivity).map { it.tag }.toSet() }
    var chosen by remember(suggestions) { mutableStateOf(preselected) }

    Sheet(onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
                .padding(bottom = 36.dp)
        ) {
            Text("✨ AI suggestions", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                if (suggestions.isEmpty()) "Nothing new spotted. Try Loose sensitivity in Settings → AI models."
                else "Tap to choose. Percentages are how sure the model is — positions are the hardest, so double-check those.",
                color = Brand.Muted,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 4.dp, bottom = 8.dp)
            )
            val byGroup = suggestions.groupBy { it.groupId }
            TagCatalog.groups.filter { it.id in byGroup }.forEach { g ->
                SectionLabel("${g.emoji} ${g.name}")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    byGroup.getValue(g.id).forEach { sug ->
                        val on = sug.tag in chosen
                        TagChip(
                            label = "${tagLabel(sug.tag)}  ${(sug.confidence * 100).toInt()}%",
                            state = if (on) ChipState.ON else ChipState.OFF
                        ) { chosen = if (on) chosen - sug.tag else chosen + sug.tag }
                    }
                }
            }
            Spacer(Modifier.height(18.dp))
            if (suggestions.isNotEmpty()) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    SecondaryButton("All", modifier = Modifier.weight(1f)) { chosen = suggestions.map { it.tag }.toSet() }
                    PrimaryButton(
                        "Add ${chosen.size} tag${if (chosen.size == 1) "" else "s"}",
                        enabled = chosen.isNotEmpty(),
                        modifier = Modifier.weight(2f)
                    ) {
                        val add = chosen
                        scope.launch {
                            Vault.applyTagChanges(setOf(item.id), add, emptySet())
                            onDismiss()
                        }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- bulk

/** Confirmation + run for AI-tagging a multi-selection. */
@Composable
fun AiBulkDialog(ids: Set<String>, onDone: () -> Unit) {
    val context = LocalContext.current
    val st = AiService.status.value
    AlertDialog(
        onDismissRequest = onDone,
        containerColor = Brand.Surface,
        title = { Text("✨ AI-tag ${ids.size} item(s)?", color = Color.White) },
        text = {
            Text(
                if (st.any) "Only tags the models are confident about get added (sensitivity: ${listOf("Strict", "Balanced", "Loose")[Vault.settings.value.aiSensitivity]}). Videos take a few seconds each."
                else "Install the AI pack first: Settings → AI models.",
                color = Brand.Muted
            )
        },
        confirmButton = {
            if (st.any) {
                TextButton(onClick = {
                    onDone()
                    AiService.appScope.launch {
                        val n = AiService.autoTag(ids.toList())
                        Toast.makeText(context, "✨ Added $n tag(s)", Toast.LENGTH_SHORT).show()
                    }
                }) { Text("Tag them", color = Brand.Red, fontWeight = FontWeight.Bold) }
            }
        },
        dismissButton = { TextButton(onClick = onDone) { Text("Cancel", color = Color.White) } }
    )
}
