package com.netscape.vault.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import com.netscape.vault.crypto.Crypto
import com.netscape.vault.crypto.EncryptedMediaDataSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID
import javax.crypto.SecretKey

enum class MediaKind { VIDEO, PHOTO }

/** A labelled moment inside a video, e.g. 2:14 → "Doggy Style". */
data class Marker(val ms: Long, val label: String)

data class VaultItem(
    val id: String,
    val title: String,
    val kind: MediaKind,
    val hash: String,
    val sizeBytes: Long,
    val durationMs: Long,
    val addedAt: Long,
    val keyWrap: String,
    val collection: String,
    val favorite: Boolean,
    val progressMs: Long,
    val lastOpened: Long,
    val hasThumb: Boolean,
    val tags: List<String> = emptyList(),
    val description: String = "",
    /** 0 = unrated, 1..5 stars. */
    val rating: Int = 0,
    /** Ages of the people in it. Always 18 or over — enforced by [Vault.cleanAges]. */
    val ages: List<Int> = emptyList(),
    val markers: List<Marker> = emptyList(),
    val views: Int = 0,
    val width: Int = 0,
    val height: Int = 0,
    val sourceName: String = "",
    /** True while the title is machine-written; a manual rename turns it off. */
    val autoTitle: Boolean = false
) {
    val progressFraction: Float
        get() = if (durationMs > 0) (progressMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    val inProgress: Boolean
        get() = kind == MediaKind.VIDEO && progressMs > 5_000 && progressFraction < 0.95f
}

object Vault {

    const val DEFAULT_COLLECTION = "My Library"
    const val MIN_AGE = 18
    const val MAX_AGE = 99

    lateinit var appContext: Context
        private set

    private var master: SecretKey? = null
    private val thumbCache = object : android.util.LruCache<String, Bitmap>(64) {}

    val items: SnapshotStateList<VaultItem> = mutableStateListOf()
    val unlocked = mutableStateOf(false)
    val busyMessage = mutableStateOf<String?>(null)
    val settings = mutableStateOf(Settings())

    /** Set when the library could not be read; saving is blocked so nothing gets overwritten. */
    val loadError = mutableStateOf<String?>(null)

    /** Set while a system picker is on screen so auto-lock does not fire. */
    var suppressAutoLock = false

    /** Stable 1-based number per item (oldest = 1), used by discreet mode and title numbering. */
    private val ordinals by derivedStateOf {
        items.sortedBy { it.addedAt }.mapIndexed { i, item -> item.id to i + 1 }.toMap()
    }

    fun numberOf(item: VaultItem): Int = ordinals[item.id] ?: (items.size + 1)

    private val root: File get() = File(appContext.filesDir, "vault").apply { mkdirs() }
    private val mediaDir: File get() = File(root, "media").apply { mkdirs() }
    private val thumbDir: File get() = File(root, "thumbs").apply { mkdirs() }
    private val headerFile: File get() = File(root, "header.json")
    private val libraryFile: File get() = File(root, "library.enc")
    private val libraryBackup: File get() = File(root, "library.enc.bak")
    private val libraryTemp: File get() = File(root, "library.enc.tmp")

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun hasVault(): Boolean = headerFile.exists()

    fun lock() {
        master = null
        items.clear()
        thumbCache.evictAll()
        settings.value = Settings()
        loadError.value = null
        unlocked.value = false
    }

    // ---------- unlock / create ----------

    suspend fun createVault(password: String): Boolean = withContext(Dispatchers.IO) {
        val salt = Crypto.randomBytes(16)
        val key = Crypto.deriveMasterKey(password.toCharArray(), salt)
        val verifier = Crypto.gcmEncrypt(key, "NETSCAPE-V1".toByteArray())
        val header = JSONObject()
            .put("v", 1)
            .put("salt", Crypto.b64(salt))
            .put("iterations", Crypto.ITERATIONS)
            .put("verifier", Crypto.b64(verifier))
        writeAtomically(headerFile, header.toString().toByteArray())
        master = key
        withContext(Dispatchers.Main) {
            items.clear()
            settings.value = Settings()
        }
        saveLibrary()
        withContext(Dispatchers.Main) { unlocked.value = true }
        true
    }

    suspend fun unlock(password: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val header = JSONObject(headerFile.readText())
            val salt = Crypto.unb64(header.getString("salt"))
            val iterations = header.optInt("iterations", Crypto.ITERATIONS)
            val key = Crypto.deriveMasterKey(password.toCharArray(), salt, iterations)
            val plain = Crypto.gcmDecrypt(key, Crypto.unb64(header.getString("verifier")))
            if (String(plain) != "NETSCAPE-V1") return@withContext false
            master = key
            val loaded = loadLibrary()
            withContext(Dispatchers.Main) {
                items.clear()
                items.addAll(loaded.first.sortedByDescending { it.addedAt })
                settings.value = loaded.second
                unlocked.value = true
            }
            true
        } catch (e: Exception) {
            master = null
            false
        }
    }

    suspend fun changePassword(current: String, next: String): Boolean = withContext(Dispatchers.IO) {
        val header = JSONObject(headerFile.readText())
        val salt = Crypto.unb64(header.getString("salt"))
        val iterations = header.optInt("iterations", Crypto.ITERATIONS)
        val oldKey = try {
            val k = Crypto.deriveMasterKey(current.toCharArray(), salt, iterations)
            Crypto.gcmDecrypt(k, Crypto.unb64(header.getString("verifier")))
            k
        } catch (e: Exception) {
            return@withContext false
        }
        if (loadError.value != null) return@withContext false
        val newSalt = Crypto.randomBytes(16)
        val newKey = Crypto.deriveMasterKey(next.toCharArray(), newSalt)
        // Re-wrap every per-item key under the new master key.
        val rewrapped = items.toList().map { item ->
            val fileKey = Crypto.unwrapKey(oldKey, item.keyWrap)
            item.copy(keyWrap = Crypto.wrapKey(newKey, fileKey))
        }
        // Write the re-wrapped library under the new key first, then swap the header.
        master = newKey
        withContext(Dispatchers.Main) {
            items.clear()
            items.addAll(rewrapped)
        }
        saveLibrary()
        writeAtomically(
            headerFile,
            JSONObject()
                .put("v", 1)
                .put("salt", Crypto.b64(newSalt))
                .put("iterations", Crypto.ITERATIONS)
                .put("verifier", Crypto.b64(Crypto.gcmEncrypt(newKey, "NETSCAPE-V1".toByteArray())))
                .toString()
                .toByteArray()
        )
        // The old backup is encrypted under the old key — replace it.
        libraryFile.copyTo(libraryBackup, overwrite = true)
        true
    }

    // ---------- persistence ----------

    /** Reads the library, falling back to the backup copy if the main file is damaged. */
    private fun loadLibrary(): Pair<List<VaultItem>, Settings> {
        val key = master ?: return emptyList<VaultItem>() to Settings()
        loadError.value = null
        if (!libraryFile.exists() && !libraryBackup.exists()) return emptyList<VaultItem>() to Settings()
        for (file in listOf(libraryFile, libraryBackup)) {
            if (!file.exists()) continue
            try {
                return parseLibrary(String(Crypto.gcmDecrypt(key, file.readBytes())))
            } catch (_: Exception) {
            }
        }
        loadError.value = "Your library index could not be read. Nothing has been changed on disk."
        return emptyList<VaultItem>() to Settings()
    }

    private fun parseLibrary(json: String): Pair<List<VaultItem>, Settings> {
        val trimmed = json.trimStart()
        // v1 was a bare array of items; v2 is {"v":2,"items":[...],"settings":{...}}.
        val (arr, settingsJson) = if (trimmed.startsWith("[")) {
            JSONArray(trimmed) to null
        } else {
            val o = JSONObject(trimmed)
            (o.optJSONArray("items") ?: JSONArray()) to o.optJSONObject("settings")
        }
        val list = mutableListOf<VaultItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val markers = mutableListOf<Marker>()
            o.optJSONArray("markers")?.let { m ->
                for (j in 0 until m.length()) {
                    val mo = m.getJSONObject(j)
                    markers += Marker(mo.optLong("ms"), mo.optString("label"))
                }
            }
            val ages = mutableListOf<Int>()
            o.optJSONArray("ages")?.let { a -> for (j in 0 until a.length()) ages += a.optInt(j) }
            list += VaultItem(
                id = o.getString("id"),
                title = o.getString("title"),
                kind = if (o.getString("kind") == "PHOTO") MediaKind.PHOTO else MediaKind.VIDEO,
                hash = o.optString("hash", ""),
                sizeBytes = o.optLong("size", 0L),
                durationMs = o.optLong("duration", 0L),
                addedAt = o.optLong("added", 0L),
                keyWrap = o.getString("keyWrap"),
                collection = o.optString("collection", DEFAULT_COLLECTION),
                favorite = o.optBoolean("favorite", false),
                progressMs = o.optLong("progress", 0L),
                lastOpened = o.optLong("lastOpened", 0L),
                hasThumb = o.optBoolean("thumb", false),
                tags = o.optJSONArray("tags").strings(),
                description = o.optString("description", ""),
                rating = o.optInt("rating", 0).coerceIn(0, 5),
                ages = cleanAges(ages),
                markers = markers.sortedBy { it.ms },
                views = o.optInt("views", 0),
                width = o.optInt("w", 0),
                height = o.optInt("h", 0),
                sourceName = o.optString("source", ""),
                autoTitle = o.optBoolean("autoTitle", false)
            )
        }
        return list to Settings.fromJson(settingsJson)
    }

    private fun saveLibrary() {
        val key = master ?: return
        // Never overwrite a library we failed to read — that would wipe it.
        if (loadError.value != null) return
        val arr = JSONArray()
        items.toList().forEach { item ->
            val markers = JSONArray()
            item.markers.forEach { markers.put(JSONObject().put("ms", it.ms).put("label", it.label)) }
            arr.put(
                JSONObject()
                    .put("id", item.id)
                    .put("title", item.title)
                    .put("kind", item.kind.name)
                    .put("hash", item.hash)
                    .put("size", item.sizeBytes)
                    .put("duration", item.durationMs)
                    .put("added", item.addedAt)
                    .put("keyWrap", item.keyWrap)
                    .put("collection", item.collection)
                    .put("favorite", item.favorite)
                    .put("progress", item.progressMs)
                    .put("lastOpened", item.lastOpened)
                    .put("thumb", item.hasThumb)
                    .put("tags", JSONArray(item.tags))
                    .put("description", item.description)
                    .put("rating", item.rating)
                    .put("ages", JSONArray(item.ages))
                    .put("markers", markers)
                    .put("views", item.views)
                    .put("w", item.width)
                    .put("h", item.height)
                    .put("source", item.sourceName)
                    .put("autoTitle", item.autoTitle)
            )
        }
        val doc = JSONObject()
            .put("v", 2)
            .put("items", arr)
            .put("settings", settings.value.toJson())
        synchronized(this) {
            // Keep the previous good copy, then swap the new file in atomically.
            if (libraryFile.exists()) libraryFile.copyTo(libraryBackup, overwrite = true)
            writeAtomically(libraryFile, Crypto.gcmEncrypt(key, doc.toString().toByteArray()))
        }
    }

    /** Write to a temp file, fsync, then rename over the target — a crash never leaves half a file. */
    private fun writeAtomically(target: File, bytes: ByteArray) {
        val tmp = if (target == libraryFile) libraryTemp else File(target.parentFile, target.name + ".tmp")
        java.io.FileOutputStream(tmp).use { out ->
            out.write(bytes)
            out.flush()
            out.fd.sync()
        }
        if (!tmp.renameTo(target)) {
            tmp.copyTo(target, overwrite = true)
            tmp.delete()
        }
    }

    private suspend fun persist() = withContext(Dispatchers.IO) { saveLibrary() }

    // ---------- files ----------

    fun mediaFile(item: VaultItem): File = File(mediaDir, item.id + ".bin")
    private fun thumbFile(id: String): File = File(thumbDir, "$id.bin")

    fun keyFor(item: VaultItem): SecretKey =
        Crypto.unwrapKey(master ?: error("locked"), item.keyWrap)

    fun storageBytes(): Long = items.sumOf { it.sizeBytes }

    // ---------- import ----------

    data class ImportResult(val added: Int, val duplicates: Int, val failed: Int)

    suspend fun importMedia(uris: List<Uri>): ImportResult = withContext(Dispatchers.IO) {
        val key = master ?: return@withContext ImportResult(0, 0, uris.size)
        val resolver = appContext.contentResolver
        var added = 0
        var dupes = 0
        var failed = 0
        val known = items.map { it.hash }.toMutableSet()

        uris.forEachIndexed { index, uri ->
            withContext(Dispatchers.Main) {
                busyMessage.value = "Encrypting ${index + 1} of ${uris.size}"
            }
            try {
                val mime = resolver.getType(uri) ?: ""
                val kind = if (mime.startsWith("image")) MediaKind.PHOTO else MediaKind.VIDEO
                val name = displayName(uri) ?: "Untitled"
                val id = UUID.randomUUID().toString()
                val fileKey = Crypto.newKey()
                val dest = File(mediaDir, "$id.bin")

                val stream = resolver.openInputStream(uri)
                    ?: throw IllegalStateException("cannot read source")
                val (hash, size) = stream.use { input ->
                    Crypto.encryptToFile(input, dest, fileKey)
                }

                if (hash in known) {
                    // Same bytes already in the vault — never store or list it twice.
                    dest.delete()
                    dupes++
                    return@forEachIndexed
                }
                known += hash

                var duration = 0L
                var width = 0
                var height = 0
                var poster: Bitmap? = null
                if (kind == MediaKind.VIDEO) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(appContext, uri)
                        duration = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_DURATION
                        )?.toLongOrNull() ?: 0L
                        width = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH
                        )?.toIntOrNull() ?: 0
                        height = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT
                        )?.toIntOrNull() ?: 0
                        val rotation = retriever.extractMetadata(
                            MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION
                        )?.toIntOrNull() ?: 0
                        if (rotation == 90 || rotation == 270) {
                            val w = width; width = height; height = w
                        }
                        poster = retriever.getFrameAtTime(
                            (duration * 1000L) / 4,
                            MediaMetadataRetriever.OPTION_CLOSEST_SYNC
                        )
                    } catch (_: Exception) {
                    } finally {
                        try { retriever.release() } catch (_: Exception) {}
                    }
                } else {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    try {
                        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                        width = bounds.outWidth.coerceAtLeast(0)
                        height = bounds.outHeight.coerceAtLeast(0)
                    } catch (_: Exception) {
                    }
                    poster = decodeSampled(uri)
                }

                val hasThumb = poster != null
                if (poster != null) writeThumb(id, fileKey, poster)

                var item = VaultItem(
                    id = id,
                    title = name.substringBeforeLast('.').ifBlank { "Untitled" },
                    kind = kind,
                    hash = hash,
                    sizeBytes = size,
                    durationMs = duration,
                    addedAt = System.currentTimeMillis(),
                    keyWrap = Crypto.wrapKey(key, fileKey),
                    collection = DEFAULT_COLLECTION,
                    favorite = false,
                    progressMs = 0L,
                    lastOpened = 0L,
                    hasThumb = hasThumb,
                    width = width,
                    height = height,
                    sourceName = name
                )
                val s = settings.value
                val number = items.size + 1
                if (s.autoNameOnImport) {
                    item = item.copy(title = TitleGenerator.title(item, number, s), autoTitle = true)
                }
                if (s.autoDescribe) {
                    item = item.copy(description = TitleGenerator.description(item, s))
                }
                val finalItem = item
                withContext(Dispatchers.Main) { items.add(0, finalItem) }
                added++
            } catch (e: Exception) {
                failed++
            }
        }
        saveLibrary()
        withContext(Dispatchers.Main) { busyMessage.value = null }
        ImportResult(added, dupes, failed)
    }

    private fun displayName(uri: Uri): String? {
        return try {
            appContext.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0 && c.moveToFirst()) c.getString(idx) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun decodeSampled(uri: Uri, max: Int = 1280): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, bounds)
            }
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, max)
            }
            appContext.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun sampleFor(w: Int, h: Int, max: Int): Int {
        var sample = 1
        while (w / sample > max || h / sample > max) sample *= 2
        return sample
    }

    private fun writeThumb(id: String, fileKey: SecretKey, bitmap: Bitmap) {
        val scaled = scaleTo(bitmap, 960)
        val bos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 88, bos)
        val bytes = bos.toByteArray()
        Crypto.encryptToFile(bytes.inputStream(), thumbFile(id), fileKey)
        thumbCache.remove(id)
    }

    private fun scaleTo(src: Bitmap, maxDim: Int): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= maxDim && h <= maxDim) return src
        val ratio = minOf(maxDim.toFloat() / w, maxDim.toFloat() / h)
        return Bitmap.createScaledBitmap(src, (w * ratio).toInt(), (h * ratio).toInt(), true)
    }

    // ---------- reading ----------

    suspend fun thumbnail(item: VaultItem): Bitmap? = withContext(Dispatchers.IO) {
        thumbCache.get(item.id)?.let { return@withContext it }
        if (!item.hasThumb || master == null) return@withContext null
        try {
            val bytes = Crypto.decryptFile(thumbFile(item.id), keyFor(item))
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bmp != null) thumbCache.put(item.id, bmp)
            bmp
        } catch (e: Exception) {
            null
        }
    }

    /** Full photo, downsampled to at most [max] px on the long edge so huge images can't crash the app. */
    suspend fun photo(item: VaultItem, max: Int = 2560): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val bytes = Crypto.decryptFile(mediaFile(item), keyFor(item))
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, max)
            }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
        } catch (e: Throwable) {
            null
        }
    }

    /** Pulls a frame out of the still-encrypted video, for the thumbnail picker. */
    suspend fun frameAt(item: VaultItem, positionMs: Long): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        var source: EncryptedMediaDataSource? = null
        try {
            source = EncryptedMediaDataSource(mediaFile(item), keyFor(item))
            retriever.setDataSource(source)
            retriever.getFrameAtTime(positionMs * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
            try { source?.close() } catch (_: Exception) {}
        }
    }

    // ---------- edits ----------

    fun find(id: String): VaultItem? = items.firstOrNull { it.id == id }

    private suspend fun update(id: String, change: (VaultItem) -> VaultItem) {
        val index = items.indexOfFirst { it.id == id }
        if (index >= 0) items[index] = change(items[index])
        persist()
    }

    private suspend fun replace(item: VaultItem, updated: VaultItem) = update(item.id) { updated }

    suspend fun rename(item: VaultItem, title: String) =
        update(item.id) { it.copy(title = title.trim().ifBlank { it.title }, autoTitle = false) }

    /** Saves the edit sheet: title, description, ages and rating in one write. */
    suspend fun saveDetails(
        id: String,
        title: String,
        description: String,
        ages: List<Int>,
        rating: Int,
        titleIsAuto: Boolean
    ) = update(id) {
        it.copy(
            title = title.trim().ifBlank { it.title },
            description = description.trim(),
            ages = cleanAges(ages),
            rating = rating.coerceIn(0, 5),
            autoTitle = titleIsAuto
        )
    }

    /** Only adults: anything under 18 (or nonsense) is dropped. */
    fun cleanAges(ages: List<Int>): List<Int> =
        ages.filter { it in MIN_AGE..MAX_AGE }.distinct()

    suspend fun setRating(item: VaultItem, rating: Int) =
        update(item.id) { it.copy(rating = rating.coerceIn(0, 5)) }

    suspend fun setCollection(item: VaultItem, collection: String) =
        update(item.id) { it.copy(collection = collection.trim().ifBlank { DEFAULT_COLLECTION }) }

    suspend fun toggleFavorite(item: VaultItem) =
        update(item.id) { it.copy(favorite = !it.favorite) }

    suspend fun setProgress(item: VaultItem, positionMs: Long, durationMs: Long) {
        if (find(item.id) == null) return
        update(item.id) { fresh ->
            fresh.copy(
                progressMs = positionMs,
                durationMs = if (durationMs > 0) durationMs else fresh.durationMs,
                lastOpened = System.currentTimeMillis()
            )
        }
    }

    suspend fun recordView(item: VaultItem) =
        update(item.id) { it.copy(views = it.views + 1, lastOpened = System.currentTimeMillis()) }

    suspend fun clearProgress(item: VaultItem) = replace(item, item.copy(progressMs = 0L))

    suspend fun addMarker(item: VaultItem, ms: Long, label: String) = update(item.id) {
        it.copy(markers = (it.markers + Marker(ms, label.trim().ifBlank { "Moment" })).sortedBy { m -> m.ms })
    }

    suspend fun removeMarker(item: VaultItem, marker: Marker) =
        update(item.id) { it.copy(markers = it.markers - marker) }

    suspend fun setThumbnail(item: VaultItem, bitmap: Bitmap) {
        withContext(Dispatchers.IO) { writeThumb(item.id, keyFor(item), bitmap) }
        update(item.id) { it.copy(hasThumb = true) }
    }

    suspend fun setThumbnailFromUri(item: VaultItem, uri: Uri) {
        val bmp = withContext(Dispatchers.IO) { decodeSampled(uri) } ?: return
        setThumbnail(item, bmp)
    }

    suspend fun delete(item: VaultItem) = withContext(Dispatchers.IO) {
        mediaFile(item).delete()
        thumbFile(item.id).delete()
        thumbCache.remove(item.id)
        withContext(Dispatchers.Main) { items.removeAll { it.id == item.id } }
        saveLibrary()
    }

    // ---------- naming ----------

    fun generateTitle(item: VaultItem): String = TitleGenerator.title(item, numberOf(item), settings.value)
    fun generateDescription(item: VaultItem): String = TitleGenerator.description(item, settings.value)

    /** Re-run the writer on an item whose title is still auto-generated. */
    private fun refreshAuto(item: VaultItem): VaultItem {
        val s = settings.value
        if (!s.retitleOnTagChange) return item
        var out = item
        if (item.autoTitle) out = out.copy(title = TitleGenerator.title(out, numberOf(out), s))
        if (s.autoDescribe) out = out.copy(description = TitleGenerator.description(out, s))
        return out
    }

    /** Rename everything. [onlyAuto] keeps any title the user typed by hand. */
    suspend fun regenerateAll(onlyAuto: Boolean) {
        val s = settings.value
        items.indices.forEach { i ->
            val item = items[i]
            if (!onlyAuto || item.autoTitle) {
                items[i] = item.copy(
                    title = TitleGenerator.title(item, numberOf(item), s),
                    description = if (s.autoDescribe) TitleGenerator.description(item, s) else item.description,
                    autoTitle = true
                )
            }
        }
        persist()
    }

    // ---------- tags ----------

    fun collections(): List<String> =
        items.map { it.collection }.distinct().sortedBy { it.lowercase() }

    fun countIn(collection: String): Int = items.count { it.collection == collection }

    fun tags(): List<String> =
        items.flatMap { it.tags }.distinct().sortedBy { it.lowercase() }

    /** Tag → number of items carrying it. */
    fun tagCounts(): Map<String, Int> =
        items.flatMap { it.tags }.groupingBy { it }.eachCount()

    fun itemsIn(collection: String): List<VaultItem> =
        items.filter { it.collection == collection }.sortedByDescending { it.addedAt }

    fun itemsTagged(tag: String): List<VaultItem> =
        items.filter { item ->
            item.tags.any { it.equals(tag, ignoreCase = true) } ||
                AutoTags.of(item).any { it.equals(tag, ignoreCase = true) }
        }.sortedByDescending { it.addedAt }

    fun itemsAged(min: Int, max: Int): List<VaultItem> =
        items.filter { item -> item.ages.any { it in min..max } }.sortedByDescending { it.addedAt }

    /** Cover art for a folder tile — first item in it that actually has artwork. */
    fun coverOf(collection: String): VaultItem? =
        items.firstOrNull { it.collection == collection && it.hasThumb }
            ?: items.firstOrNull { it.collection == collection }

    fun coverOfTag(tag: String): VaultItem? {
        val tagged = items.filter { item -> item.tags.any { it.equals(tag, ignoreCase = true) } }
        return tagged.firstOrNull { it.hasThumb } ?: tagged.firstOrNull()
    }

    suspend fun setTags(item: VaultItem, tags: List<String>) {
        val cleaned = tags.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        update(item.id) { refreshAuto(it.copy(tags = cleaned)) }
    }

    suspend fun addTagTo(ids: Set<String>, tag: String) = applyTagChanges(ids, setOf(tag), emptySet())

    /** Bulk edit from the tag editor: add [add] and remove [remove] on every item in [ids]. */
    suspend fun applyTagChanges(ids: Set<String>, add: Set<String>, remove: Set<String>) {
        val addClean = add.map { it.trim() }.filter { it.isNotBlank() }
        ids.forEach { id ->
            val index = items.indexOfFirst { it.id == id }
            if (index >= 0) {
                val current = items[index]
                val kept = current.tags.filterNot { t -> remove.any { it.equals(t, ignoreCase = true) } }
                val extra = addClean.filter { a -> kept.none { it.equals(a, ignoreCase = true) } }
                val next = kept + extra
                if (next != current.tags) items[index] = refreshAuto(current.copy(tags = next))
            }
        }
        persist()
    }

    /** Bulk age edit — values under 18 are always dropped. */
    suspend fun applyAgeChanges(ids: Set<String>, add: Set<Int>, remove: Set<Int>) {
        ids.forEach { id ->
            val index = items.indexOfFirst { it.id == id }
            if (index >= 0) {
                val current = items[index]
                val next = cleanAges(current.ages.filterNot { it in remove } + add)
                if (next != current.ages) items[index] = refreshAuto(current.copy(ages = next))
            }
        }
        persist()
    }

    suspend fun moveToCollection(ids: Set<String>, collection: String) {
        val name = collection.trim().ifBlank { DEFAULT_COLLECTION }
        ids.forEach { id ->
            val index = items.indexOfFirst { it.id == id }
            if (index >= 0) items[index] = items[index].copy(collection = name)
        }
        persist()
    }

    suspend fun deleteMany(ids: Set<String>) {
        ids.mapNotNull { id -> items.firstOrNull { it.id == id } }.forEach { delete(it) }
    }

    suspend fun rateMany(ids: Set<String>, rating: Int) {
        ids.forEach { id -> items.indexOfFirst { it.id == id }.takeIf { it >= 0 }?.let { i ->
            items[i] = items[i].copy(rating = rating.coerceIn(0, 5))
        } }
        persist()
    }

    /** Renaming a folder just re-labels its items — nothing is re-encrypted. */
    suspend fun renameCollection(from: String, to: String) {
        val name = to.trim().ifBlank { return }
        items.indices.forEach { index ->
            if (items[index].collection == from) items[index] = items[index].copy(collection = name)
        }
        persist()
    }

    /** Removing a folder never removes media — the items fall back to the default folder. */
    suspend fun deleteCollection(name: String) {
        if (name == DEFAULT_COLLECTION) return
        items.indices.forEach { index ->
            if (items[index].collection == name) {
                items[index] = items[index].copy(collection = DEFAULT_COLLECTION)
            }
        }
        persist()
    }

    // ---------- settings ----------

    suspend fun updateSettings(change: (Settings) -> Settings) {
        settings.value = change(settings.value)
        persist()
    }

    suspend fun addCustomTag(groupId: String, name: String) {
        val clean = name.trim()
        if (clean.isBlank()) return
        updateSettings { s ->
            val list = s.customTags[groupId].orEmpty()
            if (list.any { it.equals(clean, ignoreCase = true) }) s
            else s.copy(customTags = s.customTags + (groupId to (list + clean)))
        }
    }

    suspend fun removeCustomTag(groupId: String, name: String) {
        updateSettings { s ->
            s.copy(customTags = s.customTags + (groupId to s.customTags[groupId].orEmpty().filterNot { it == name }))
        }
    }

    /** What to show as the title — discreet mode swaps in a neutral name. */
    fun displayTitle(item: VaultItem): String {
        val s = settings.value
        if (s.discreet) return (if (item.kind == MediaKind.PHOTO) "Photo " else "Clip ") + numberOf(item)
        return item.title
    }
}
