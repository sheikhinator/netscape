package com.netscape.vault.data

/**
 * Built-in tag library. Every tag belongs to exactly one group; users can add their own
 * tags to any group (stored in [Settings.customTags]) and they behave like the presets.
 *
 * Presets cover consensual adult content only. Nothing youth-coded, non-consensual or
 * otherwise illegal is shipped here.
 */
data class TagDef(val name: String, val emoji: String)

data class TagGroup(
    val id: String,
    val name: String,
    val emoji: String,
    val tags: List<TagDef>
)

object TagCatalog {

    const val CUSTOM_GROUP = "custom"

    private fun t(vararg pairs: Pair<String, String>) = pairs.map { TagDef(it.first, it.second) }

    private val raw: List<TagGroup> = listOf(
        TagGroup(
            "category", "Spicy Categories", "🔥", t(
                "Hot" to "🔥", "Spicy" to "🌶️", "Romantic" to "💋", "Naughty" to "😈",
                "Booty" to "🍑", "Late Night" to "🌙", "Steamy" to "💦", "VIP" to "👑",
                "Premium" to "💎", "Extreme Heat" to "🥵", "Soft & Sweet" to "😇",
                "Roleplay" to "🎭", "Photo Shoots" to "📸", "Homemade Heat" to "🎥",
                "Vacation Vibes" to "🏝️", "Just Us" to "💑", "Kinky" to "⛓️",
                "Date Night" to "🍷", "Quickies" to "⚡", "Full Scenes" to "🎬",
                "Special Occasion" to "🥂", "Chill" to "🧊", "Queer" to "🌈",
                "Solo Play" to "🫦", "Throwbacks" to "📼", "Best Of" to "🏆",
                "Teasers" to "👀", "Sexy Selfies" to "🤳", "Tonight's Pick" to "🎯",
                "Guilty Pleasures" to "🍫"
            )
        ),
        TagGroup(
            "heat", "Heat Level", "🌡️", t(
                "Mild" to "😇", "Sexy" to "😏", "Explicit" to "🔥", "Animated" to "🎨"
            )
        ),
        TagGroup(
            "age", "Age", "🎂", t(
                "Young Adult" to "✨", "Adult" to "💋", "Mature" to "🍷"
            )
        ),
        TagGroup(
            "who", "Who's In It", "👥", t(
                "Solo Female" to "👩", "Solo Male" to "👨", "Couple" to "💑",
                "Straight" to "⚤", "Lesbian" to "👩‍❤️‍👩", "Gay" to "👨‍❤️‍👨",
                "Bisexual" to "💗", "Trans" to "🏳️‍⚧️", "Non-binary" to "⚧️",
                "Threesome FFM" to "👩‍👩‍👨", "Threesome MMF" to "👨‍👨‍👩", "Threesome" to "3️⃣",
                "Foursome" to "4️⃣", "Group" to "👯", "Orgy" to "🎉", "Swingers" to "🔄",
                "Couple + Guest" to "➕", "Me" to "🙋", "Partner" to "❤️", "Us" to "💞",
                "Ex" to "💔", "Friend with Benefits" to "🤝", "Hookup" to "🌃",
                "MILF" to "💃", "DILF" to "🕺", "Amateur Couple" to "🏠",
                "Performer" to "⭐"
            )
        ),
        TagGroup(
            "type", "Type & Format", "🎬", t(
                "Full Video" to "🎬", "Short Clip" to "✂️", "Compilation" to "🎞️",
                "Highlights" to "✨", "Uncut" to "📼", "Trailer" to "🎟️", "Loop" to "🔁",
                "GIF" to "🌀", "Photo Set" to "🖼️", "Single Photo" to "📷",
                "Selfie" to "🤳", "Mirror Selfie" to "🪞", "Nude" to "🍑",
                "Semi-Nude" to "🙈", "Boudoir" to "🌹", "Artistic Nude" to "🎨",
                "Tease" to "👀", "Sext" to "💬", "Screenshot" to "📱", "Video Call" to "📞",
                "Livestream" to "🔴", "Webcam" to "💻", "Story" to "📲",
                "Behind the Scenes" to "🎥", "Photo Shoot" to "📸", "Audio" to "🎧",
                "ASMR" to "👂", "JOI" to "🗣️", "Striptease Video" to "💃"
            )
        ),
        TagGroup(
            "position", "Positions", "🤸", t(
                "Missionary" to "🛏️", "Legs Up" to "🦵", "Legs on Shoulders" to "🤸",
                "Butterfly" to "🦋", "Cowgirl" to "🤠", "Reverse Cowgirl" to "🔄",
                "Squatting Cowgirl" to "🐸", "Leaning-Back Cowgirl" to "🌙",
                "Doggy Style" to "🐶", "Standing Doggy" to "🧍", "Prone Bone" to "🛌",
                "Spooning" to "🥄", "Side-by-Side" to "↔️", "Standing" to "🧍‍♀️",
                "Against the Wall" to "🧱", "Carry / Lift" to "🏋️", "Wheelbarrow" to "🛒",
                "Lotus" to "🪷", "Lap Sitting" to "🪑", "Chair" to "💺",
                "Edge of the Bed" to "🛏️", "Bent Over" to "↘️", "Table Top" to "🪵",
                "Kneeling" to "🧎", "Face to Face" to "😍", "69" to "♋",
                "Face Sitting" to "🍑", "Piledriver" to "⤵️", "Pretzel" to "🥨",
                "Scissoring" to "✂️", "Bridge" to "🌉", "Amazon" to "🏹",
                "Reverse Missionary" to "🔃", "Frog" to "🐸", "Downward Dog" to "🐕",
                "Shower Standing" to "🚿", "Sofa Side" to "🛋️", "On Top" to "⬆️",
                "Bottom" to "⬇️", "Straddling" to "🐎"
            )
        ),
        TagGroup(
            "act", "Acts", "😈", t(
                "Kissing" to "💋", "Making Out" to "😘", "Foreplay" to "🔥",
                "Massage" to "💆", "Striptease" to "💃", "Teasing" to "👀",
                "Lap Dance" to "🪩", "Grinding" to "🌀", "Dry Humping" to "👖",
                "Masturbation" to "✋", "Mutual Masturbation" to "🙌", "Fingering" to "☝️",
                "Handjob" to "🤲", "Oral" to "👅", "Blowjob" to "🍆", "Cunnilingus" to "🍑",
                "Deepthroat" to "😮", "Rimming" to "💫", "Titjob" to "🍈",
                "Footjob" to "🦶", "Vaginal" to "💞", "Anal" to "🍑",
                "Double Penetration" to "✌️", "Pegging" to "🔄", "Strap-on" to "🎗️",
                "Fisting" to "✊", "Squirting" to "💦", "Creampie" to "🥧",
                "Cumshot" to "💥", "Facial" to "😳", "Swallow" to "😋",
                "Edging" to "⏳", "Orgasm" to "🤯", "Multiple Orgasms" to "🎆",
                "Dirty Talk" to "🗣️", "Moaning" to "🎶", "Hair Pulling" to "💇",
                "Biting" to "😬", "Scratching" to "🐾", "Cuddling" to "🫂",
                "Aftercare" to "🩹", "Sixty-Nine Oral" to "♋", "Tribbing" to "💗",
                "Shower Sex" to "🚿", "Quickie" to "⚡", "Morning Sex" to "🌅",
                "Make-Up Sex" to "💔", "Toy Play" to "🪄"
            )
        ),
        TagGroup(
            "body", "Body Focus", "🍑", t(
                "Face" to "😊", "Eyes" to "👁️", "Lips" to "👄", "Tongue" to "👅",
                "Neck" to "🦢", "Shoulders" to "💪", "Collarbone" to "✨",
                "Breasts" to "🍒", "Nipples" to "🎯", "Cleavage" to "🍈", "Chest" to "🫀",
                "Abs" to "🍫", "Belly" to "🫄", "Back" to "🔙", "Lower Back" to "〰️",
                "Hips" to "💃", "Waist" to "⌛", "Butt" to "🍑", "Thighs" to "🦵",
                "Legs" to "🦿", "Calves" to "🦵", "Feet" to "🦶", "Toes" to "🦶",
                "Hands" to "🤲", "Arms" to "💪", "Hair" to "💇", "Pussy" to "🌸",
                "Dick" to "🍆", "Balls" to "⚽", "Full Body" to "🧍",
                "Curves" to "〽️", "Tan Lines" to "🏖️", "Tattoo Close-up" to "🖋️"
            )
        ),
        TagGroup(
            "look", "Look & Body Type", "💁", t(
                "Petite" to "🧚", "Slim" to "🪶", "Athletic" to "🏃", "Fit" to "💪",
                "Curvy" to "〽️", "Thick" to "🍑", "BBW" to "💖", "Muscular" to "🏋️",
                "Tall" to "📏", "Short" to "🤏", "Big Tits" to "🍈", "Small Tits" to "🍒",
                "Natural Tits" to "🌿", "Enhanced" to "💉", "Big Ass" to "🍑",
                "Bubble Butt" to "🫧", "Big Dick" to "🍆", "Blonde" to "👱‍♀️",
                "Brunette" to "👩", "Redhead" to "👩‍🦰", "Black Hair" to "🖤",
                "Dyed Hair" to "🌈", "Short Hair" to "💇‍♀️", "Long Hair" to "💁‍♀️",
                "Curly Hair" to "➰", "Ponytail" to "🎀", "Tattoos" to "🖋️",
                "Piercings" to "📌", "Freckles" to "🟤", "Shaved" to "🪒",
                "Trimmed" to "✂️", "Hairy" to "🐻", "Bearded" to "🧔", "Glasses" to "👓",
                "Makeup" to "💄", "Natural Look" to "🌿", "Nails Done" to "💅",
                "Tanned" to "☀️", "Pale" to "🤍"
            )
        ),
        TagGroup(
            "outfit", "Outfit & Lingerie", "👙", t(
                "Naked" to "🍑", "Topless" to "🙈", "Lingerie" to "👙",
                "Bra & Panties" to "🩲", "Thong" to "〽️", "G-String" to "🧵",
                "Stockings" to "🧦", "Fishnets" to "🕸️", "Garter Belt" to "🎗️",
                "Bodysuit" to "🩱", "Corset" to "⌛", "Babydoll" to "🎀",
                "Robe" to "🥋", "Towel" to "🧖", "Bikini" to "👙", "Swimsuit" to "🩱",
                "Yoga Pants" to "🧘", "Leggings" to "🦵", "Mini Skirt" to "👗",
                "Dress" to "👗", "Heels" to "👠", "Boots" to "👢", "Costume" to "🎭",
                "Uniform" to "👮", "Nurse Outfit" to "👩‍⚕️", "Maid Outfit" to "🧹",
                "Latex" to "🖤", "Leather" to "🧥", "Sheer" to "🫧",
                "Shirt Only" to "👔", "Oversized Hoodie" to "🧥", "Jeans" to "👖",
                "Pajamas" to "🌙", "Socks" to "🧦", "Collar" to "⭕", "Harness" to "⛓️",
                "Jewelry" to "💍", "Sports Bra" to "🏃‍♀️", "Crop Top" to "👚"
            )
        ),
        TagGroup(
            "kink", "Kink & Fetish", "⛓️", t(
                "BDSM" to "⛓️", "Bondage" to "🪢", "Rope" to "🪢", "Handcuffs" to "🔗",
                "Blindfold" to "🙈", "Gag" to "🤐", "Dom / Sub" to "👑",
                "Femdom" to "👸", "Maledom" to "🤴", "Spanking" to "🖐️",
                "Paddle" to "🏓", "Whip / Flogger" to "🪶", "Wax Play" to "🕯️",
                "Ice Play" to "🧊", "Sensory Play" to "✨", "Tease & Denial" to "⏳",
                "Chastity" to "🔒", "Worship" to "🙏", "Foot Fetish" to "🦶",
                "Latex Fetish" to "🖤", "Leather Fetish" to "🧥",
                "Stockings Fetish" to "🧦", "Exhibitionism" to "👀", "Voyeur Roleplay" to "🔭",
                "Cuckold" to "🦌", "Hotwife" to "🔥", "Praise" to "💖",
                "Degradation" to "🗯️", "Roleplay Scene" to "🎭", "Boss & Secretary" to "💼",
                "Nurse & Patient" to "🩺", "Stranger Fantasy" to "🕶️",
                "Massage Parlor" to "💆", "Pizza Delivery" to "🍕", "Personal Trainer" to "🏋️",
                "Photographer & Model" to "📸", "Cosplay" to "🦸", "Pet Play" to "🐾",
                "Size Difference" to "📏","Breeding Kink" to "🥚",
                "Marking" to "🖊️", "Primal" to "🐺"
            )
        ),
        TagGroup(
            "toys", "Toys & Props", "🪄", t(
                "Vibrator" to "📳", "Wand" to "🪄", "Dildo" to "🍆", "Butt Plug" to "💎",
                "Anal Beads" to "📿", "Cock Ring" to "⭕", "Strap-on Toy" to "🎗️",
                "Fleshlight" to "🔦", "Remote Toy" to "📡", "Suction Toy" to "🌬️",
                "Nipple Clamps" to "🗜️", "Restraints" to "🔗", "Feather" to "🪶",
                "Massage Oil" to "🫗", "Lube" to "💧", "Ice Cubes" to "🧊",
                "Whipped Cream" to "🍦", "Chocolate" to "🍫", "Champagne" to "🍾",
                "Candles" to "🕯️", "Mirror" to "🪞", "Sex Swing" to "🎠",
                "Wedge Pillow" to "🔺", "Machine" to "⚙️", "Camera Toy" to "📷"
            )
        ),
        TagGroup(
            "setting", "Setting & Place", "🛏️", t(
                "Bedroom" to "🛏️", "Living Room" to "🛋️", "Couch" to "🛋️",
                "Kitchen" to "🍳", "Bathroom" to "🚽", "Shower" to "🚿", "Bathtub" to "🛁",
                "Pool" to "🏊", "Hot Tub" to "♨️", "Sauna" to "🧖", "Beach" to "🏖️",
                "Outdoors" to "🌳", "Forest" to "🌲", "Garden" to "🌷",
                "Balcony" to "🌆", "Rooftop" to "🏙️", "Car" to "🚗", "Back Seat" to "🚙",
                "Hotel" to "🏨", "Vacation Rental" to "🏡", "Office" to "🏢",
                "Desk" to "🖥️", "Gym" to "🏋️", "Locker Room" to "🚪", "Camping" to "⛺",
                "Boat" to "⛵", "Stairs" to "🪜", "Floor" to "🟫", "Table" to "🪵",
                "Dressing Room" to "👗", "Studio" to "🎬", "Mirror Wall" to "🪞",
                "Window" to "🪟", "Laundry Room" to "🧺", "Club" to "🪩", "Party" to "🎉"
            )
        ),
        TagGroup(
            "mood", "Mood & Vibe", "💫", t(
                "Passionate" to "❤️‍🔥", "Sensual" to "🌹", "Slow" to "🐢", "Rough" to "💥",
                "Intense" to "⚡", "Playful" to "😜", "Loving" to "🥰", "Wild" to "🐆",
                "Dominant" to "👑", "Submissive" to "🎀", "Giggly" to "🤭",
                "Lazy Sunday" to "☕", "Marathon" to "🏃", "Intimate" to "🕯️",
                "Dirty" to "😈", "Sweet" to "🍬", "Teasing Vibe" to "😏",
                "Tender" to "🤍", "Energetic" to "🔋", "Needy" to "🥺", "Spontaneous" to "🎲",
                "Seductive" to "🐍", "Confident" to "😎", "Shy" to "☺️",
                "Cinematic" to "🎞️", "Nostalgic" to "📼", "Loud" to "📢", "Quiet" to "🤫"
            )
        ),
        TagGroup(
            "camera", "Camera & Style", "🎥", t(
                "POV" to "👁️", "Close-up" to "🔍", "Wide Shot" to "🖼️",
                "Tripod" to "📐", "Handheld" to "🤳", "Slow Motion" to "🐌",
                "Timelapse" to "⏩", "Homemade" to "🏠", "Amateur" to "🎥",
                "Professional" to "🎬", "Phone Video" to "📱", "Vertical Video" to "📲",
                "Low Light" to "🌑", "Candlelight" to "🕯️", "Neon" to "💜",
                "Natural Light" to "☀️", "Black & White" to "⚫", "Soft Focus" to "🌫️",
                "Split Screen" to "🪟", "Multi-Angle" to "🎥", "Mirror Shot" to "🪞",
                "Face Visible" to "😊", "No Face" to "🙈", "With Sound" to "🔊",
                "No Sound" to "🔇", "Music" to "🎵", "Subtitled" to "💬",
                "High Quality" to "💎", "Retro Film" to "📽️"
            )
        ),
        TagGroup(
            "time", "Time & Occasion", "🌙", t(
                "Morning" to "🌅", "Afternoon" to "🌤️", "Evening" to "🌇", "Midnight" to "🌙",
                "Weekend" to "🗓️", "Holiday" to "🎄", "Vacation" to "✈️",
                "Honeymoon" to "💍", "Anniversary" to "💝", "Birthday" to "🎂",
                "Valentine's Day" to "💘", "New Year's" to "🎆", "Halloween" to "🎃",
                "Christmas" to "🎅", "Summer" to "☀️", "Winter" to "❄️", "Spring" to "🌸",
                "Autumn" to "🍂", "Road Trip" to "🚘", "First Time Together" to "🥇",
                "Reunion" to "🤗", "Long Distance" to "📡", "Staycation" to "🏠"
            )
        ),
        TagGroup("people", "People", "👤", emptyList()),
        TagGroup(CUSTOM_GROUP, "Custom", "🏷️", emptyList())
    )

    /** Presets with duplicate names (across groups) removed — first occurrence wins. */
    val groups: List<TagGroup> = run {
        val seen = HashSet<String>()
        raw.map { g -> g.copy(tags = g.tags.filter { seen.add(it.name.lowercase()) }) }
    }

    private val byName: Map<String, Pair<TagGroup, TagDef>> =
        groups.flatMap { g -> g.tags.map { it.name.lowercase() to (g to it) } }.toMap()

    fun group(id: String): TagGroup? = groups.firstOrNull { it.id == id }

    /** All tags in a group: presets first, then the user's own additions. */
    fun tagsIn(groupId: String, settings: Settings): List<TagDef> {
        val g = group(groupId) ?: return emptyList()
        val custom = settings.customTags[groupId].orEmpty()
            .filter { name -> g.tags.none { it.name.equals(name, ignoreCase = true) } }
            .map { TagDef(it, g.emoji) }
        return g.tags + custom
    }

    fun groupOf(tag: String, settings: Settings): TagGroup {
        byName[tag.lowercase()]?.let { return it.first }
        settings.customTags.forEach { (gid, list) ->
            if (list.any { it.equals(tag, ignoreCase = true) }) group(gid)?.let { return it }
        }
        return group(CUSTOM_GROUP)!!
    }

    fun emojiOf(tag: String, settings: Settings): String =
        byName[tag.lowercase()]?.second?.emoji ?: groupOf(tag, settings).emoji

    /** Tags on an item that belong to [groupId]. */
    fun pick(item: VaultItem, groupId: String, settings: Settings): List<String> =
        item.tags.filter { groupOf(it, settings).id == groupId }
}

/** Tags computed from the file itself — never stored, always searchable. */
object AutoTags {
    fun of(item: VaultItem): List<String> {
        val out = mutableListOf<String>()
        out += if (item.kind == MediaKind.VIDEO) "Video" else "Photo"
        if (item.kind == MediaKind.VIDEO && item.durationMs > 0) {
            val min = item.durationMs / 60_000
            out += when {
                min < 1 -> "Under 1 min"
                min < 5 -> "Short (1–5 min)"
                min < 20 -> "Medium (5–20 min)"
                else -> "Long (20+ min)"
            }
        }
        quality(item)?.let { out += it }
        if (item.width > 0 && item.height > 0) {
            out += when {
                item.height > item.width -> "Portrait"
                item.width > item.height -> "Landscape"
                else -> "Square"
            }
        }
        if (item.views == 0 && item.kind == MediaKind.VIDEO) out += "Unwatched"
        return out
    }

    fun quality(item: VaultItem): String? {
        val short = minOf(item.width, item.height)
        if (short <= 0) return null
        return when {
            short >= 2000 -> "4K"
            short >= 1400 -> "2K"
            short >= 1000 -> "Full HD"
            short >= 700 -> "HD"
            else -> "SD"
        }
    }
}
