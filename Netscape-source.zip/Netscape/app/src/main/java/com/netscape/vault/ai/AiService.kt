package com.netscape.vault.ai

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.mutableStateOf
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.TagCatalog
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream
import kotlin.math.max

/**
 * Android side of the offline AI: installs the pack, pulls frames out of encrypted media
 * (in memory only), runs the models and hands results to [AiTagger].
 */
object AiService {

    data class Status(
        val classifier: Boolean = false,
        val nudeNet: Boolean = false,
        val clip: Boolean = false,
        val version: String = "",
        val bytes: Long = 0
    ) {
        val any: Boolean get() = classifier || nudeNet || clip
        val all: Boolean get() = classifier && nudeNet && clip
    }

    val status = mutableStateOf(Status())

    /** Outlives any screen, so bulk / import tagging isn't cancelled when a dialog closes. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val dir: File get() = File(Vault.appContext.filesDir, "models").apply { mkdirs() }
    private var models: AiModels? = null
    private val lock = Mutex()
    private val textCache = HashMap<String, FloatArray>()

    fun refresh() {
        val m = AiModels(dir)
        status.value = Status(
            classifier = m.hasClassifier,
            nudeNet = m.hasNudeNet,
            clip = m.hasClip,
            version = m.version,
            bytes = dir.listFiles()?.sumOf { it.length() } ?: 0
        )
    }

    @Volatile private var releasePending = false

    /**
     * Frees model memory and forgets cached tag embeddings — called when the vault locks.
     * If an analysis is running, the release happens as soon as it finishes.
     */
    fun release() {
        if (lock.tryLock()) {
            try { releaseNow() } finally { lock.unlock() }
        } else {
            releasePending = true
        }
    }

    private fun releaseNow() {
        models?.close()
        models = null
        releasePending = false
        synchronized(textCache) { textCache.clear() }
    }

    private fun open(): AiModels = models ?: AiModels(dir).also { models = it }

    // ---------------------------------------------------------------- install / remove

    /** Unzips an AI pack chosen with the system file picker. Returns an error message or null. */
    suspend fun install(uri: Uri): String? = withContext(Dispatchers.IO) {
        lock.withLock {
            releaseNow()
            val staging = File(Vault.appContext.filesDir, "models.staging").apply { deleteRecursively(); mkdirs() }
            try {
                var found = 0
                val input = Vault.appContext.contentResolver.openInputStream(uri)
                    ?: return@withContext "Couldn't open that file"
                ZipInputStream(input.buffered()).use { zip ->
                    while (true) {
                        val entry = zip.nextEntry ?: break
                        val name = entry.name.substringAfterLast('/')
                        if (!entry.isDirectory && name in AiModels.PACK_FILES) {
                            File(staging, name).outputStream().use { zip.copyTo(it, 1 shl 16) }
                            found++
                        }
                    }
                }
                val check = AiModels(staging)
                if (check.manifest == null || !(check.hasClassifier || check.hasNudeNet || check.hasClip)) {
                    return@withContext "That doesn't look like a Netscape AI pack"
                }
                check.close()
                dir.deleteRecursively()
                if (!staging.renameTo(dir)) {
                    staging.copyRecursively(dir, overwrite = true)
                    staging.deleteRecursively()
                }
                null
            } catch (e: Exception) {
                "Install failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                staging.deleteRecursively()
                withContext(Dispatchers.Main) { refresh() }
            }
        }
    }

    suspend fun remove() = withContext(Dispatchers.IO) {
        lock.withLock {
            releaseNow()
            dir.deleteRecursively()
            withContext(Dispatchers.Main) { refresh() }
        }
    }

    // ---------------------------------------------------------------- analysis

    private fun Bitmap.toPixels(maxSide: Int = 640): Pixels {
        val scale = maxSide.toFloat() / max(width, height)
        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(this, (width * scale).toInt().coerceAtLeast(1), (height * scale).toInt().coerceAtLeast(1), true) else this
        val px = IntArray(bmp.width * bmp.height)
        bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
        return Pixels(bmp.width, bmp.height, px)
    }

    /** One photo, or 5 frames spread across a video — decrypted in memory only. */
    private suspend fun frames(item: VaultItem): List<Pixels> {
        if (item.kind == MediaKind.PHOTO) {
            return listOfNotNull(Vault.photo(item, max = 1024)?.toPixels())
        }
        val duration = item.durationMs.coerceAtLeast(1L)
        return listOf(0.1, 0.3, 0.5, 0.7, 0.9).mapNotNull { f ->
            Vault.frameAt(item, (duration * f).toLong())?.toPixels()
        }
    }

    private fun groupTags(): Map<String, List<String>> {
        val s = Vault.settings.value
        return TagCatalog.groups.associate { g -> g.id to TagCatalog.tagsIn(g.id, s).map { it.name } }
    }

    private fun embedText(clip: ClipModel, prompt: String): FloatArray =
        synchronized(textCache) { textCache[prompt] } ?: clip.embedText(prompt).also {
            synchronized(textCache) { textCache[prompt] = it }
        }

    /** Run every installed model on [item] and return tag suggestions (nothing is applied). */
    suspend fun suggest(item: VaultItem): List<Suggestion> = lock.withLock {
        try {
            suggestLocked(item)
        } finally {
            if (releasePending) releaseNow()
        }
    }

    private suspend fun suggestLocked(item: VaultItem): List<Suggestion> {
        val shots = frames(item)
        if (shots.isEmpty()) return emptyList()
        return withContext(Dispatchers.Default) {
            val m = open()
            val cls = m.classifier()
            val nude = m.nudeNet()
            val clip = m.clip()
            val results = shots.map { px ->
                FrameResult(
                    nsfw = cls?.classify(px),
                    detections = nude?.detect(px),
                    clip = clip?.embedImage(px)
                )
            }
            AiTagger.suggest(
                frames = results,
                groupTags = groupTags(),
                existing = item.tags.toSet(),
                sensitivity = Vault.settings.value.aiSensitivity,
                embedText = clip?.let { c -> { p: String -> embedText(c, p) } }
            )
        }
    }

    /**
     * Tag many items, keeping only confident suggestions. Progress goes to the busy overlay.
     * Returns how many tags were added in total.
     */
    suspend fun autoTag(ids: List<String>): Int {
        var added = 0
        ids.forEachIndexed { i, id ->
            withContext(Dispatchers.Main) { Vault.busyMessage.value = "✨ AI tagging ${i + 1} of ${ids.size}" }
            val item = Vault.find(id) ?: return@forEachIndexed
            val picks = try {
                AiTagger.confident(suggest(item), Vault.settings.value.aiSensitivity)
            } catch (e: Throwable) {
                emptyList()
            }
            if (picks.isNotEmpty()) {
                withContext(Dispatchers.Main) {
                    Vault.applyTagChanges(setOf(id), picks.map { it.tag }.toSet(), emptySet())
                }
                added += picks.size
            }
        }
        withContext(Dispatchers.Main) { Vault.busyMessage.value = null }
        return added
    }
}
