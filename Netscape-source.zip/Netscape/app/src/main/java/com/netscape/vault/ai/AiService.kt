package com.netscape.vault.ai

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.mutableStateOf
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.TagCatalog
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import android.provider.OpenableColumns
import java.util.Locale
import kotlin.math.max

/**
 * Android side of the offline AI: installs the pack, pulls frames out of encrypted media
 * (in memory only), runs the models and hands results to [AiTagger].
 */
object AiService {

    data class Status(
        val classifier: Boolean = false,
        val nudeNet: Boolean = false,
        val clip: Boolean = false,
        val captioner: Boolean = false,
        val version: String = "",
        val bytes: Long = 0
    ) {
        val taggerAvailable: Boolean get() = classifier || nudeNet || clip
        val any: Boolean get() = classifier || nudeNet || clip || captioner
        val all: Boolean get() = classifier && nudeNet && clip && captioner
    }

    val status = mutableStateOf(Status())

    /** 0..1 while an AI pack is being unpacked and verified, null otherwise. */
    val installProgress = mutableStateOf<Float?>(null)

    /** Outlives any screen, so bulk / import tagging isn't cancelled when a dialog closes. */
    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val dir: File get() = File(Vault.appContext.filesDir, "models").apply { mkdirs() }
    private var models: AiModels? = null
    private val lock = Mutex()
    private val textCache = HashMap<String, FloatArray>()

    fun refresh() {
        val m = AiModels(dir)
        status.value = Status(
            classifier = m.hasClassifier,
            nudeNet = m.hasNudeNet,
            clip = m.hasClip,
            captioner = m.hasCaptioner,
            version = m.version,
            bytes = dir.listFiles()?.sumOf { it.length() } ?: 0
        )
    }

    @Volatile private var releasePending = false

    /**
     * Frees model memory and forgets cached tag embeddings — called when the vault locks.
     * If an analysis is running, the release happens as soon as it finishes.
     */
    fun release() {
        if (lock.tryLock()) {
            try { releaseNow() } finally { lock.unlock() }
        } else {
            releasePending = true
        }
    }

    private fun releaseNow() {
        models?.close()
        models = null
        releasePending = false
        synchronized(textCache) { textCache.clear() }
        diskCache = null
    }

    private fun open(): AiModels = models ?: AiModels(dir).also { models = it }

    // ---------------------------------------------------------------- install / remove

    /** Unzips an AI pack chosen with the system file picker. Returns an error message or null. */
    suspend fun install(uri: Uri): String? = withContext(Dispatchers.IO) {
        lock.withLock {
            releaseNow()
            val staging = File(Vault.appContext.filesDir, "models.staging").apply { deleteRecursively(); mkdirs() }
            try {
                val resolver = Vault.appContext.contentResolver
                // The models unpack to roughly the zip's size — make sure they fit before starting.
                val packSize = try {
                    resolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else -1L
                    } ?: -1L
                } catch (_: Exception) {
                    -1L
                }
                val free = Vault.appContext.filesDir.usableSpace + (dir.listFiles()?.sumOf { it.length() } ?: 0L)
                if (packSize > 0 && free < packSize + 64L * 1024 * 1024) {
                    return@withContext String.format(
                        Locale.US,
                        "Not enough free storage: the AI pack needs about %.0f MB, only %.0f MB is free.",
                        packSize / 1e6, free / 1e6
                    )
                }
                val input = resolver.openInputStream(uri)
                    ?: return@withContext "Couldn't open that file"
                input.use {
                    var lastPct = -1
                    PackInstaller.extract(it, staging, AiModels.PACK_FILES) { written ->
                        if (packSize > 0) {
                            val pct = (written * 100 / packSize).toInt().coerceIn(0, 100)
                            if (pct != lastPct) {
                                lastPct = pct
                                installProgress.value = pct / 100f
                            }
                        }
                    }
                }
                val check = AiModels(staging)
                if (check.manifest == null || !(check.hasClassifier || check.hasNudeNet || check.hasClip || check.hasCaptioner)) {
                    return@withContext "That doesn't look like a Netscape AI pack"
                }
                check.close()
                dir.deleteRecursively()
                if (!staging.renameTo(dir)) {
                    staging.copyRecursively(dir, overwrite = true)
                    staging.deleteRecursively()
                }
                null
            } catch (e: PackInstaller.BadPack) {
                e.message
            } catch (e: Exception) {
                "Install failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                installProgress.value = null
                staging.deleteRecursively()
                withContext(Dispatchers.Main) { refresh() }
            }
        }
    }

    suspend fun remove() = withContext(Dispatchers.IO) {
        lock.withLock {
            releaseNow()
            dir.deleteRecursively()
            withContext(Dispatchers.Main) { refresh() }
        }
    }

    // ---------------------------------------------------------------- analysis

    /** Only for fresh, caller-owned bitmaps returned by Vault.photo/frameAt (never cached UI bitmaps). */
    private fun Bitmap.toScenePixels(): Pixels {
        val source = this
        val scale = 640f / max(source.width, source.height)
        var resized: Bitmap? = null
        try {
            val bmp = if (scale < 1f) {
                Bitmap.createScaledBitmap(
                    source, (source.width * scale).toInt().coerceAtLeast(1),
                    (source.height * scale).toInt().coerceAtLeast(1), true
                ).also { resized = it }
            } else source
            val px = IntArray(bmp.width * bmp.height)
            bmp.getPixels(px, 0, bmp.width, 0, 0, bmp.width, bmp.height)
            return Pixels(bmp.width, bmp.height, px)
        } finally {
            if (resized !== source) resized?.recycle()
            source.recycle()
        }
    }

    /** One photo, or three frames spread across a video — decrypted in memory only. */
    private suspend fun frames(item: VaultItem): List<Pixels> {
        if (item.kind == MediaKind.PHOTO) {
            currentCoroutineContext().ensureActive()
            return listOfNotNull(Vault.photo(item, max = 640)?.toScenePixels())
        }
        val duration = item.durationMs.coerceAtLeast(1L)
        return listOf(0.1, 0.5, 0.9).mapNotNull { f ->
            currentCoroutineContext().ensureActive()
            Vault.frameAt(item, (duration * f).toLong(), maxSide = 640)?.toScenePixels()
        }
    }

    /** Scene inference needs only three frames; release each freshly decoded bitmap after copying pixels. */
    private suspend fun sceneFrames(item: VaultItem): List<Pixels> {
        if (item.kind == MediaKind.PHOTO) {
            currentCoroutineContext().ensureActive()
            return listOfNotNull(Vault.photo(item, max = 640)?.toScenePixels())
        }
        val duration = item.durationMs.coerceAtLeast(1L)
        return listOf(0.1, 0.5, 0.9).mapNotNull { f ->
            currentCoroutineContext().ensureActive()
            Vault.frameAt(item, (duration * f).toLong(), maxSide = 640)?.toScenePixels()
        }
    }

    private fun groupTags(): Map<String, List<String>> {
        val s = Vault.settings.value
        return TagCatalog.groups.associate { g -> g.id to TagCatalog.tagsIn(g.id, s).map { it.name } }
    }

    // ---- CLIP tag phrases: computed once, kept on disk next to the model --------------------
    // CLIP must "read" every tag phrase (~300) before it can match them; that is the slow part of
    // the first suggestion. Results are saved keyed by SHA-256 of the phrase (custom tag names are
    // never written in plain text) and are wiped automatically when the pack is reinstalled.

    /** "Preparing tags 120/310" while the one-time preparation runs, null otherwise. */
    val prepareProgress = mutableStateOf<String?>(null)

    private val diskCacheFile: File get() = File(dir, "clip_text.cache")
    private var diskCache: HashMap<String, FloatArray>? = null

    private fun sha(text: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    private fun loadDiskCache(): HashMap<String, FloatArray> {
        diskCache?.let { return it }
        val map = HashMap<String, FloatArray>()
        try {
            if (diskCacheFile.isFile) java.io.DataInputStream(diskCacheFile.inputStream().buffered()).use { d ->
                if (d.readInt() == 0x4E534354) { // "NSCT"
                    val dim = d.readInt()
                    repeat(d.readInt()) {
                        val key = d.readUTF()
                        map[key] = FloatArray(dim) { d.readFloat() }
                    }
                }
            }
        } catch (_: Exception) {
            map.clear() // damaged cache: just rebuild it
        }
        diskCache = map
        return map
    }

    private fun saveDiskCache() {
        val map = diskCache ?: return
        if (map.isEmpty()) return
        try {
            val tmp = File(dir, "clip_text.cache.tmp")
            java.io.DataOutputStream(tmp.outputStream().buffered()).use { d ->
                d.writeInt(0x4E534354)
                d.writeInt(map.values.first().size)
                d.writeInt(map.size)
                map.forEach { (k, v) -> d.writeUTF(k); v.forEach(d::writeFloat) }
            }
            if (!tmp.renameTo(diskCacheFile)) { tmp.copyTo(diskCacheFile, overwrite = true); tmp.delete() }
        } catch (_: Exception) {
        }
    }

    private fun embedText(clip: ClipModel, prompt: String): FloatArray {
        synchronized(textCache) { textCache[prompt] }?.let { return it }
        val key = sha(prompt)
        val disk = loadDiskCache()
        val v = synchronized(disk) { disk[key] } ?: clip.embedText(prompt).also { synchronized(disk) { disk[key] = it } }
        synchronized(textCache) { textCache[prompt] = v }
        return v
    }

    /** Every phrase CLIP may be asked about, for the current tag catalog (incl. custom tags). */
    private fun allTagPrompts(): List<String> {
        val tags = groupTags()
        return AiTagger.PROMPTS.flatMap { (group, template) -> tags[group].orEmpty().map { template.format(it) } }
    }

    /** Computes any phrases not cached yet; returns how many were new. Call with [lock] held. */
    private suspend fun prepareTagPhrases(clip: ClipModel, onProgress: suspend (Int, Int) -> Unit): Int {
        val prompts = allTagPrompts()
        val disk = loadDiskCache()
        val missing = prompts.filter { p -> synchronized(disk) { !disk.containsKey(sha(p)) } }
        if (missing.isEmpty()) return 0
        missing.forEachIndexed { i, p ->
            currentCoroutineContext().ensureActive()
            embedText(clip, p)
            if (i % 10 == 0) onProgress(i, missing.size)
            if (i % 60 == 59) saveDiskCache()
        }
        saveDiskCache()
        return missing.size
    }

    /** Runs the one-time tag preparation in the background (after installing the pack). */
    fun warmUp() {
        appScope.launch {
            lock.withLock {
                try {
                    withContext(Dispatchers.Default) {
                        val clip = open().clip()
                        if (clip != null) {
                            prepareTagPhrases(clip) { done, total ->
                                withContext(Dispatchers.Main) { prepareProgress.value = "Preparing tag matching $done/$total" }
                            }
                        }
                    }
                } catch (_: Throwable) {
                } finally {
                    prepareProgress.value = null
                    if (releasePending) releaseNow()
                }
            }
        }
    }

    /** Run every installed model on [item] and return tag suggestions (nothing is applied). */
    suspend fun suggest(item: VaultItem, onPhase: suspend (String) -> Unit = {}): List<Suggestion> = lock.withLock {
        try {
            suggestLocked(item, onPhase)
        } finally {
            if (releasePending) releaseNow()
        }
    }

    private suspend fun suggestLocked(item: VaultItem, onPhase: suspend (String) -> Unit): List<Suggestion> {
        withContext(Dispatchers.Main) { onPhase("Reading frames") }
        val shots = frames(item)
        if (shots.isEmpty()) return emptyList()
        withContext(Dispatchers.Main) { onPhase("Running offline models") }
        return withContext(Dispatchers.Default) {
            val m = open()
            m.closeCaptioner()
            val cls = m.classifier()
            val nude = m.nudeNet()
            val clip = m.clip()
            val results = shots.map { px ->
                currentCoroutineContext().ensureActive()
                FrameResult(
                    nsfw = cls?.classify(px),
                    detections = nude?.detect(px),
                    clip = clip?.embedImage(px)
                )
            }
            currentCoroutineContext().ensureActive()
            if (clip != null) {
                prepareTagPhrases(clip) { done, total ->
                    withContext(Dispatchers.Main) { onPhase("Preparing tags $done/$total · first time only") }
                }
                withContext(Dispatchers.Main) { onPhase("Matching tags") }
            }
            val inferenceContext = currentCoroutineContext()
            AiTagger.suggest(
                frames = results,
                groupTags = groupTags(),
                existing = item.tags.toSet(),
                sensitivity = Vault.settings.value.aiSensitivity,
                embedText = clip?.let { c -> { p: String ->
                    inferenceContext.ensureActive()
                    embedText(c, p)
                } }
            )
        }
    }

    /**
     * Produces a non-graphic scene draft. Frames stay in memory and all resulting text remains
     * a proposal until the detail sheet explicitly saves it.
     */
    suspend fun suggestScene(item: VaultItem, onPhase: suspend (String) -> Unit = {}): SceneDraft = lock.withLock {
        try {
            withContext(Dispatchers.Main) { onPhase("Reading scene frames") }
            val selected = sceneFrames(item)
            require(selected.isNotEmpty()) { "No readable frames were found" }
            val allowedTags = listOf("setting", "mood", "camera", "outfit")
                .flatMap { id -> TagCatalog.groups.firstOrNull { it.id == id }?.tags?.map { it.name }.orEmpty() }
                .distinct()
                .take(80)
            require(allowedTags.isNotEmpty()) { "There are no scene tags available" }

            withContext(Dispatchers.Main) { onPhase("Preparing scene model") }
            withContext(Dispatchers.Default) {
                currentCoroutineContext().ensureActive()
                // Avoid holding ONNX sessions alongside the much larger VLM in the first mobile
                // prototype. The VLM itself remains lazy and is released when the vault locks.
                open().closeTaggers()
                val engine = open().captioner() ?: error("SmolVLM2 is not installed in this AI pack")
                // A plain line layout: a 500M model follows it far more reliably than JSON, and
                // the parser below copes when it drifts anyway.
                val prompt = """
                    Describe the setting, clothing, mood and camera style you can see. Keep it non-graphic: no body parts, nudity or sexual acts, no ages or identities.
                    Answer in exactly three lines:
                    Title: <a short catchy title, at most 8 words>
                    Description: <one sentence>
                    Tags: <up to 6, comma-separated, only from this list: ${allowedTags.joinToString(", ")}>
                """.trimIndent()
                withContext(Dispatchers.Main) { onPhase("Generating scene draft") }
                val raw = engine.generate(selected, prompt)
                currentCoroutineContext().ensureActive()
                parseSceneDraft(raw, allowedTags)
            }
        } finally {
            if (releasePending) releaseNow()
        }
    }

    private fun parseSceneDraft(raw: String, allowedTags: List<String>): SceneDraft =
        SceneDraftParser.parse(raw, allowedTags)

    /**
     * Tag many items, keeping only confident suggestions. Progress goes to the busy overlay.
     * Returns how many tags were added in total.
     */
    suspend fun autoTag(ids: List<String>): Int {
        var added = 0
        try {
            ids.forEachIndexed { i, id ->
                currentCoroutineContext().ensureActive()
                withContext(Dispatchers.Main) { Vault.busyMessage.value = "✨ AI tagging ${i + 1} of ${ids.size}" }
                val item = Vault.find(id) ?: return@forEachIndexed
                val picks = try {
                    AiTagger.confident(suggest(item), Vault.settings.value.aiSensitivity)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    emptyList()
                }
                currentCoroutineContext().ensureActive()
                if (picks.isNotEmpty()) {
                    withContext(Dispatchers.Main) {
                        Vault.applyTagChanges(setOf(id), picks.map { it.tag }.toSet(), emptySet())
                    }
                    added += picks.size
                }
            }
            return added
        } finally {
            withContext(NonCancellable + Dispatchers.Main) { Vault.busyMessage.value = null }
        }
    }
}
