package com.netscape.vault.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem

@Composable
fun BrowseScreen(onBack: () -> Unit, onOpen: (VaultItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    val filters = listOf("All", "Videos", "Photos", "My List", "In progress")

    val results = Vault.items
        .filter { item ->
            when (filter) {
                "Videos" -> item.kind == MediaKind.VIDEO
                "Photos" -> item.kind == MediaKind.PHOTO
                "My List" -> item.favorite
                "In progress" -> item.inProgress
                else -> true
            }
        }
        .filter {
            query.isBlank() ||
                it.title.contains(query, ignoreCase = true) ||
                it.collection.contains(query, ignoreCase = true)
        }
        .distinctBy { it.hash.ifBlank { it.id } }
        .sortedByDescending { it.addedAt }

    Column(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 8.dp, end = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                placeholder = { Text("Search your vault", color = Brand.Muted) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = Brand.Surface,
                    unfocusedContainerColor = Brand.Surface,
                    focusedIndicatorColor = Brand.Red,
                    unfocusedIndicatorColor = Color.Transparent,
                    cursorColor = Brand.Red
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        Row(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 14.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            filters.forEach { name ->
                FilterChip(
                    selected = filter == name,
                    onClick = { filter = name },
                    label = { Text(name, fontSize = 13.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        containerColor = Brand.Surface,
                        labelColor = Brand.Muted,
                        selectedContainerColor = Brand.Red,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        if (results.isEmpty()) {
            Text(
                text = "Nothing matches that.",
                color = Brand.Muted,
                modifier = Modifier.padding(24.dp)
            )
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                items(results, key = { it.id }) { item ->
                    MediaCard(item, modifier = Modifier.fillMaxWidth()) { onOpen(item) }
                }
            }
        }
    }
}
