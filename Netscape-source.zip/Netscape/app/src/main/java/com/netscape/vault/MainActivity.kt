package com.netscape.vault

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.Vault
import com.netscape.vault.ui.BrowseScreen
import com.netscape.vault.ui.Brand
import com.netscape.vault.ui.DetailScreen
import com.netscape.vault.ui.FramePickerScreen
import com.netscape.vault.ui.HomeScreen
import com.netscape.vault.ui.LockScreen
import com.netscape.vault.ui.NetscapeTheme
import com.netscape.vault.ui.PhotoScreen
import com.netscape.vault.ui.PlayerScreen
import kotlinx.coroutines.launch

private sealed class Screen {
    object Home : Screen()
    object Browse : Screen()
    data class Detail(val id: String) : Screen()
    data class Play(val id: String) : Screen()
    data class Photo(val id: String) : Screen()
    data class Frame(val id: String) : Screen()
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keeps the vault out of screenshots and the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Vault.init(this)

        setContent {
            NetscapeTheme {
                NetscapeApp()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!Vault.suppressAutoLock) Vault.lock()
    }
}

@Composable
private fun NetscapeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf<Screen>(Screen.Home) }
    val unlocked by Vault.unlocked
    val busy by Vault.busyMessage

    val importer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        Vault.suppressAutoLock = false
        if (!uris.isNullOrEmpty()) {
            scope.launch {
                val result = Vault.importMedia(uris)
                val message = buildString {
                    append("${result.added} added")
                    if (result.duplicates > 0) append(", ${result.duplicates} duplicate skipped")
                    if (result.failed > 0) append(", ${result.failed} failed")
                }
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun pickMedia() {
        Vault.suppressAutoLock = true
        importer.launch(arrayOf("video/*", "image/*"))
    }

    if (!unlocked) {
        LockScreen(onUnlocked = { screen = Screen.Home })
        return
    }

    BackHandler(enabled = screen !is Screen.Home) {
        screen = when (val current = screen) {
            is Screen.Play -> Screen.Detail(current.id)
            is Screen.Photo -> Screen.Detail(current.id)
            is Screen.Frame -> Screen.Detail(current.id)
            else -> Screen.Home
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        when (val current = screen) {
            is Screen.Home -> HomeScreen(
                onOpen = { item ->
                    screen = if (item.kind == MediaKind.PHOTO) Screen.Photo(item.id) else Screen.Play(item.id)
                },
                onDetails = { screen = Screen.Detail(it.id) },
                onAdd = { pickMedia() },
                onSearch = { screen = Screen.Browse },
                onLock = { Vault.lock() }
            )

            is Screen.Browse -> BrowseScreen(
                onBack = { screen = Screen.Home },
                onOpen = { screen = Screen.Detail(it.id) }
            )

            is Screen.Detail -> DetailScreen(
                itemId = current.id,
                onBack = { screen = Screen.Home },
                onPlay = { item ->
                    screen = if (item.kind == MediaKind.PHOTO) Screen.Photo(item.id) else Screen.Play(item.id)
                },
                onPickFrame = { screen = Screen.Frame(it.id) }
            )

            is Screen.Play -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) screen = Screen.Home
                else PlayerScreen(item) { screen = Screen.Detail(item.id) }
            }

            is Screen.Photo -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) screen = Screen.Home
                else PhotoScreen(item) { screen = Screen.Detail(item.id) }
            }

            is Screen.Frame -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) screen = Screen.Home
                else FramePickerScreen(item) { screen = Screen.Detail(item.id) }
            }
        }

        val message = busy
        if (message != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f)),
                contentAlignment = Alignment.Center
            ) {
                androidx.compose.foundation.layout.Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator(color = Brand.Red)
                    Text(
                        text = message,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        }
    }
}
