package com.netscape.vault

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Photo
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import com.netscape.vault.ui.Brand
import com.netscape.vault.ui.CollectionScreen
import com.netscape.vault.ui.DetailScreen
import com.netscape.vault.ui.FoldersScreen
import com.netscape.vault.ui.FramePickerScreen
import com.netscape.vault.ui.HomeScreen
import com.netscape.vault.ui.LockScreen
import com.netscape.vault.ui.NetscapeTheme
import com.netscape.vault.ui.PhotoScreen
import com.netscape.vault.ui.PhotosScreen
import com.netscape.vault.ui.PlayerScreen
import com.netscape.vault.ui.SearchScreen
import com.netscape.vault.ui.VideosScreen
import kotlinx.coroutines.launch

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Filled.Home),
    VIDEOS("Videos", Icons.Filled.Movie),
    PHOTOS("Photos", Icons.Filled.Photo),
    FOLDERS("Folders", Icons.Filled.Folder),
    SEARCH("Search", Icons.Filled.Search)
}

private sealed class Route {
    object Tabs : Route()
    data class Detail(val id: String) : Route()
    data class Play(val id: String) : Route()
    data class Photo(val id: String) : Route()
    data class Frame(val id: String) : Route()
    data class Folder(val name: String) : Route()
    data class TagView(val name: String) : Route()
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Keeps the vault out of screenshots and the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Vault.init(this)

        setContent {
            NetscapeTheme {
                NetscapeApp()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!Vault.suppressAutoLock) Vault.lock()
    }
}

@Composable
private fun NetscapeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var route by remember { mutableStateOf<Route>(Route.Tabs) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    val unlocked by Vault.unlocked
    val busy by Vault.busyMessage

    val importer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        Vault.suppressAutoLock = false
        if (!uris.isNullOrEmpty()) {
            scope.launch {
                val result = Vault.importMedia(uris)
                val message = buildString {
                    append("${result.added} added")
                    if (result.duplicates > 0) append(", ${result.duplicates} duplicate skipped")
                    if (result.failed > 0) append(", ${result.failed} failed")
                }
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun pickMedia() {
        Vault.suppressAutoLock = true
        importer.launch(arrayOf("video/*", "image/*"))
    }

    fun open(item: VaultItem) {
        route = if (item.kind == MediaKind.PHOTO) Route.Photo(item.id) else Route.Play(item.id)
    }

    if (!unlocked) {
        LockScreen(onUnlocked = {
            route = Route.Tabs
            tab = Tab.HOME
        })
        return
    }

    BackHandler(enabled = route !is Route.Tabs || tab != Tab.HOME) {
        val current = route
        route = when (current) {
            is Route.Play -> Route.Detail(current.id)
            is Route.Photo -> Route.Detail(current.id)
            is Route.Frame -> Route.Detail(current.id)
            is Route.Tabs -> {
                tab = Tab.HOME
                Route.Tabs
            }
            else -> Route.Tabs
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        when (val current = route) {
            is Route.Tabs -> when (tab) {
                Tab.HOME -> HomeScreen(
                    onOpen = { open(it) },
                    onDetails = { route = Route.Detail(it.id) },
                    onAdd = { pickMedia() },
                    onSearch = { tab = Tab.SEARCH },
                    onLock = { Vault.lock() }
                )
                Tab.VIDEOS -> VideosScreen(onOpen = { route = Route.Detail(it.id) })
                Tab.PHOTOS -> PhotosScreen(onOpen = { route = Route.Detail(it.id) })
                Tab.FOLDERS -> FoldersScreen(
                    onOpenFolder = { route = Route.Folder(it) },
                    onOpenTag = { route = Route.TagView(it) }
                )
                Tab.SEARCH -> SearchScreen(onOpen = { route = Route.Detail(it.id) })
            }

            is Route.Folder -> CollectionScreen(
                title = current.name,
                entries = Vault.itemsIn(current.name),
                onBack = { route = Route.Tabs },
                onOpen = { route = Route.Detail(it.id) }
            )

            is Route.TagView -> CollectionScreen(
                title = "#" + current.name,
                entries = Vault.itemsTagged(current.name),
                onBack = { route = Route.Tabs },
                onOpen = { route = Route.Detail(it.id) }
            )

            is Route.Detail -> DetailScreen(
                itemId = current.id,
                onBack = { route = Route.Tabs },
                onPlay = { open(it) },
                onPickFrame = { route = Route.Frame(it.id) }
            )

            is Route.Play -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) {
                    route = Route.Tabs
                } else {
                    PlayerScreen(item) { route = Route.Detail(item.id) }
                }
            }

            is Route.Photo -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) {
                    route = Route.Tabs
                } else {
                    PhotoScreen(item) { route = Route.Detail(item.id) }
                }
            }

            is Route.Frame -> {
                val item = Vault.items.firstOrNull { it.id == current.id }
                if (item == null) {
                    route = Route.Tabs
                } else {
                    FramePickerScreen(item) { route = Route.Detail(item.id) }
                }
            }
        }

        // Bottom navigation — hidden while playing, viewing a photo or picking a frame.
        val showBar = route is Route.Tabs || route is Route.Folder || route is Route.TagView
        if (showBar) {
            NavigationBar(
                containerColor = Color.Black.copy(alpha = 0.94f),
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
            ) {
                Tab.values().forEach { entry ->
                    NavigationBarItem(
                        selected = route is Route.Tabs && tab == entry,
                        onClick = {
                            tab = entry
                            route = Route.Tabs
                        },
                        icon = { Icon(entry.icon, contentDescription = entry.label) },
                        label = { Text(entry.label, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color.White,
                            selectedTextColor = Color.White,
                            indicatorColor = Brand.Red,
                            unselectedIconColor = Brand.Muted,
                            unselectedTextColor = Brand.Muted
                        )
                    )
                }
            }
        }

        val message = busy
        if (message != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Brand.Red)
                    Text(
                        text = message,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        }
    }
}
