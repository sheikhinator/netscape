package com.netscape.vault

import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import com.netscape.vault.ui.Brand
import com.netscape.vault.ui.CollectionScreen
import com.netscape.vault.ui.DetailScreen
import com.netscape.vault.ui.ExploreScreen
import com.netscape.vault.ui.FramePickerScreen
import com.netscape.vault.ui.HomeScreen
import com.netscape.vault.ui.LibraryScreen
import com.netscape.vault.ui.LockScreen
import com.netscape.vault.ui.NetscapeTheme
import com.netscape.vault.ui.PhotoScreen
import com.netscape.vault.ui.PlayerScreen
import com.netscape.vault.ui.SearchScreen
import com.netscape.vault.ui.SettingsScreen
import com.netscape.vault.ui.TagEditorScreen
import com.netscape.vault.ui.tagLabel
import kotlinx.coroutines.launch

private enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    LIBRARY("Library", Icons.Rounded.VideoLibrary),
    EXPLORE("Explore", Icons.Rounded.Explore),
    SEARCH("Search", Icons.Rounded.Search),
    SETTINGS("Settings", Icons.Rounded.Settings)
}

private sealed class Route {
    object Tabs : Route()
    data class Detail(val id: String) : Route()
    data class Play(val id: String, val startAt: Long? = null) : Route()
    data class Photo(val id: String) : Route()
    data class Frame(val id: String) : Route()
    data class Folder(val name: String) : Route()
    data class TagView(val name: String) : Route()
    data class Ages(val min: Int, val max: Int) : Route()
    data class Tags(val ids: Set<String>) : Route()
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        super.onCreate(savedInstanceState)
        // Keeps the vault out of screenshots and the recent-apps preview.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        Vault.init(this)
        com.netscape.vault.ai.AiService.refresh()

        setContent {
            NetscapeTheme {
                NetscapeApp()
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (!Vault.suppressAutoLock) Vault.lock()
    }
}

@Composable
private fun NetscapeApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val stack = remember { mutableStateListOf<Route>(Route.Tabs) }
    var tab by remember { mutableStateOf(Tab.HOME) }
    val unlocked by Vault.unlocked
    val busy by Vault.busyMessage
    val loadError by Vault.loadError

    fun push(route: Route) {
        if (stack.lastOrNull() != route) stack.add(route)
    }

    fun pop() {
        if (stack.size > 1) stack.removeAt(stack.lastIndex)
    }

    val importer = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        Vault.suppressAutoLock = false
        if (!uris.isNullOrEmpty()) {
            scope.launch {
                val result = Vault.importMedia(uris)
                val message = buildString {
                    append("${result.added} added")
                    if (result.duplicates > 0) append(", ${result.duplicates} duplicate skipped")
                    if (result.failed > 0) append(", ${result.failed} failed")
                }
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                val ai = com.netscape.vault.ai.AiService
                if (Vault.settings.value.aiAutoTagImports && ai.status.value.any && result.ids.isNotEmpty()) {
                    ai.appScope.launch {
                        val n = ai.autoTag(result.ids)
                        Toast.makeText(context, "✨ AI added $n tag(s)", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    fun pickMedia() {
        Vault.suppressAutoLock = true
        importer.launch(arrayOf("video/*", "image/*"))
    }

    fun open(item: VaultItem, at: Long? = null) {
        push(if (item.kind == MediaKind.PHOTO) Route.Photo(item.id) else Route.Play(item.id, at))
    }

    fun details(item: VaultItem) = push(Route.Detail(item.id))
    fun editTags(ids: Set<String>) { if (ids.isNotEmpty()) push(Route.Tags(ids)) }
    fun openTag(tag: String) = push(Route.TagView(tag))

    if (!unlocked) {
        LockScreen(onUnlocked = {
            stack.clear()
            stack.add(Route.Tabs)
            tab = Tab.HOME
        })
        return
    }

    BackHandler(enabled = stack.size > 1 || tab != Tab.HOME) {
        if (stack.size > 1) pop() else tab = Tab.HOME
    }

    val top = stack.last()

    Box(modifier = Modifier.fillMaxSize().background(Brand.Ink)) {
        AnimatedContent(
            targetState = if (top is Route.Tabs) Pair<Route, Tab?>(top, tab) else Pair<Route, Tab?>(top, null),
            transitionSpec = {
                (fadeIn(tween(220)) + scaleIn(initialScale = 0.98f, animationSpec = tween(220)))
                    .togetherWith(fadeOut(tween(160)))
            },
            label = "nav"
        ) { (current, currentTab) ->
            when (current) {
                is Route.Tabs -> when (currentTab ?: Tab.HOME) {
                    Tab.HOME -> HomeScreen(
                        onOpen = { open(it) },
                        onDetails = { details(it) },
                        onAdd = { pickMedia() },
                        onOpenTag = { openTag(it) },
                        onSurprise = { Vault.items.randomOrNull()?.let { details(it) } },
                        onLock = { Vault.lock() }
                    )
                    Tab.LIBRARY -> LibraryScreen(onOpen = { details(it) }, onEditTags = { editTags(it) })
                    Tab.EXPLORE -> ExploreScreen(
                        onOpenFolder = { push(Route.Folder(it)) },
                        onOpenTag = { openTag(it) },
                        onOpenAges = { lo, hi -> push(Route.Ages(lo, hi)) }
                    )
                    Tab.SEARCH -> SearchScreen(onOpen = { details(it) }, onEditTags = { editTags(it) })
                    Tab.SETTINGS -> SettingsScreen()
                }

                is Route.Folder -> CollectionScreen(
                    title = current.name,
                    entries = Vault.itemsIn(current.name),
                    onBack = { pop() },
                    onOpen = { details(it) },
                    onEditTags = { editTags(it) }
                )

                is Route.TagView -> CollectionScreen(
                    title = if (Vault.settings.value.discreet) "Collection" else tagLabel(current.name),
                    entries = Vault.itemsTagged(current.name),
                    onBack = { pop() },
                    onOpen = { details(it) },
                    onEditTags = { editTags(it) }
                )

                is Route.Ages -> CollectionScreen(
                    title = "🎂 " + if (current.max >= Vault.MAX_AGE) "${current.min}+" else "${current.min}–${current.max}",
                    entries = Vault.itemsAged(current.min, current.max),
                    onBack = { pop() },
                    onOpen = { details(it) },
                    onEditTags = { editTags(it) }
                )

                is Route.Detail -> DetailScreen(
                    itemId = current.id,
                    onBack = { pop() },
                    onPlay = { open(it) },
                    onPlayAt = { item, ms -> open(item, ms) },
                    onPickFrame = { push(Route.Frame(it.id)) },
                    onEditTags = { editTags(setOf(it.id)) },
                    onOpenTag = { openTag(it) }
                )

                is Route.Tags -> TagEditorScreen(ids = current.ids, onDone = { pop() })

                is Route.Play -> {
                    val item = Vault.find(current.id)
                    if (item != null) PlayerScreen(item, current.startAt) { pop() }
                    else Box(Modifier.fillMaxSize().background(Color.Black))
                }

                is Route.Photo -> {
                    val item = Vault.find(current.id)
                    if (item != null) PhotoScreen(item, onBack = { pop() }, onInfo = { details(it) })
                    else Box(Modifier.fillMaxSize().background(Color.Black))
                }

                is Route.Frame -> {
                    val item = Vault.find(current.id)
                    if (item != null) FramePickerScreen(item) { pop() }
                    else Box(Modifier.fillMaxSize().background(Brand.Ink))
                }
            }
        }

        // iOS-style tab bar — hidden while playing, viewing, editing tags or picking a frame.
        val showBar = top is Route.Tabs || top is Route.Folder || top is Route.TagView || top is Route.Ages
        if (showBar) {
            TabBar(
                current = if (top is Route.Tabs) tab else null,
                modifier = Modifier.align(Alignment.BottomCenter)
            ) { entry ->
                tab = entry
                stack.clear()
                stack.add(Route.Tabs)
            }
        }

        loadError?.let { msg ->
            Text(
                text = "⚠️ $msg",
                color = Color.White,
                fontSize = 13.sp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF8A1C1C))
                    .padding(12.dp)
            )
        }

        val message = busy
        if (message != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.75f))
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {},
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brand.Surface)
                        .padding(horizontal = 28.dp, vertical = 22.dp)
                ) {
                    CircularProgressIndicator(color = Brand.Red)
                    Text(
                        text = message,
                        color = Color.White,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(top = 16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TabBar(current: Tab?, modifier: Modifier = Modifier, onSelect: (Tab) -> Unit) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xF20A0A0A))
    ) {
        Box(Modifier.fillMaxWidth().height(0.5.dp).background(Brand.Line))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(top = 6.dp, bottom = 4.dp)
        ) {
            Tab.values().forEach { entry ->
                val on = current == entry
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(entry) }
                        .padding(vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        entry.icon,
                        contentDescription = entry.label,
                        tint = if (on) Brand.Red else Brand.Muted,
                        modifier = Modifier.size(26.dp)
                    )
                    Text(
                        entry.label,
                        color = if (on) Brand.Red else Brand.Muted,
                        fontSize = 10.sp,
                        fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal
                    )
                }
            }
        }
    }
}
