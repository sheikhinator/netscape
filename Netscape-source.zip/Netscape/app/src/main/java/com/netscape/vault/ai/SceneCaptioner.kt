package com.netscape.vault.ai

import java.io.Closeable

/** Offline SmolVLM2 wrapper. Pixel buffers are passed directly to JNI and never written to disk. */
class SceneCaptioner(modelPath: String, mmprojPath: String) : Closeable {
    private var handle = NativeSmolVlm.open(modelPath, mmprojPath, threads = 4)

    @Synchronized
    fun generate(frames: List<Pixels>, prompt: String): String {
        check(handle != 0L) { "The scene model is closed" }
        require(frames.isNotEmpty()) { "No frames to analyze" }
        require(frames.size <= 3) { "At most three frames can be analyzed at once" }
        return NativeSmolVlm.generate(
            handle = handle,
            prompt = prompt,
            widths = IntArray(frames.size) { frames[it].width },
            heights = IntArray(frames.size) { frames[it].height },
            frames = Array(frames.size) { frames[it].argb },
            maxTokens = 96
        ).trim().take(2_000)
    }

    @Synchronized
    override fun close() {
        if (handle != 0L) {
            NativeSmolVlm.close(handle)
            handle = 0L
        }
    }
}