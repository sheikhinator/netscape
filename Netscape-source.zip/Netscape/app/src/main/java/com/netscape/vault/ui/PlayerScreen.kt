package com.netscape.vault.ui

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import com.netscape.vault.crypto.EncryptedDataSource
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Composable
fun PlayerScreen(item: VaultItem, onBack: () -> Unit) {
    val context = LocalContext.current

    val player = remember(item.id) {
        val factory = EncryptedDataSource.Factory(Vault.mediaFile(item), Vault.keyFor(item))
        val source = ProgressiveMediaSource.Factory(factory)
            .createMediaSource(ExoMediaItem.fromUri(Uri.parse("netscape://" + item.id)))
        ExoPlayer.Builder(context).build().apply {
            setMediaSource(source)
            prepare()
            if (item.progressMs > 0 && item.progressFraction < 0.98f) seekTo(item.progressMs)
            playWhenReady = true
        }
    }

    DisposableEffect(item.id) {
        onDispose {
            val position = player.currentPosition
            val duration = if (player.duration > 0) player.duration else item.durationMs
            player.release()
            CoroutineScope(Dispatchers.Main).launch {
                Vault.setProgress(item, position, duration)
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    this.player = player
                    useController = true
                    setShowNextButton(false)
                    setShowPreviousButton(false)
                    setBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        IconButton(
            onClick = onBack,
            modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
        ) {
            Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
        }
        Text(
            text = item.title,
            color = Color.White.copy(alpha = 0.85f),
            fontSize = 14.sp,
            modifier = Modifier.align(Alignment.TopCenter).padding(top = 18.dp)
        )
    }
}
