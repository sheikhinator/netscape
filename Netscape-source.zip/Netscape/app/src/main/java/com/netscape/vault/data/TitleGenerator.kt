package com.netscape.vault.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

/**
 * Offline title + description writer. Builds names from what the vault already knows about an
 * item (its tags, rating, length, quality) and the user's chosen style and emoji level.
 * Every call is random, so tapping "Generate" again gives a fresh option.
 */
object TitleGenerator {

    private class Voice(
        val adjectives: List<String>,
        val nouns: List<String>,
        val emojis: List<String>,
        val openers: List<String>,
        val closers: List<String>
    )

    private val voices = mapOf(
        TitleStyle.SPICY to Voice(
            adjectives = listOf(
                "Steamy", "Sizzling", "Red-Hot", "Sultry", "Wild", "Naughty", "Molten",
                "Feverish", "Scorching", "Sinful", "Forbidden", "Breathless", "Electric",
                "Untamed", "Dangerous", "Tempting", "Blazing", "Wicked", "Dripping", "Heated"
            ),
            nouns = listOf(
                "Session", "Encounter", "Night", "Affair", "Rendezvous", "Escape", "Fantasy",
                "Temptation", "Heatwave", "Moment", "Adventure", "Secret", "Desire", "Rush",
                "After Dark", "Hour", "Obsession", "Craving", "Round", "Takeover"
            ),
            emojis = listOf("🔥", "🌶️", "😈", "💋", "🥵", "💦", "🍑", "🍒", "👅", "😏", "💥", "❤️‍🔥"),
            openers = listOf(
                "Things get heated fast", "Turn the lights down for this one",
                "Pure fire from start to finish", "Warning: dangerously hot",
                "A slow burn that ends in flames", "Nobody is keeping their hands to themselves",
                "The temperature rises and never comes down", "Zero chill, all heat"
            ),
            closers = listOf(
                "Rewatch value: dangerously high.", "Hydrate afterwards.",
                "Best enjoyed with the door locked.", "You already know you'll be back.",
                "Certified scorcher.", "Handle with care — it's hot."
            )
        ),
        TitleStyle.FLIRTY to Voice(
            adjectives = listOf(
                "Cheeky", "Flirty", "Teasing", "Sweet & Spicy", "Blushing", "Irresistible",
                "Tempting", "Cute but Naughty", "Sneaky", "Dreamy", "Pouty", "Sugar-Coated"
            ),
            nouns = listOf(
                "Tease", "Crush", "Little Secret", "Kiss", "Wink", "Surprise", "Treat", "Date",
                "Daydream", "Invitation", "Distraction", "Situationship"
            ),
            emojis = listOf("😘", "😉", "💕", "💋", "🍓", "✨", "😏", "💌", "🎀", "🫦"),
            openers = listOf(
                "A little tease that turns into a lot more", "Sweet at first, spicy by the end",
                "Just a peek… or maybe more", "The kind of wink that means trouble",
                "Butterflies, then fireworks"
            ),
            closers = listOf(
                "Blush responsibly.", "Keep this one between us.", "Worth every second.",
                "Consider yourself teased.", "Smile guaranteed."
            )
        ),
        TitleStyle.CLASSY to Voice(
            adjectives = listOf(
                "Velvet", "Midnight", "Silk", "Golden", "Candlelit", "Private", "Exquisite",
                "Intimate", "Elegant", "Noir", "Crimson", "Moonlit", "Opulent", "Satin"
            ),
            nouns = listOf(
                "Collection", "Edition", "Reserve", "Suite", "Soirée", "Chapter", "Serenade",
                "Affair", "Evening", "Interlude", "Portrait", "Sonata", "Study"
            ),
            emojis = listOf("🥂", "🍷", "🌹", "🕯️", "🖤", "✨", "💎", "🌙", "🎻"),
            openers = listOf(
                "An intimate evening, beautifully captured", "Elegance with a dangerous edge",
                "Soft light, slow hands, no hurry", "A private screening for one",
                "Refined, sensual and entirely unforgettable"
            ),
            closers = listOf(
                "Best paired with a glass of red.", "A connoisseur's choice.",
                "Timeless.", "Reserved for special occasions.", "Simply exquisite."
            )
        ),
        TitleStyle.PLAYFUL to Voice(
            adjectives = listOf(
                "Oops!", "Cheeky", "Bouncy", "Giggly", "Mischievous", "Spicy Little",
                "Totally Innocent", "Accidentally Hot", "Chaotic", "Very Busy", "Extra"
            ),
            nouns = listOf(
                "Shenanigans", "Adventure", "Game Night", "Rodeo", "Party", "Workout",
                "Situation", "Mischief", "Snack Break", "Field Trip", "Olympics", "Tutorial"
            ),
            emojis = listOf("😜", "🙈", "🍑", "🍆", "🎉", "🤭", "😝", "🍌", "🌮", "🎠", "🤠"),
            openers = listOf(
                "It started innocently. It did not stay innocent", "Cardio, but make it fun",
                "Somebody call a referee", "Plot twist: nobody finished the movie",
                "Rated E for Extremely not safe for work"
            ),
            closers = listOf(
                "10/10 would rewatch.", "No regrets.", "Somebody grab a towel.",
                "The neighbours definitely heard.", "Gold medal performance."
            )
        ),
        TitleStyle.MINIMAL to Voice(
            adjectives = listOf(""), nouns = listOf(""), emojis = emptyList(),
            openers = listOf(""), closers = listOf("")
        )
    )

    private fun voiceFor(style: TitleStyle): Voice =
        voices[if (style == TitleStyle.CUSTOM) TitleStyle.SPICY else style] ?: voices.getValue(TitleStyle.SPICY)

    private fun <T> List<T>.pickOne(r: Random): T? = if (isEmpty()) null else this[r.nextInt(size)]

    // ---------- titles ----------

    fun title(item: VaultItem, number: Int, s: Settings, r: Random = Random.Default): String {
        val v = voiceFor(s.titleStyle)
        val tags = TagView(item, s)

        val raw = when (s.titleStyle) {
            TitleStyle.MINIMAL -> {
                val lead = tags.category ?: tags.position ?: tags.setting
                val kind = if (item.kind == MediaKind.PHOTO) "Photo" else "Clip"
                listOfNotNull(lead, "$kind #$number").joinToString(" · ")
            }
            TitleStyle.CUSTOM -> fillTemplate(s.customTemplate, item, number, s, v, tags, r)
            else -> {
                val adj = v.adjectives.pickOne(r).orEmpty()
                val noun = v.nouns.pickOne(r).orEmpty()
                val focus = listOfNotNull(tags.setting, tags.position, tags.act, tags.mood).pickOne(r)
                val second = listOfNotNull(tags.position, tags.act, tags.who, tags.outfit)
                    .filter { it != focus }.pickOne(r)
                when (r.nextInt(5)) {
                    0 -> "$adj $noun"
                    1 -> if (focus != null) "$adj $focus $noun" else "$adj $noun"
                    2 -> if (second != null) "$adj $noun · $second" else "$adj $noun #$number"
                    3 -> if (focus != null) "The $focus $noun" else "The $adj $noun"
                    else -> if (tags.person != null) "$adj $noun with ${tags.person}" else "$adj $noun Vol. $number"
                }
            }
        }
        return decorate(raw.trim(), item, s, v, r)
    }

    private fun decorate(text: String, item: VaultItem, s: Settings, v: Voice, r: Random): String {
        if (s.emojiLevel == 0 || s.titleStyle == TitleStyle.MINIMAL || s.titleStyle == TitleStyle.CUSTOM) {
            return if (s.emojiLevel == 0) stripEmoji(text) else text
        }
        val pool = (v.emojis + tagEmojis(item, s)).distinct().shuffled(r)
        return when (s.emojiLevel) {
            1 -> "${pool.firstOrNull().orEmpty()} $text".trim()
            else -> "${pool.getOrNull(0).orEmpty()} $text ${pool.drop(1).take(2).joinToString("")}".trim()
        }
    }

    private fun tagEmojis(item: VaultItem, s: Settings): List<String> =
        item.tags.map { TagCatalog.emojiOf(it, s) }

    private fun fillTemplate(
        template: String, item: VaultItem, number: Int, s: Settings, v: Voice, tags: TagView, r: Random
    ): String {
        val emojiPool = (v.emojis + tagEmojis(item, s)).shuffled(r)
        var emojiIndex = 0
        val values = mapOf(
            "adj" to { v.adjectives.pickOne(r).orEmpty() },
            "noun" to { v.nouns.pickOne(r).orEmpty() },
            "category" to { tags.category.orEmpty() },
            "who" to { tags.who.orEmpty() },
            "type" to { tags.type.orEmpty() },
            "position" to { tags.position.orEmpty() },
            "act" to { tags.act.orEmpty() },
            "body" to { tags.body.orEmpty() },
            "look" to { tags.look.orEmpty() },
            "outfit" to { tags.outfit.orEmpty() },
            "kink" to { tags.kink.orEmpty() },
            "setting" to { tags.setting.orEmpty() },
            "mood" to { tags.mood.orEmpty() },
            "person" to { tags.person.orEmpty() },
            "age" to { tags.age.orEmpty() },
            "n" to { number.toString() },
            "duration" to { durationText(item.durationMs) },
            "quality" to { AutoTags.quality(item).orEmpty() },
            "rating" to { "⭐".repeat(item.rating) },
            "date" to { SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(Date(item.addedAt)) },
            "emoji" to {
                if (s.emojiLevel == 0) "" else emojiPool.getOrNull(emojiIndex++).orEmpty()
            }
        )
        val filled = Regex("\\{(\\w+)\\}").replace(template) { m ->
            values[m.groupValues[1].lowercase()]?.invoke() ?: ""
        }
        // Tidy up separators left dangling by empty tokens.
        return filled
            .replace(Regex("\\s*·\\s*(·\\s*)+"), " · ")
            .replace(Regex("^[\\s·#-]+|[\\s·#-]+$"), "")
            .replace(Regex(" #(?=\\s|$)"), "")
            .replace(Regex("\\s{2,}"), " ")
            .trim()
            .ifBlank { "Untitled #$number" }
    }

    // ---------- descriptions ----------

    fun description(item: VaultItem, s: Settings, r: Random = Random.Default): String {
        val v = voiceFor(s.titleStyle)
        val tags = TagView(item, s)
        val lines = mutableListOf<String>()

        if (s.titleStyle != TitleStyle.MINIMAL) {
            val e1 = if (s.emojiLevel > 0) (v.emojis.pickOne(r)?.plus(" ") ?: "") else ""
            lines += "$e1${v.openers.pickOne(r).orEmpty()}."
        }

        val parts = mutableListOf<String>()
        tags.all("who").takeIf { it.isNotEmpty() }?.let { parts += join(it) }
        tags.all("position").takeIf { it.isNotEmpty() }?.let { parts += "featuring ${join(it)}" }
        tags.all("act").takeIf { it.isNotEmpty() }?.let { parts += "with ${join(it)}" }
        tags.all("setting").firstOrNull()?.let { parts += "in the ${it.lowercase()}" }
        tags.all("outfit").takeIf { it.isNotEmpty() }?.let { parts += "wearing ${join(it).lowercase()}" }
        if (parts.isNotEmpty()) {
            val mood = tags.all("mood").firstOrNull()?.let { " — ${it.lowercase()} vibes" }.orEmpty()
            lines += parts.joinToString(" ").replaceFirstChar { it.uppercase() } + mood + "."
        }
        val kinks = tags.all("kink") + tags.all("toys")
        if (kinks.isNotEmpty()) lines += "Extras: ${join(kinks)}."
        val focus = tags.all("body")
        if (focus.isNotEmpty()) lines += "Focus on ${join(focus).lowercase()}."
        if (tags.people.isNotEmpty()) lines += "Starring ${join(tags.people)}."

        if (s.titleStyle != TitleStyle.MINIMAL) {
            val e2 = if (s.emojiLevel > 1) (" " + (v.emojis.pickOne(r) ?: "")) else ""
            lines += v.closers.pickOne(r).orEmpty() + e2
        }

        val facts = listOfNotNull(
            durationText(item.durationMs).takeIf { it.isNotEmpty() }?.let { "⏱ $it" },
            AutoTags.quality(item),
            tags.age?.let { "🎂 $it" },
            if (item.rating > 0) "⭐".repeat(item.rating) else null
        )
        if (facts.isNotEmpty()) lines += facts.joinToString(" · ")

        val text = lines.filter { it.isNotBlank() }.joinToString("\n")
        return if (s.emojiLevel == 0) stripEmoji(text) else text
    }

    // ---------- helpers ----------

    private fun join(list: List<String>): String = when (list.size) {
        0 -> ""
        1 -> list[0]
        2 -> "${list[0]} & ${list[1]}"
        else -> list.dropLast(1).joinToString(", ") + " & " + list.last()
    }

    fun durationText(ms: Long): String {
        if (ms <= 0) return ""
        val total = ms / 1000
        val h = total / 3600
        val m = (total % 3600) / 60
        val sec = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private val emojiRegex = Regex(
        "[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{2B00}-\\x{2BFF}\\x{2190}-\\x{21FF}" +
            "\\x{2300}-\\x{23FF}\\x{3030}\\x{303D}\\x{FE0F}\\x{200D}\\x{20E3}\\x{2640}\\x{2642}\\x{26A7}]"
    )

    fun stripEmoji(text: String): String =
        text.replace(emojiRegex, "").replace(Regex("[ \\t]{2,}"), " ").lines()
            .joinToString("\n") { it.trim() }.trim()

    /** First tag from each group, for quick access while composing. */
    private class TagView(item: VaultItem, s: Settings) {
        private val byGroup: Map<String, List<String>> =
            item.tags.groupBy { TagCatalog.groupOf(it, s).id }

        fun all(group: String): List<String> = byGroup[group].orEmpty()

        val category = all("category").firstOrNull()
        val age = all("age").firstOrNull()
        val who = all("who").firstOrNull()
        val type = all("type").firstOrNull()
        val position = all("position").firstOrNull()
        val act = all("act").firstOrNull()
        val body = all("body").firstOrNull()
        val look = all("look").firstOrNull()
        val outfit = all("outfit").firstOrNull()
        val kink = all("kink").firstOrNull()
        val setting = all("setting").firstOrNull()
        val mood = all("mood").firstOrNull()
        val people = all("people")
        val person = people.firstOrNull()
    }
}
