package com.netscape.vault.crypto

import android.media.MediaDataSource
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import java.io.File
import javax.crypto.SecretKey

/** Feeds ExoPlayer decrypted bytes straight from the vault — nothing is ever written in the clear. */
class EncryptedDataSource(
    private val file: File,
    private val key: SecretKey
) : BaseDataSource(false) {

    private var reader: Crypto.RandomReader? = null
    private var uri: Uri? = null
    private var position = 0L
    private var remaining = 0L
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        transferInitializing(dataSpec)
        uri = dataSpec.uri
        val r = Crypto.RandomReader(file, key)
        reader = r
        position = dataSpec.position
        remaining = if (dataSpec.length == C.LENGTH_UNSET.toLong()) {
            r.plainLength - dataSpec.position
        } else {
            minOf(dataSpec.length, r.plainLength - dataSpec.position)
        }
        opened = true
        transferStarted(dataSpec)
        return remaining
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (remaining <= 0) return C.RESULT_END_OF_INPUT
        val want = minOf(length.toLong(), remaining).toInt()
        val read = reader?.readAt(position, buffer, offset, want) ?: -1
        if (read <= 0) return C.RESULT_END_OF_INPUT
        position += read
        remaining -= read
        bytesTransferred(read)
        return read
    }

    override fun getUri(): Uri? = uri

    override fun close() {
        reader?.close()
        reader = null
        uri = null
        if (opened) {
            opened = false
            transferEnded()
        }
    }

    class Factory(private val file: File, private val key: SecretKey) : DataSource.Factory {
        override fun createDataSource(): DataSource = EncryptedDataSource(file, key)
    }
}

/** Lets MediaMetadataRetriever pull frames out of an encrypted file for thumbnail picking. */
class EncryptedMediaDataSource(file: File, key: SecretKey) : MediaDataSource() {
    private val reader = Crypto.RandomReader(file, key)
    override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int =
        reader.readAt(position, buffer, offset, size)
    override fun getSize(): Long = reader.plainLength
    override fun close() = reader.close()
}
