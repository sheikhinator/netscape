package com.netscape.vault.crypto

import android.util.Base64
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.math.BigInteger
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * All Netscape media lives on disk as ciphertext and is never written anywhere else.
 *
 * - Master key: PBKDF2-HMAC-SHA256(passphrase, salt, 150k) -> 256 bit.
 * - Every item gets its own random 256-bit key, wrapped with the master key (AES-GCM).
 * - Media payloads use AES-256-CTR so the player can seek without decrypting the whole file.
 * - Thumbnails, metadata and the key wraps use AES-256-GCM (authenticated).
 */
object Crypto {

    const val ITERATIONS = 150_000
    const val CTR_IV_LEN = 16
    private const val GCM_IV_LEN = 12
    private const val GCM_TAG_BITS = 128

    private val rng = SecureRandom()

    fun randomBytes(n: Int): ByteArray {
        val b = ByteArray(n)
        rng.nextBytes(b)
        return b
    }

    fun deriveMasterKey(password: CharArray, salt: ByteArray, iterations: Int = ITERATIONS): SecretKey {
        val spec = PBEKeySpec(password, salt, iterations, 256)
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val raw = factory.generateSecret(spec).encoded
        return SecretKeySpec(raw, "AES")
    }

    fun newKey(): SecretKey = SecretKeySpec(randomBytes(32), "AES")

    // ---------- GCM (small blobs) ----------

    fun gcmEncrypt(key: SecretKey, plain: ByteArray): ByteArray {
        val iv = randomBytes(GCM_IV_LEN)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        return iv + c.doFinal(plain)
    }

    fun gcmDecrypt(key: SecretKey, blob: ByteArray): ByteArray {
        val iv = blob.copyOfRange(0, GCM_IV_LEN)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
        return c.doFinal(blob, GCM_IV_LEN, blob.size - GCM_IV_LEN)
    }

    fun wrapKey(master: SecretKey, key: SecretKey): String =
        Base64.encodeToString(gcmEncrypt(master, key.encoded), Base64.NO_WRAP)

    fun unwrapKey(master: SecretKey, wrapped: String): SecretKey =
        SecretKeySpec(gcmDecrypt(master, Base64.decode(wrapped, Base64.NO_WRAP)), "AES")

    fun b64(b: ByteArray): String = Base64.encodeToString(b, Base64.NO_WRAP)
    fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    // ---------- CTR (seekable media) ----------

    /** Counter block for the AES-CTR stream at [blockIndex] blocks past the base [iv]. */
    private fun counterFor(iv: ByteArray, blockIndex: Long): ByteArray {
        if (blockIndex == 0L) return iv.copyOf()
        val base = BigInteger(1, iv)
        val max = BigInteger.ONE.shiftLeft(128)
        val next = base.add(BigInteger.valueOf(blockIndex)).mod(max)
        val raw = next.toByteArray()
        val out = ByteArray(16)
        if (raw.size >= 16) {
            System.arraycopy(raw, raw.size - 16, out, 0, 16)
        } else {
            System.arraycopy(raw, 0, out, 16 - raw.size, raw.size)
        }
        return out
    }

    /**
     * Cipher positioned at plaintext byte [offset]. The returned Int is how many keystream
     * bytes must be discarded first so the stream lines up with the requested offset.
     */
    fun ctrCipherAt(key: SecretKey, iv: ByteArray, offset: Long): Pair<Cipher, Int> {
        val block = offset / 16
        val skip = (offset % 16).toInt()
        val c = Cipher.getInstance("AES/CTR/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(counterFor(iv, block)))
        if (skip > 0) c.update(ByteArray(skip))
        return c to skip
    }

    /**
     * Streams [input] into [dest] as `[16 byte IV][AES-CTR ciphertext]`.
     * Returns SHA-256 of the plaintext (used for duplicate detection) and the plaintext size.
     */
    fun encryptToFile(input: InputStream, dest: File, key: SecretKey): Pair<String, Long> {
        val iv = randomBytes(CTR_IV_LEN)
        val cipher = Cipher.getInstance("AES/CTR/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key, IvParameterSpec(iv))
        val digest = MessageDigest.getInstance("SHA-256")
        var total = 0L
        FileOutputStream(dest).use { out ->
            out.write(iv)
            val buf = ByteArray(128 * 1024)
            while (true) {
                val read = input.read(buf)
                if (read <= 0) break
                digest.update(buf, 0, read)
                total += read
                val enc = cipher.update(buf, 0, read)
                if (enc != null && enc.isNotEmpty()) out.write(enc)
            }
            val tail = cipher.doFinal()
            if (tail != null && tail.isNotEmpty()) out.write(tail)
            out.flush()
        }
        return b64(digest.digest()) to total
    }

    /** Full decrypt of a CTR file into memory (photos, small assets). */
    fun decryptFile(file: File, key: SecretKey): ByteArray {
        file.inputStream().use { input ->
            val iv = ByteArray(CTR_IV_LEN)
            var got = 0
            while (got < CTR_IV_LEN) {
                val r = input.read(iv, got, CTR_IV_LEN - got)
                if (r <= 0) break
                got += r
            }
            val cipher = Cipher.getInstance("AES/CTR/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, IvParameterSpec(iv))
            val body = input.readBytes()
            return cipher.doFinal(body)
        }
    }

    /** Random-access reader over a CTR encrypted file. */
    class RandomReader(private val file: File, private val key: SecretKey) {
        private val raf = java.io.RandomAccessFile(file, "r")
        private val iv = ByteArray(CTR_IV_LEN)
        val plainLength: Long

        init {
            raf.seek(0)
            raf.readFully(iv)
            plainLength = (file.length() - CTR_IV_LEN).coerceAtLeast(0L)
        }

        @Synchronized
        fun readAt(position: Long, out: ByteArray, offset: Int, size: Int): Int {
            if (position >= plainLength) return -1
            val want = minOf(size.toLong(), plainLength - position).toInt()
            if (want <= 0) return -1
            val raw = ByteArray(want)
            raf.seek(CTR_IV_LEN + position)
            var got = 0
            while (got < want) {
                val r = raf.read(raw, got, want - got)
                if (r <= 0) break
                got += r
            }
            if (got <= 0) return -1
            val (cipher, _) = ctrCipherAt(key, iv, position)
            val plain = cipher.update(raw, 0, got) ?: ByteArray(0)
            System.arraycopy(plain, 0, out, offset, plain.size)
            return plain.size
        }

        fun close() = try { raf.close() } catch (_: Exception) {}
    }
}
