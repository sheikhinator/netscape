package com.netscape.vault.ai

import java.io.InputStream
import java.util.zip.GZIPInputStream

/**
 * Byte-level BPE tokenizer used by OpenAI CLIP — a straight port of open_clip's SimpleTokenizer
 * (lower-case cleaning). Reads the standard bpe_simple_vocab_16e6.txt(.gz) merges file.
 */
class ClipTokenizer(mergesLines: List<String>) {

    /** byte value → printable unicode stand-in. */
    private val byteEncoder: Array<String>
    private val encoder: Map<String, Int>
    private val bpeRanks: Map<Pair<String, String>, Int>
    private val cache = HashMap<String, List<String>>()

    val sot: Int
    val eot: Int

    init {
        val (ordered, table) = bytesToUnicode()
        byteEncoder = table
        val merges = mergesLines.subList(1, 49152 - 256 - 2 + 1).map {
            val parts = it.split(" ")
            parts[0] to parts[1]
        }
        val vocab = ArrayList<String>(49408)
        vocab.addAll(ordered)
        ordered.forEach { vocab.add("$it</w>") }
        merges.forEach { vocab.add(it.first + it.second) }
        vocab.add("<start_of_text>")
        vocab.add("<end_of_text>")
        encoder = vocab.withIndex().associate { it.value to it.index }
        bpeRanks = merges.withIndex().associate { it.value to it.index }
        sot = encoder.getValue("<start_of_text>")
        eot = encoder.getValue("<end_of_text>")
    }

    private val pattern = Regex(
        "<start_of_text>|<end_of_text>|'s|'t|'re|'ve|'m|'ll|'d|[\\p{L}]+|[\\p{N}]|[^\\s\\p{L}\\p{N}]+",
        RegexOption.IGNORE_CASE
    )

    private fun bpe(token: String): List<String> {
        cache[token]?.let { return it }
        // Split into code points so non-BMP characters stay whole.
        val chars = ArrayList<String>()
        var i = 0
        while (i < token.length) {
            val cp = token.codePointAt(i)
            chars.add(String(Character.toChars(cp)))
            i += Character.charCount(cp)
        }
        var word: List<String> = chars.dropLast(1) + (chars.last() + "</w>")
        if (word.size == 1) {
            cache[token] = word
            return word
        }
        while (true) {
            var best: Pair<String, String>? = null
            var bestRank = Int.MAX_VALUE
            for (k in 0 until word.size - 1) {
                val pair = word[k] to word[k + 1]
                val rank = bpeRanks[pair] ?: continue
                if (rank < bestRank) {
                    bestRank = rank
                    best = pair
                }
            }
            if (best == null) break
            val (first, second) = best
            val next = ArrayList<String>(word.size)
            var j = 0
            while (j < word.size) {
                if (j < word.size - 1 && word[j] == first && word[j + 1] == second) {
                    next.add(first + second)
                    j += 2
                } else {
                    next.add(word[j])
                    j += 1
                }
            }
            word = next
            if (word.size == 1) break
        }
        cache[token] = word
        return word
    }

    fun encode(text: String): List<Int> {
        val clean = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.joinToString(" ").lowercase()
        val out = ArrayList<Int>()
        for (m in pattern.findAll(clean)) {
            val token = m.value.toByteArray(Charsets.UTF_8).joinToString("") { byteEncoder[it.toInt() and 0xFF] }
            bpe(token).forEach { piece -> encoder[piece]?.let { out.add(it) } }
        }
        return out
    }

    /** [sot] + tokens + [eot], truncated/zero-padded to [contextLength] — same as open_clip. */
    fun tokenize(text: String, contextLength: Int = 77): LongArray {
        var tokens = listOf(sot) + encode(text) + eot
        if (tokens.size > contextLength) tokens = tokens.take(contextLength - 1) + eot
        val out = LongArray(contextLength)
        tokens.forEachIndexed { i, t -> out[i] = t.toLong() }
        return out
    }

    companion object {
        fun fromGzip(input: InputStream): ClipTokenizer =
            ClipTokenizer(GZIPInputStream(input).bufferedReader(Charsets.UTF_8).use { it.readText() }.split("\n"))

        /** Returns (chars in Python dict insertion order, table indexed by byte value). */
        private fun bytesToUnicode(): Pair<List<String>, Array<String>> {
            val bs = ArrayList<Int>()
            bs.addAll('!'.code..'~'.code)
            bs.addAll('¡'.code..'¬'.code)
            bs.addAll('®'.code..'ÿ'.code)
            val cs = ArrayList(bs)
            var n = 0
            for (b in 0 until 256) {
                if (b !in bs) {
                    bs.add(b)
                    cs.add(256 + n)
                    n++
                }
            }
            val table = Array(256) { "" }
            val ordered = ArrayList<String>(256)
            bs.forEachIndexed { i, b ->
                val c = String(Character.toChars(cs[i]))
                table[b] = c
                ordered.add(c)
            }
            return ordered to table
        }
    }
}
