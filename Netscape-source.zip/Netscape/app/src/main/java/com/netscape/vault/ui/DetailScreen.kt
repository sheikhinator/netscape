package com.netscape.vault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Sell
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.AutoTags
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.TagCatalog
import com.netscape.vault.data.TitleGenerator
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DetailScreen(
    itemId: String,
    onBack: () -> Unit,
    onPlay: (VaultItem) -> Unit,
    onPlayAt: (VaultItem, Long) -> Unit,
    onPickFrame: (VaultItem) -> Unit,
    onEditTags: (VaultItem) -> Unit,
    onOpenTag: (String) -> Unit
) {
    val item = Vault.find(itemId)
    if (item == null) {
        // Deleted (or mid-transition) — render nothing; navigation handles the rest.
        Box(Modifier.fillMaxSize().background(Brand.Ink))
        return
    }
    val s = Vault.settings.value
    val scope = rememberCoroutineScope()
    var editing by remember { mutableStateOf(false) }
    var moving by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var thumbSheet by remember { mutableStateOf(false) }
    var reveal by remember(itemId) { mutableStateOf(false) }
    var descExpanded by remember { mutableStateOf(false) }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        Vault.suppressAutoLock = false
        if (uri != null) scope.launch { Vault.setThumbnailFromUri(item, uri) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(if (item.kind == MediaKind.PHOTO) 4f / 5f else 16f / 10f)
                .clickable { reveal = !reveal }
        ) {
            ThumbImage(item, Modifier.fillMaxSize(), reveal = reveal)
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0f to Color.Black.copy(alpha = 0.45f),
                            0.25f to Color.Transparent,
                            0.7f to Color.Transparent,
                            1f to Brand.Ink
                        )
                    )
            )
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                CircleIcon(Icons.Rounded.ArrowBackIosNew, "Back", onBack)
                Spacer(Modifier.weight(1f))
                CircleIcon(Icons.Rounded.Edit, "Edit") { editing = true }
            }
            if (item.kind == MediaKind.VIDEO) {
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.45f))
                        .bounceClick { onPlay(item) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.PlayArrow, contentDescription = "Play", tint = Color.White, modifier = Modifier.size(38.dp))
                }
            }
        }

        Column(modifier = Modifier.padding(horizontal = 18.dp)) {
            Text(
                text = shownTitle(item),
                color = Color.White,
                fontSize = 26.sp,
                fontWeight = FontWeight.Black,
                lineHeight = 31.sp
            )

            // Meta line: quality badge · duration · views · date
            Row(
                modifier = Modifier.padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                AutoTags.quality(item)?.let { q ->
                    Text(
                        q,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier
                            .background(Brand.SurfaceHigher, RoundedCornerShape(3.dp))
                            .padding(horizontal = 5.dp, vertical = 1.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                }
                Text(metaLine(item), color = Brand.Muted, fontSize = 13.sp)
            }

            Row(
                modifier = Modifier.padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                StarRating(item.rating, size = 24.dp) { r -> scope.launch { Vault.setRating(item, r) } }
            }

            if (item.inProgress) {
                LinearProgressIndicator(
                    progress = { item.progressFraction },
                    color = Brand.Red,
                    trackColor = Brand.Line,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp)
                        .height(3.dp)
                        .clip(RoundedCornerShape(2.dp))
                )
                Text(
                    text = "${formatDuration(item.durationMs - item.progressMs)} left",
                    color = Brand.Muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            PrimaryButton(
                text = when {
                    item.kind == MediaKind.PHOTO -> "View"
                    item.inProgress -> "Resume"
                    else -> "Play"
                },
                icon = Icons.Rounded.PlayArrow,
                light = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                onClick = { onPlay(item) }
            )
            if (item.inProgress) {
                SecondaryButton(
                    text = "Start from beginning",
                    icon = Icons.Rounded.Refresh,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                ) { onPlayAt(item, 0L) }
            }

            // Description
            if (item.description.isNotBlank() && !s.discreet) {
                val text = if (s.emojiLevel == 0) TitleGenerator.stripEmoji(item.description) else item.description
                Text(
                    text = text,
                    color = Brand.Label,
                    fontSize = 15.sp,
                    lineHeight = 21.sp,
                    maxLines = if (descExpanded) Int.MAX_VALUE else 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier
                        .padding(top = 16.dp)
                        .animateContentSize()
                        .clickable { descExpanded = !descExpanded }
                )
            }

            // ✨ one-tap writer
            Row(
                modifier = Modifier
                    .padding(top = 14.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Brand.Surface)
                    .clickable {
                        scope.launch {
                            Vault.saveDetails(
                                id = item.id,
                                title = Vault.generateTitle(item),
                                description = Vault.generateDescription(item),
                                rating = item.rating,
                                titleIsAuto = true
                            )
                        }
                    }
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Rounded.AutoAwesome, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                Text(
                    "  Generate new title & description",
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            AiSuggestRow(item)

            // Action row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp)
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ActionButton(
                    icon = if (item.favorite) Icons.Rounded.Check else Icons.Rounded.Add,
                    label = "My List",
                    tint = if (item.favorite) Brand.Red else Color.White
                ) { scope.launch { Vault.toggleFavorite(item) } }
                ActionButton(Icons.Rounded.Sell, "Tags") { onEditTags(item) }
                ActionButton(Icons.Rounded.Edit, "Edit") { editing = true }
                ActionButton(Icons.Rounded.Image, "Artwork") { thumbSheet = true }
                ActionButton(Icons.Rounded.Folder, "Folder") { moving = true }
                if (item.kind == MediaKind.VIDEO && item.progressMs > 0) {
                    ActionButton(Icons.Rounded.Visibility, "Unwatch") { scope.launch { Vault.clearProgress(item) } }
                }
                ActionButton(Icons.Rounded.Delete, "Delete", tint = Color(0xFFFF453A)) { deleting = true }
            }

            // Tags, grouped
            if (!s.discreet) {
                val grouped = item.tags.groupBy { TagCatalog.groupOf(it, s) }
                if (grouped.isEmpty()) {
                    Row(
                        modifier = Modifier
                            .padding(top = 20.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brand.Surface)
                            .clickable { onEditTags(item) }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🏷️", fontSize = 22.sp)
                        Column(modifier = Modifier.padding(start = 12.dp).weight(1f)) {
                            Text("Add tags", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            Text("Age, positions, acts, outfits, setting, mood, people…", color = Brand.Muted, fontSize = 13.sp)
                        }
                    }
                } else {
                    Column(modifier = Modifier.padding(top = 12.dp)) {
                        TagCatalog.groups.filter { it in grouped.keys }.forEach { g ->
                            Text(
                                if (s.emojiLevel == 0) g.name else "${g.emoji}  ${g.name}",
                                color = Brand.Muted,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 12.dp, bottom = 6.dp)
                            )
                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                grouped[g].orEmpty().forEach { tag ->
                                    TagChip(tagLabel(tag)) { onOpenTag(tag) }
                                }
                            }
                        }
                        TextButton(onClick = { onEditTags(item) }, modifier = Modifier.padding(top = 4.dp)) {
                            Text("Edit tags", color = Brand.Red)
                        }
                    }
                }

                val autos = AutoTags.of(item)
                if (autos.isNotEmpty()) {
                    Text(
                        "AUTO-DETECTED",
                        color = Brand.Muted,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        autos.forEach { tag -> TagChip(tag) { onOpenTag(tag) } }
                    }
                }
            }

            // Bookmarked moments
            if (item.kind == MediaKind.VIDEO) {
                Text(
                    "MOMENTS",
                    color = Brand.Muted,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 22.dp, bottom = 6.dp)
                )
                if (item.markers.isEmpty()) {
                    Text(
                        "While watching, tap the bookmark button to save a moment — e.g. 2:14 → Cowgirl. They show on the seek bar.",
                        color = Brand.Muted,
                        fontSize = 13.sp
                    )
                } else {
                    Column(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Brand.Surface)
                    ) {
                        item.markers.forEachIndexed { i, m ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onPlayAt(item, m.ms) }
                                    .padding(horizontal = 14.dp, vertical = 11.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Rounded.Bookmark, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                                Text(
                                    formatDuration(m.ms.coerceAtLeast(1000)),
                                    color = Brand.Red,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.padding(start = 10.dp).width(64.dp)
                                )
                                Text(
                                    if (s.discreet) "Moment ${i + 1}" else tagLabel(m.label),
                                    color = Color.White,
                                    fontSize = 15.sp,
                                    modifier = Modifier.weight(1f)
                                )
                                Icon(
                                    Icons.Rounded.Close,
                                    contentDescription = "Remove",
                                    tint = Brand.Muted,
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clickable { scope.launch { Vault.removeMarker(item, m) } }
                                )
                            }
                        }
                    }
                }
            }

            Text(
                text = "🔒 Encrypted with AES-256 · stored only in this app's private storage.",
                color = Brand.Muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 24.dp, bottom = 48.dp)
            )
        }
    }

    if (editing) {
        EditDetailsSheet(item = item, onDismiss = { editing = false })
    }

    if (moving) {
        FolderPickerDialog(
            onDismiss = { moving = false },
            onPick = { name ->
                moving = false
                scope.launch { Vault.setCollection(item, name) }
            }
        )
    }

    if (deleting) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            containerColor = Brand.Surface,
            title = { Text("Delete permanently?", color = Color.White) },
            text = {
                Text(
                    "\"${shownTitle(item)}\" and its encrypted file will be erased from this device.",
                    color = Brand.Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleting = false
                    scope.launch {
                        Vault.delete(item)
                        onBack()
                    }
                }) { Text("Delete", color = Color(0xFFFF453A), fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = false }) { Text("Cancel", color = Color.White) }
            }
        )
    }

    if (thumbSheet) {
        Sheet(onDismiss = { thumbSheet = false }) {
            Text(
                "Change artwork",
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
            )
            GroupedSection {
                if (item.kind == MediaKind.VIDEO) {
                    GroupedRow("Pick a frame from the video", icon = Icons.Rounded.PlayArrow, onClick = {
                        thumbSheet = false
                        onPickFrame(item)
                    })
                }
                GroupedRow("Choose an image", icon = Icons.Rounded.Image, showDivider = false, onClick = {
                    thumbSheet = false
                    Vault.suppressAutoLock = true
                    imagePicker.launch(arrayOf("image/*"))
                })
            }
            Spacer(Modifier.height(30.dp))
        }
    }
}

/** Title, description and rating in one sheet — with ✨ buttons to auto-write. */
@Composable
fun EditDetailsSheet(item: VaultItem, onDismiss: () -> Unit) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf(item.title) }
    var titleAuto by remember { mutableStateOf(item.autoTitle) }
    var description by remember { mutableStateOf(item.description) }
    var rating by remember { mutableStateOf(item.rating) }

    Sheet(onDismiss = onDismiss) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp)
                .padding(bottom = 36.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onDismiss) { Text("Cancel", color = Brand.Red, fontSize = 16.sp) }
                Text(
                    "Edit",
                    color = Color.White,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f),
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                TextButton(onClick = {
                    scope.launch {
                        Vault.saveDetails(item.id, title, description, rating, titleAuto && title.isNotBlank())
                        onDismiss()
                    }
                }) { Text("Save", color = Brand.Red, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
            }

            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                FilledField(
                    value = title,
                    onValueChange = { title = it; titleAuto = false },
                    label = "Title",
                    modifier = Modifier.weight(1f)
                )
                SparkleButton {
                    title = TitleGenerator.title(item.copy(rating = rating), Vault.numberOf(item), Vault.settings.value)
                    titleAuto = true
                }
            }

            Row(verticalAlignment = Alignment.Top, modifier = Modifier.padding(top = 12.dp)) {
                FilledField(
                    value = description,
                    onValueChange = { description = it },
                    label = "Description",
                    singleLine = false,
                    minLines = 4,
                    modifier = Modifier.weight(1f)
                )
                SparkleButton {
                    description = TitleGenerator.description(item.copy(rating = rating), Vault.settings.value)
                }
            }

            Text("RATING", color = Brand.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 20.dp, bottom = 8.dp))
            StarRating(rating, size = 34.dp) { rating = it }

        }
    }
}

@Composable
private fun SparkleButton(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .padding(start = 8.dp)
            .size(48.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Brand.SurfaceHigh)
            .bounceClick(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(Icons.Rounded.AutoAwesome, contentDescription = "Generate", tint = Brand.Red)
    }
}

@Composable
private fun CircleIcon(icon: ImageVector, label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.5f))
            .bounceClick(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = label, tint = Color.White, modifier = Modifier.size(20.dp))
    }
}

private fun metaLine(item: VaultItem): String {
    val date = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(item.addedAt))
    val size = String.format(Locale.US, "%.1f MB", item.sizeBytes / 1_048_576.0)
    val parts = mutableListOf<String>()
    if (item.durationMs > 0) parts += formatDuration(item.durationMs)
    parts += size
    if (item.views > 0) parts += "${item.views} view${if (item.views == 1) "" else "s"}"
    parts += date
    return parts.joinToString("  ·  ")
}

@Composable
private fun ActionButton(
    icon: ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(66.dp)
            .bounceClick(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(26.dp))
        Text(label, color = Brand.Muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
