package com.netscape.vault.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.netscape.vault.data.MediaKind
import com.netscape.vault.data.Vault
import com.netscape.vault.data.VaultItem
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DetailScreen(
    itemId: String,
    onBack: () -> Unit,
    onPlay: (VaultItem) -> Unit,
    onPickFrame: (VaultItem) -> Unit
) {
    val item = Vault.items.firstOrNull { it.id == itemId }
    if (item == null) {
        onBack()
        return
    }
    val scope = rememberCoroutineScope()
    var renaming by remember { mutableStateOf(false) }
    var moving by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    var thumbSheet by remember { mutableStateOf(false) }
    var draft by remember { mutableStateOf(item.title) }
    var collectionDraft by remember { mutableStateOf(item.collection) }

    val imagePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        Vault.suppressAutoLock = false
        if (uri != null) scope.launch { Vault.setThumbnailFromUri(item, uri) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brand.Ink)
            .verticalScroll(rememberScrollState())
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
        ) {
            ThumbImage(item, Modifier.fillMaxSize())
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            0.5f to Color.Transparent,
                            1f to Brand.Ink
                        )
                    )
            )
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(6.dp)
                    .background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(50))
            ) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
        }

        Column(modifier = Modifier.padding(horizontal = 18.dp)) {
            Text(
                text = item.title,
                color = Color.White,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = metaLine(item),
                color = Brand.Muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 6.dp)
            )

            if (item.inProgress) {
                LinearProgressIndicator(
                    progress = { item.progressFraction },
                    color = Brand.Red,
                    trackColor = Brand.Line,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .padding(top = 14.dp)
                )
                Text(
                    text = "Resumes at ${formatDuration(item.progressMs)}",
                    color = Brand.Muted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }

            Button(
                onClick = { onPlay(item) },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
                    .height(46.dp)
            ) {
                Icon(Icons.Filled.PlayArrow, contentDescription = null, tint = Color.Black)
                Text(
                    text = when {
                        item.kind == MediaKind.PHOTO -> "View"
                        item.inProgress -> "Resume"
                        else -> "Play"
                    },
                    color = Color.Black,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 6.dp)
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                ActionButton(
                    icon = if (item.favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    label = "My List",
                    tint = if (item.favorite) Brand.Red else Color.White
                ) { scope.launch { Vault.toggleFavorite(item) } }

                ActionButton(icon = Icons.Filled.DriveFileRenameOutline, label = "Rename") {
                    draft = item.title
                    renaming = true
                }
                ActionButton(icon = Icons.Filled.Image, label = "Artwork") { thumbSheet = true }
                ActionButton(icon = Icons.Filled.Folder, label = "Collection") {
                    collectionDraft = item.collection
                    moving = true
                }
                ActionButton(icon = Icons.Filled.Delete, label = "Delete", tint = Brand.Red) {
                    deleting = true
                }
            }

            if (item.kind == MediaKind.VIDEO && item.progressMs > 0) {
                TextButton(onClick = { scope.launch { Vault.clearProgress(item) } }) {
                    Icon(Icons.Filled.Refresh, contentDescription = null, tint = Brand.Muted, modifier = Modifier.size(16.dp))
                    Text("  Mark as unwatched", color = Brand.Muted, fontSize = 13.sp)
                }
            }

            Text(
                text = "Encrypted with AES-256. Stored only in this app's private storage.",
                color = Brand.Muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 20.dp, bottom = 40.dp)
            )
        }
    }

    if (renaming) {
        InputDialog(
            title = "Rename",
            value = draft,
            onValueChange = { draft = it },
            onConfirm = {
                scope.launch { Vault.rename(item, draft) }
                renaming = false
            },
            onDismiss = { renaming = false }
        )
    }

    if (moving) {
        InputDialog(
            title = "Collection",
            value = collectionDraft,
            onValueChange = { collectionDraft = it },
            onConfirm = {
                scope.launch { Vault.setCollection(item, collectionDraft) }
                moving = false
            },
            onDismiss = { moving = false }
        )
    }

    if (deleting) {
        AlertDialog(
            onDismissRequest = { deleting = false },
            containerColor = Brand.Surface,
            title = { Text("Delete permanently?", color = Color.White) },
            text = {
                Text(
                    "\"${item.title}\" and its encrypted file will be erased from this device.",
                    color = Brand.Muted
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    deleting = false
                    scope.launch {
                        Vault.delete(item)
                        onBack()
                    }
                }) { Text("Delete", color = Brand.Red) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = false }) { Text("Cancel", color = Color.White) }
            }
        )
    }

    if (thumbSheet) {
        AlertDialog(
            onDismissRequest = { thumbSheet = false },
            containerColor = Brand.Surface,
            title = { Text("Change artwork", color = Color.White) },
            text = { Text("Pick a frame from the video or use any image from your device.", color = Brand.Muted) },
            confirmButton = {
                if (item.kind == MediaKind.VIDEO) {
                    TextButton(onClick = {
                        thumbSheet = false
                        onPickFrame(item)
                    }) { Text("Pick a frame", color = Brand.Red) }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    thumbSheet = false
                    Vault.suppressAutoLock = true
                    imagePicker.launch(arrayOf("image/*"))
                }) { Text("Choose image", color = Color.White) }
            }
        )
    }
}

private fun metaLine(item: VaultItem): String {
    val date = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(item.addedAt))
    val size = String.format(Locale.US, "%.1f MB", item.sizeBytes / 1_048_576.0)
    val kind = if (item.kind == MediaKind.PHOTO) "Photo" else "Video"
    val duration = if (item.durationMs > 0) " • ${formatDuration(item.durationMs)}" else ""
    return "$kind$duration • $size • Added $date • ${item.collection}"
}

@Composable
private fun ActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color = Color.White,
    onClick: () -> Unit
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        IconButton(onClick = onClick) {
            Icon(icon, contentDescription = label, tint = tint)
        }
        Text(label, color = Brand.Muted, fontSize = 11.sp)
    }
}

@Composable
private fun InputDialog(
    title: String,
    value: String,
    onValueChange: (String) -> Unit,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Brand.Surface,
        title = { Text(title, color = Color.White) },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Brand.Red, modifier = Modifier.size(18.dp))
                Text("  Save", color = Brand.Red)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel", color = Color.White) }
        }
    )
}
