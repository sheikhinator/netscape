package com.netscape.vault.ai

/** Unapplied, reviewable title, non-graphic description, and catalog-tag proposal. */
data class SceneDraft(
    val title: String,
    val description: String,
    val tags: List<String>
)