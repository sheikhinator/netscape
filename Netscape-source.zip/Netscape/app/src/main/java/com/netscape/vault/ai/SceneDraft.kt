package com.netscape.vault.ai

/** Unapplied, reviewable title, non-graphic description, and catalog-tag proposal. */
data class SceneDraft(
    val title: String,
    val description: String,
    val tags: List<String>
)

/**
 * Turns whatever the small scene model wrote into a [SceneDraft]. A 500M model often cuts JSON
 * short, drifts from the requested layout, or just writes a sentence, so this accepts the line
 * format ("Title: / Description: / Tags:"), JSON (complete or truncated) and plain text, and only
 * fails when there is nothing usable at all. Plain Kotlin so it is unit-tested on a desktop JVM.
 */
object SceneDraftParser {

    private val BLOCKED = Regex(
        """\b(?:nude|nudity|naked|sex|sexual|genital\w*|penis|vagina|breasts?|intercourse|penetrat\w*|orgasm\w*|ejaculat\w*)\b""",
        RegexOption.IGNORE_CASE
    )

    fun parse(raw: String, allowedTags: List<String>): SceneDraft {
        val text = raw.replace("<end_of_utterance>", "").replace("\r", "").trim()
        require(text.isNotBlank()) { "The scene model returned nothing. Try again." }

        var title = field(text, "title")
        var description = field(text, "description") ?: field(text, "caption")
        val tagField = field(text, "tags")

        // No labelled fields: treat the answer as a plain description.
        if (title == null && description == null) {
            description = text.lineSequence().map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("{") && !it.startsWith("}") && !it.startsWith("[") }
                .joinToString(" ")
        }

        description = description?.let { safe(clean(it)) }?.let { finish(limit(it, 178)) }
        title = title?.let { safe(clean(it)) }?.takeIf { it.isNotBlank() }?.let { limit(it, 63) }
            ?: description?.let { titleFrom(it) }

        val tags = matchTags(tagField, text, allowedTags)
        require(!title.isNullOrBlank() || tags.isNotEmpty()) {
            "The scene model didn't describe anything usable. Try again."
        }
        return SceneDraft(title.orEmpty(), description.orEmpty(), tags)
    }

    /** Value of `Title: …` / `"title": "…"` (truncated JSON strings are fine). */
    private fun field(text: String, name: String): String? {
        Regex("(?i)\"$name\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"?").find(text)?.let {
            return it.groupValues[1].replace("\\\"", "\"").replace("\\n", " ").trim().ifBlank { null }
        }
        Regex("(?im)^\\s*[*#\\-]*\\s*$name\\s*[*]*\\s*[:：]\\s*(.+)$").find(text)?.let {
            return it.groupValues[1].trim().ifBlank { null }
        }
        return null
    }

    private fun clean(s: String): String =
        s.replace(Regex("[\\r\\n\\t]+"), " ")
            .replace(Regex("[*_#`{}\\[\\]]"), "")
            .replace(Regex("\\s{2,}"), " ")
            .trim().trim('"', '\'', ',', ' ')

    /** Keeps the draft non-graphic by dropping any sentence with blocked words, instead of failing. */
    private fun safe(s: String): String =
        s.split(Regex("(?<=[.!?])\\s+")).filterNot { BLOCKED.containsMatchIn(it) }.joinToString(" ").trim()

    /** Cut at a word (or sentence) boundary rather than mid-word. */
    private fun limit(s: String, max: Int): String {
        if (s.length <= max) return s
        val cut = s.take(max)
        val sentence = cut.lastIndexOfAny(charArrayOf('.', '!', '?'))
        if (sentence >= max / 2) return cut.take(sentence + 1)
        val space = cut.lastIndexOf(' ')
        return (if (space > 0) cut.take(space) else cut).trimEnd(',', ';', ' ') + "…"
    }

    private val DANGLING = Regex("(?i)[,;:\\s]+(?:and|or|with|the|a|an|of|in|on|at|to|by|for|while|as)?\\s*$")

    /** A cut-off answer ends mid-phrase: end it at the last full sentence, or close it cleanly. */
    private fun finish(s: String): String {
        if (s.isBlank() || s.last() in ".!?…") return s
        val sentence = s.lastIndexOfAny(charArrayOf('.', '!', '?'))
        if (sentence >= s.length / 2) return s.take(sentence + 1)
        var t = s
        while (true) { val n = t.replace(DANGLING, ""); if (n == t) break; t = n }
        return if (t.isBlank()) t else "$t."
    }

    private val LEADING = Regex("(?i)^(?:this|the|in this|here|a|an)\\s+(?:image|photo|picture|video|frame|scene|shot)\\s+(?:shows|features|depicts|is of|of)\\s+")

    private fun titleFrom(description: String): String? {
        val words = description.replace(LEADING, "").substringBefore('.').substringBefore(',')
            .split(' ').filter { it.isNotBlank() }.take(6)
        if (words.isEmpty()) return null
        return words.joinToString(" ").trimEnd(',', ';', ':').replaceFirstChar { it.uppercase() }
    }

    /** Tags from the Tags field first, then any catalog tag the text names outright. */
    private fun matchTags(tagField: String?, text: String, allowed: List<String>): List<String> {
        val canonical = allowed.associateBy { it.lowercase() }
        val fromField = tagField.orEmpty()
            .split(',', ';', '|', '\n', '"')
            .map { it.trim().trim('[', ']', '.', '-', '*', ' ').lowercase() }
            .mapNotNull { canonical[it] }
        val mentioned = allowed.filter { tag ->
            Regex("(?i)(?<![\\w])${Regex.escape(tag)}(?![\\w])").containsMatchIn(text)
        }
        return (fromField + mentioned).distinct().take(6)
    }
}
