package com.netscape.vault.data

import org.json.JSONArray
import org.json.JSONObject

enum class TitleStyle(val label: String) {
    SPICY("Spicy 🌶️"),
    FLIRTY("Flirty 😘"),
    CLASSY("Classy 🥂"),
    PLAYFUL("Playful 😜"),
    FILTHY("Filthy 😈"),
    MINIMAL("Minimal"),
    CUSTOM("Custom template")
}

enum class SortOrder(val label: String) {
    NEWEST("Newest"),
    OLDEST("Oldest"),
    TITLE("A–Z"),
    RATING("Top rated"),
    VIEWS("Most watched"),
    LONGEST("Longest"),
    SHORTEST("Shortest"),
    RANDOM("Shuffle")
}

/** Everything the user can customise. Stored inside the encrypted library file. */
data class Settings(
    val titleStyle: TitleStyle = TitleStyle.SPICY,
    /** 0 = no emojis, 1 = a few, 2 = lots. */
    val emojiLevel: Int = 2,
    val customTemplate: String = "{emoji} {adj} {setting} {noun} · {position} #{n}",
    val autoNameOnImport: Boolean = true,
    val autoDescribe: Boolean = true,
    /** Regenerate auto titles whenever tags change (manual titles are never touched). */
    val retitleOnTagChange: Boolean = true,
    val accent: Int = 0,
    val gridColumns: Int = 2,
    val defaultSort: SortOrder = SortOrder.NEWEST,
    val showBillboard: Boolean = true,
    val showTagsOnCards: Boolean = true,
    val blurThumbs: Boolean = false,
    val discreet: Boolean = false,
    val startMuted: Boolean = false,
    val customTags: Map<String, List<String>> = emptyMap(),
    val hiddenGroups: Set<String> = emptySet(),
    /** Offline AI: auto-apply confident tags to new imports. */
    val aiAutoTagImports: Boolean = false,
    /** 0 = strict, 1 = balanced, 2 = loose. */
    val aiSensitivity: Int = 1,
    /** Offline writer: rewrite auto titles/descriptions in the background after import/tagging. */
    val aiAutoWrite: Boolean = true
) {
    fun toJson(): JSONObject {
        val custom = JSONObject()
        customTags.forEach { (k, v) -> custom.put(k, JSONArray(v)) }
        return JSONObject()
            .put("titleStyle", titleStyle.name)
            .put("emojiLevel", emojiLevel)
            .put("customTemplate", customTemplate)
            .put("autoNameOnImport", autoNameOnImport)
            .put("autoDescribe", autoDescribe)
            .put("retitleOnTagChange", retitleOnTagChange)
            .put("accent", accent)
            .put("gridColumns", gridColumns)
            .put("defaultSort", defaultSort.name)
            .put("showBillboard", showBillboard)
            .put("showTagsOnCards", showTagsOnCards)
            .put("blurThumbs", blurThumbs)
            .put("discreet", discreet)
            .put("startMuted", startMuted)
            .put("customTags", custom)
            .put("hiddenGroups", JSONArray(hiddenGroups.toList()))
            .put("aiAutoTagImports", aiAutoTagImports)
            .put("aiSensitivity", aiSensitivity)
            .put("aiAutoWrite", aiAutoWrite)
    }

    companion object {
        fun fromJson(o: JSONObject?): Settings {
            if (o == null) return Settings()
            val d = Settings()
            val custom = mutableMapOf<String, List<String>>()
            o.optJSONObject("customTags")?.let { c ->
                c.keys().forEach { k -> custom[k] = c.optJSONArray(k).strings() }
            }
            return Settings(
                titleStyle = enumOr(o.optString("titleStyle"), d.titleStyle),
                emojiLevel = o.optInt("emojiLevel", d.emojiLevel).coerceIn(0, 2),
                customTemplate = o.optString("customTemplate", d.customTemplate),
                autoNameOnImport = o.optBoolean("autoNameOnImport", d.autoNameOnImport),
                autoDescribe = o.optBoolean("autoDescribe", d.autoDescribe),
                retitleOnTagChange = o.optBoolean("retitleOnTagChange", d.retitleOnTagChange),
                accent = o.optInt("accent", d.accent),
                gridColumns = o.optInt("gridColumns", d.gridColumns).coerceIn(1, 4),
                defaultSort = enumOr(o.optString("defaultSort"), d.defaultSort),
                showBillboard = o.optBoolean("showBillboard", d.showBillboard),
                showTagsOnCards = o.optBoolean("showTagsOnCards", d.showTagsOnCards),
                blurThumbs = o.optBoolean("blurThumbs", d.blurThumbs),
                discreet = o.optBoolean("discreet", d.discreet),
                startMuted = o.optBoolean("startMuted", d.startMuted),
                customTags = custom,
                hiddenGroups = o.optJSONArray("hiddenGroups").strings().toSet(),
                aiAutoTagImports = o.optBoolean("aiAutoTagImports", d.aiAutoTagImports),
                aiSensitivity = o.optInt("aiSensitivity", d.aiSensitivity).coerceIn(0, 2),
                aiAutoWrite = o.optBoolean("aiAutoWrite", d.aiAutoWrite)
            )
        }

        private inline fun <reified E : Enum<E>> enumOr(name: String, fallback: E): E =
            enumValues<E>().firstOrNull { it.name == name } ?: fallback
    }
}

fun JSONArray?.strings(): List<String> {
    if (this == null) return emptyList()
    return (0 until length()).map { getString(it) }
}
